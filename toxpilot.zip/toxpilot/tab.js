

var Tab = function(type, base){
	this.type = type;
	this.info = [];

	var self = this;

	var cmdMap = {'showTab': {
			undo:function(param){
				var id = param[0];
				var prev = param[1];
				self.showTab(prev);
			}, redo:function(param){
				var id = param[0];
				var prev = param[1];
				self.showTab(id);
			}
		}
	};

	cmds.addHandler(this.type, cmdMap);


	if (Array.isArray(base)){
		// 固定タブ
		for (var i in base){
			var obj = base[i];
			this.addTab(obj.head, obj.content, obj.obj, false);
		}
	} else if (base != null){
		// 追加タブ
		this.id = base;
	}

};

Tab.prototype.getTabs = function(){
	return this.info;
}

Tab.prototype.getTab = function(head){
	return this.info[head];
}


// 引数で指定するのはheadおよびcontentのID
Tab.prototype.addTab = function(head, body, obj, closeable, func ){
	var self = this;

	// 閉じられるタブ
	if (closeable == null){
		closeable = true;
	}

	this.info[head] = {'head':head, 'content':body, 'obj':obj};

	$('#' + head).click(function(data){
		var newTab = data.target.id;
		if (newTab == ''){
			newTab = data.target.parentElement.id;
		}
		var prevTab = self.getCurrentTab();
		var cmd = new Command(self.type + ".showTab", [newTab, prevTab]);
		cmds.push(cmd);

		self.showTab(newTab);
	});
	
	if (closeable){
		$('#' + head).append('<span class="tab_close"><input type="image" src="img/close_button.png" alt="x" class="close_button ' + head + '"></span>');
		$('.close_button' + '.' + head ).on( 'click', func );
	}
	
	self.refreshCloseButton( self );
}

Tab.prototype.refreshCloseButton = function( tabData ) {
	var keys 	= Object.keys( tabData.info );
	var displaystyle;
	if( keys.length == 1 ) {
		displayStyle = 'none';
	}
	else {
		displayStyle = 'inline';
	}
	for( var cnt = 0; cnt < keys.length; cnt++ ) {
		var buttons = document.getElementsByClassName( 'close_button' + ' ' + keys[cnt] );	
		for ( var cnt2 = 0; cnt2 < buttons.length; cnt2++ ) {
 			 buttons[cnt2].style.display = displayStyle;
		}
	}
}


Tab.prototype.removeTab = function(head){
	var selected = this.getCurrentTab();
	if (selected == head){
		// 表示中タブが削除対象なので、一つ前のタブに切り替える
		var prev = null;
		var next = null;
		for (var key in this.info){
			if (next){
				next = key;
				break;
			}
			if (key == selected){
				if (prev == null){
					next = true;
				} else {
					break;
				}
			}
			prev = key;
		}
		if (next != null){
			this.showTab(next);
		} else if (prev != null){
			this.showTab(prev);
		}
	}
	var map = this.info[head];
	$("#"+map.content).remove();
	$("#"+head).remove();
	if (this.info[head].obj != null){
		delete this.info[head].obj;
	}
	delete this.info[head];
	this.refreshCloseButton( this );
}

/**
 * タブ名から該当タブを取得
 */
Tab.prototype.findTab = function(label){
	for (var i in this.info){
		var head = this.info[i].head;

		if ($('#' + head +" .label").text() == label){
			return head;
		}
	}
	return null;

}

// タブを指定してラベル名を設定する
Tab.prototype.setName = function(name, label){

	if ($('#' + name + " .label").length == 0){
		$('#' + name).append('<span class="label"></span>');
	}
	$('#' + name + " .label").text(label);

}


// 外からタブを設定
Tab.prototype.showTab = function(name){
	// TODO
	for (var i in this.info){
		var head = this.info[i].head;
		var content = this.info[i].content;

		$('#' + head).removeClass('selected');
		$('#' + content).hide();
	}

	for (var i in this.info){
		var head = this.info[i].head;
		var content = this.info[i].content;

		if (head == name || name == null){
			$('#' + head).addClass('selected');
			$('#' + content).show();
			break;
		}
	}
	$(window).trigger('resize');
};

// 新しく追加可能なタブのIDを取得する
Tab.prototype.getNewTabID = function(){
	var index;
	for (index = 0; ;index++){
		if ($("#" + this.id + "_head_"+index)[0] == null){
			break;
		}
	}
	return {'head':this.id + "_head_"+index, 'body':this.id + "_body_"+index};
}


Tab.prototype.getCurrentTab = function(){
	// TODO
	for (var i in this.info){
		var head = this.info[i].head;
		var content = this.info[i].content;

		if ($('#' + head).hasClass('selected')){
			return head;
		}
	}
	return null;

};

