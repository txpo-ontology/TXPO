

var cmds = new CommandHandler();

$(window).load(function() {
	var self = this;
	this.lang = 'ja';

	tab = new Tab("base", [{head:'head_1', content:'body_1'}, {head:'head_2', content:'body_2'}, {head:'head_3', content:'body_3'}, {head:'head_4', content:'body_4'}, {head:'head_5', content:'body_5'}, {head:'head_6', content:'body_6'}, {head:'head_7', content:'body_7'}, {head:'head_8', content:'body_8'}]);
	tab.showTab('head_7');


	// 言語
	var words = {};
	words['ja'] = {
			'title':'Toxic process interpretable knowledge system',
			'tab_1':'各種検索',
			'tab_2':'作用機序',
			'tab_3':'汎用機序',
			'tab_4':'プロセス',
			'tab_5':'経路',
			'tab_6':'オントロジー',
			'tab_7':'トップ',
			'tab_8':'PubMed'
			};
	words['en'] = {
			'title':'Toxic process interpretable knowledge system',
			'tab_1':'Search',
			'tab_2':'Toxic Course',
			'tab_3':'General course map',
			'tab_4':'Process',
			'tab_5':'Route',
			'tab_6':'Ontology',
			'tab_7':'Top',
			'tab_8':'PubMed'
			};



	var sc = null;
	$('#head_1').click(function() {
		if (sc == null){
			sc = new SearchController(base_url, $('#body_1'));
			sc.setEventHandler(function(src, type, args){
				var func = self.searchEventMap[type];
				if (func != null){
					func(src, args);
				}
			});
			sc.setLang(self.lang);
		}
		change_style('head_1');

	});

	var cc = null;
	$('#head_2').click(function() {
		if (cc == null){
			cc = createController( 'head_2', null, true );
			/*
			cc = new CourseController( base_url, $( '#body_2' ), self.lang, null, true);
			cc.setEventHandler(function(src, type, args) {
				var func = self.courseEventMap[type];
				if (func != null) {
					func(src, args);
				}
			} );
			cc.setLang(self.lang);
			*/
		}
		change_style('head_2');
	} );

	var gc = null;
	$('#head_3').click(function() {
		if (gc == null){
			gc = createController( 'head_3', null, true );
			/*
			gc = new GenericController(base_url, $('#body_3'), self.lang, null, true);
			gc.setEventHandler(function(src, type, args){
				var func = self.genericEventMap[type];
				if (func != null){
					func(src, args);
				}
			} );
			gc.setLang(self.lang);
			*/
		}
		change_style('head_3');

	} );

	var pc = null;
	$('#head_4').click(function() {
		if (pc == null){
			pc = createController( 'head_4', null, true );
			/*
			pc = new ProcessController(base_url, $('#body_4'), self.lang, null, true);
			pc.setEventHandler(function(src, type, args){
				var func = self.processEventMap[type];
				if (func != null){
					func(src, args);
				}
			});
			pc.setLang(self.lang);
			*/

		}
		change_style('head_4');

	} );

	var rc = null;
	$('#head_5').click(function() {
		if (rc == null){
			rc = createController( 'head_5', null, true );
			/*
			rc = new RouteController(base_url, $('#body_5'), self.lang, null, true);
			rc.setEventHandler(function(src, type, args){
				var func = self.routeEventMap[type];
				if (func != null){
					func(src, args);
				}
			} );
			rc.setLang(self.lang);
			*/
		}
		change_style('head_5');

	} );

	var ac = null;
	$('#head_6').click(function() {
		if (ac == null){
			ac = createController( 'head_6', null, true );
/*
			ac = new AllController(base_url, $('#body_6'), self.lang, null, true);
			ac.setEventHandler(function(src, type, args){
				var func = self.allEventMap[type];
				if (func != null){
					func(src, args);
				}
			} );
			ac.setLang(self.lang);
			*/
		}
		change_style('head_6');
	} );

	var tc = null;
//	$('#head_7').click(function() {
	$('.head_logo2').click(function() {
		if (tc == null){
			tc = createController('head_7');
		}
		tab.showTab('head_7');
		change_style('head_7');
	} );

	var mc = null;
	$('#head_8').click(function() {
		if (mc == null){
			mc = createController( 'head_8', null, true );
		}
		change_style('head_8');
//		mc.setLang(self.lang);

	} );


	$('#head_7').hide();

	// 各画面の作成関数　処理の共通化のため定義
	function createController( showTab, param, isCreateTab ) {
		var ret = null;
		switch( showTab ) {
			case 'head_1':
				ret = new SearchController( base_url, $( '#body_1' ), self.lang, param, isCreateTab );
				ret.setEventHandler( function( src, type, args ) {
					var func = self.searchEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				sc = ret;
				break;
			case 'head_2':
				ret = new CourseController( base_url, $( '#body_2' ), self.lang, param, isCreateTab );
				ret.setEventHandler( function( src, type, args ) {
					var func = self.courseEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				cc = ret;
				break;
			case 'head_3':
				ret = new GenericController( base_url, $( '#body_3' ), self.lang, param, isCreateTab );
				ret.setEventHandler(function( src, type, args ) {
					var func = self.genericEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				gc = ret;
				break;
			case 'head_4':
				ret = new ProcessController( base_url, $('#body_4'), self.lang, param, isCreateTab );
				ret.setEventHandler( function( src, type, args ) {
					var func = self.processEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				pc = ret;
				break;
			case 'head_5':
				ret = new RouteController( base_url, $('#body_5'), self.lang, param, isCreateTab );
				ret.setEventHandler( function( src, type, args ) {
					var func = self.routeEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				rc = ret;
				break;
			case 'head_6':
				ret = new AllController( base_url, $('#body_6'), self.lang, param);
				ret.setEventHandler(function( src, type, args ) {
					var func = self.allEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				ac = ret;
				break;
			case 'head_7':
				ret = new TopController( base_url, $('#body_7'));
				ret.setEventHandler(function( src, type, args ) {
					var func = self.topEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				tc = ret;
				break;
			case 'head_8':
				ret = new PubMedController( base_url, $('#body_8'), self.lang, param);
				ret.setEventHandler(function( src, type, args ) {
					var func = self.pubmedEventMap[type];
					if( func != null ) {
						func( src, args );
					}
				} );
				mc = ret;
				break;
			default:
				return( null );
		}
		ret.setLang( self.lang );

		return( ret );
	}

	// 言語設定が切り替わったときのイベント
	$('#lang_select select').change(function(event){
		self.lang = $('#lang_select select').val();
		change_lang(self.lang);
	});

	function change_lang(lang){
		/*
		$('.head h1').text(words[lang].title);
		for (var i=0; i<$('#tab_head li').length; i++){
			$($('#tab_head li')[i]).text(words[lang].tabs[i]);
		}
		*/
		for(var key in words[lang]){
			$('.text_'+key).text(words[lang][key]);
		}


		change_lang_common(sc, lang);
		change_lang_common(cc, lang);
		change_lang_common(gc, lang);
		change_lang_common(pc, lang);
		change_lang_common(rc, lang);
		change_lang_common(ac, lang);
		change_lang_common(tc, lang);
		change_lang_common(mc, lang);
	}

	function change_lang_common( c, lang ){
		if( c != null ){
			c.setLang( lang );
		}
	}

	function eventmap_common(c, showTab, args, command){
		if( null == c ){
			c = createController(showTab, null, false);
		}
		if( c != null ){
			// TODO history
			var prev = c.getCurrentTab();

			// タブに応じてスタイル切り替え
			change_style(showTab);

			// tab切り替え
			tab.showTab( showTab );
			// TODO newtabがあればそれに設定
			// なければあたらしく追加
			var tabid = c.addTab(args, false);

			var cmd = new Command( command, [tabid, prev, args]);
			cmds.push(cmd);
		}
		return c;
	}

	function change_style(tab){
		for (var i=0; i<7;i++){
			$('body').removeClass('bgcolor_'+(i+1));
		}
		var cls = tab.replace('head', 'bgcolor');
		$('body').addClass(cls);

		if (tab == 'head_7'){
			$('.head_logo').show();
			$('.div_text_title').show();
			$('.tab_head').hide();
			$('.head_logo2').hide();
			$('.head_block').addClass('top');
		} else {
			$('.head_logo').hide();
			$('.div_text_title').hide();
			$('.tab_head').show();
			$('.head_logo2').show();
			$('.head_block').removeClass('top');
		}

	}

	// TODO tab間に関連するイベント
	function set_eventmap(){
		self.searchEventMap = {
			'course':function( src, args ){
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'molecule':function(src, args){
				var prev = tab.getCurrentTab();

				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				}

				tab.showTab('head_6');
				ac.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'role':function(src, args){
				var prev = tab.getCurrentTab();

				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				}

				tab.showTab('head_6');
				ac.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'finding':function(src, args){
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'structure':function(src, args){
				var prev = tab.getCurrentTab();

				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				}

				tab.showTab('head_6');
				ac.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();

				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				}

				tab.showTab('head_6');
				change_style('head_6');
				ac.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'pubmed':function(src, args){
				var prev = tab.getCurrentTab();

				if (mc == null){
					mc = createController('head_8', {ids:[args]});
				}

				tab.showTab('head_8');
				mc.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_8', prev, args]);
				cmds.push(cmd);
			}
		};

		self.courseEventMap = {
			// TODO searchがないが必要ではないか？
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();
				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				} else {
					ac.show_info(args, 'new');
				}
				tab.showTab('head_6');
				change_style('head_6');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'pubmed':function(src, args){
				var prev = tab.getCurrentTab();

				if (mc == null){
					mc = createController('head_8', {ids:[args]});
				}

				tab.showTab('head_8');
				mc.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_8', prev, args]);
				cmds.push(cmd);
			}
		};

		self.genericEventMap = {
			'course':function(src, args){
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();
				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				} else {
					ac.show_info(args, 'new');
				}
				tab.showTab('head_6');
				change_style('head_6');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'pubmed':function(src, args){
				var prev = tab.getCurrentTab();

				if (mc == null){
					mc = createController('head_8', {ids:[args]});
				}

				tab.showTab('head_8');
				mc.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_8', prev, args]);
				cmds.push(cmd);
			}
		};

		self.processEventMap = {
			'course':function(src, args){
				// argsは作用機序IDのみ、もしくは作用機序IDとプロセスIDの配列
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();
				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				} else {
					ac.show_info(args, 'new');
				}
				tab.showTab('head_6');
				change_style('head_6');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'pubmed':function(src, args){
				var prev = tab.getCurrentTab();

				if (mc == null){
					mc = createController('head_8', {ids:[args]});
				}

				tab.showTab('head_8');
				mc.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_8', prev, args]);
				cmds.push(cmd);
			}
		};

		self.routeEventMap = {
			'course':function(src, args){
				// argsは作用機序IDのみ、もしくは作用機序IDとプロセスIDの配列
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();
				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				} else {
					ac.show_info(args, 'new');
				}
				tab.showTab('head_6');
				change_style('head_6');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);

			}

		};
		self.allEventMap = {
			'course':function(src, args){
				eventmap_common( cc, 'head_2', args, "base.course" );
			},
			'generic':function(src, args){
				eventmap_common( gc, 'head_3', args, "base.generic" );
			},
			'process':function(src, args){
				eventmap_common( pc, 'head_4', args, "base.process" );
			},
			'route':function(src, args){
				eventmap_common( rc, 'head_5', args, "base.route" );
			},
			'ontology':function(src, args){
//				eventmap_common( ac, 'head_6', args, "base.ontology" );
				var prev = tab.getCurrentTab();
				if (ac == null){
					ac = createController('head_6', {ids:[args]});
				} else {
					ac.show_info(args, 'new');
				}
				tab.showTab('head_6');
				change_style('head_6');

				var cmd = new Command("base.ontology", ['head_6', prev, args]);
				cmds.push(cmd);
			},
			'pubmed':function(src, args){
				var prev = tab.getCurrentTab();

				if (mc == null){
					mc = createController('head_8', {ids:[args]});
				}

				tab.showTab('head_8');
				mc.show_info(args, 'new');

				var cmd = new Command("base.ontology", ['head_8', prev, args]);
				cmds.push(cmd);
			}
		};
		self.topEventMap = {
				'search':function(src, args){
//					eventmap_common( sc, 'head_1', args, "base.search" );
					if (sc == null){
						sc = createController( 'head_1', null, true );
					}
					tab.showTab('head_1');
					change_style('head_1');

				},
				'course':function(src, args){
					if (cc == null){
						cc = createController( 'head_2', null, true );
					}
					tab.showTab('head_2');
					change_style('head_2');

				},
				'generic':function(src, args){
//					eventmap_common( gc, 'head_3', args, "base.generic" );
					if (gc == null){
						gc = createController( 'head_3', null, true );
					}
					tab.showTab('head_3');
					change_style('head_3');

				},
				'process':function(src, args){
//					eventmap_common( pc, 'head_4', args, "base.process" );
					if (pc == null){
						pc = createController( 'head_4', null, true );
					}
					tab.showTab('head_4');
					change_style('head_4');

				},
				'route':function(src, args){
//					eventmap_common( rc, 'head_5', args, "base.route" );
					if (rc == null){
						rc = createController( 'head_5', null, true );
					}
					tab.showTab('head_5');
					change_style('head_5');

				},
				'ontology':function(src, args){
//					eventmap_common( ac, 'head_6', args, "base.ontology" );
					/*
					var prev = tab.getCurrentTab();
					if (ac == null){
						ac = createController('head_6', {ids:[args]});
					} else {
						ac.show_info(args, 'new');
					}
					tab.showTab('head_6');

					var cmd = new Command("base.ontology", ['head_6', prev, args]);
					cmds.push(cmd);
					*/
					if (ac == null){
						ac = createController( 'head_6', null, true );
					}
					tab.showTab('head_6');
					change_style('head_6');
				},
				'pubmed':function(src, args){
					if (mc == null){
						mc = createController('head_8', {ids:[args]});
					}

					tab.showTab('head_8');
					change_style('head_8');
				}
			};
		self.pubmedEventMap = {
				'course':function(src, args){
					eventmap_common( cc, 'head_2', args, "base.course" );

				},
				'generic':function(src, args){
					eventmap_common( gc, 'head_3', args, "base.generic" );
				},
				'process':function(src, args){
					eventmap_common( pc, 'head_4', args, "base.process" );
				},
				'route':function(src, args){
					eventmap_common( rc, 'head_5', args, "base.route" );
				},
				'ontology':function(src, args){
					var prev = tab.getCurrentTab();

					if (ac == null){
						ac = createController('head_6', {ids:[args]});
					}

					tab.showTab('head_6');
					change_style('head_6');
					ac.show_info(args, 'new');

					var cmd = new Command("base.ontology", ['head_6', prev, args]);
					cmds.push(cmd);
				},
				'pubmed':function(src, args){
					if (mc == null){
						mc = createController('head_8', {ids:[args]});
					}

					tab.showTab('head_8');
					change_style('head_8');
				}
			};

	}

	init();

	function init(){


		function undo_common ( param, c, showTab ) {
			if( c != null ){
				var tabid 	= param[0];
				var prev 	= param[1];
				var id 		= param[2];
				c.removeTab( tabid, false );
				c.selectTab( prev, false );
				tab.showTab( showTab );
			}
		}

		function redo_common ( param, c, showTab ) {
			if( c != null ) {
				var tabid	= param[0];
				var prev	= param[1];
				var id		= param[2];
				c.addTab( id, false );
				c.selectTab( tabid, false );
				tab.showTab( showTab );
			}
		}

		var cmdMap = {};
		cmdMap['course'] = {
			undo:function( param ) {
				undo_common( param, cc, 'head_1' );
			},
			redo:function( param ) {
				redo_common( param, cc, 'head_2' );
			}
		};
		cmdMap['process'] = {
			undo:function( param ) {
				undo_common( param, pc, 'head_1' );
			},
			redo:function(param){
				redo_common( param, pc, 'head_2' );
			}
		};
		cmdMap['generic'] = {
			undo:function( param ) {
				undo_common( param, gc, 'head_1' );
			},
			redo:function(param){
				redo_common( param, gc, 'head_2' );
			}
		};
		cmdMap['route'] = {
			undo:function( param ) {
				undo_common( param, rc, 'head_1' );
			},
			redo:function(param){
				redo_common( param, rc, 'head_2' );
			}
		};

		cmdMap['top'] = {
				undo:function( param ) {
					undo_common( param, tc, 'head_1' );
				},
				redo:function(param){
					redo_common( param, tc, 'head_2' );
				}
			};

		cmdMap['pubmed'] = {
				undo:function( param ) {
					undo_common( param, mc, 'head_1' );
				},
				redo:function(param){
					redo_common( param, mc, 'head_2' );
				}
			};

		cmds.addHandler('base', cmdMap);
	}


	set_eventmap();

	change_lang(self.lang);

	createController('head_7');
	change_style('head_7');

});

