<?php
$test =false;

?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>TOXPILOT - Toxic process interpretable knowledge system</title>
<link rel="stylesheet" href="css/main.css" />
<link rel="stylesheet" href="css/simpletree.css" />
<link rel="stylesheet" href="css/tree.css" />

<link rel="stylesheet" href="css/tablesorter.css" />


<link rel="stylesheet" href="css/tipsy.css" />
<link rel="stylesheet" href="css/popupmenu.css" />
<link rel="stylesheet" href="css/context-menu.css" />

<link rel="stylesheet" href="css/tab.css" />
<link rel="stylesheet" href="css/jquery-ui.css" />


<link rel="stylesheet" href="css/split-pane.css" />
<link rel="stylesheet" href="css/dialog.css" />

<!-- api -->
<link rel="stylesheet" href="capi/css/draw.css" />
<link rel="stylesheet" href="capi/css/radar.css" />
<link rel="stylesheet" href="capi/css/info.css" />
<link rel="stylesheet" href="capi/css/search.css" />
<link rel="stylesheet" href="api-app/css/top.css?20191031" />
<link rel="stylesheet" href="api-app/css/course.css" />
<link rel="stylesheet" href="api-app/css/search.css" />
<link rel="stylesheet" href="api-app/css/result.css" />
<link rel="stylesheet" href="api-app/css/common.css" />

<?php
if ($test){
echo '<script> var test = true;</script>';
}

?>


<script type="text/javascript" src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-ui.min.js"></script>

<!-- d3 -->
<script type="text/javascript" src="js/d3.v4.min.js"></script>
<script type="text/javascript" src="js/dagre-d3.js?1"></script>
<script type="text/javascript" src="js/tipsy.js"></script>
<script type="text/javascript" src="js/download.js"></script>

<script type="text/javascript" src="js/context-menu.js"></script>


<!-- split  -->
<script type="text/javascript" src="js/split-pane.js"></script>

<!-- sortable table -->
<script type="text/javascript" src="js/jquery.tablesorter.min.js"></script>
<!-- header固定table -->
<script type="text/javascript" src="js/jquery.floatThead.min.js"></script>


<!-- tree lib (required by tree API) -->
<script type="text/javascript" src="js/treeData.js"></script>
<script type="text/javascript" src="js/treeLib.js"></script>
<script type="text/javascript" src="js/simpletreemenu.js"></script>
<!-- tox api  -->
<script type="text/javascript" src="capi/js/util.js"></script>
<script type="text/javascript" src="capi/js/apiAccessor.js"></script>
<script type="text/javascript" src="capi/js/command.js"></script>
<script type="text/javascript" src="capi/js/const.js"></script>
<script type="text/javascript" src="capi/js/search.js"></script>
<script type="text/javascript" src="capi/js/data.js"></script>
<script type="text/javascript" src="capi/js/process.js"></script>
<script type="text/javascript" src="capi/js/pubmed.js"></script>
<script type="text/javascript" src="capi/js/route.js"></script>
<script type="text/javascript" src="capi/js/view/tree.js"></script>
<script type="text/javascript" src="capi/js/view/info_common.js"></script>
<script type="text/javascript" src="capi/js/view/info_course.js"></script>
<script type="text/javascript" src="capi/js/view/info_process.js"></script>
<script type="text/javascript" src="capi/js/view/info_role.js"></script>
<script type="text/javascript" src="capi/js/view/info_annotation.js"></script>
<script type="text/javascript" src="capi/js/view/info_molecule.js"></script>
<script type="text/javascript" src="capi/js/view/info_siblings.js"></script>
<script type="text/javascript" src="capi/js/view/info_pubmed.js"></script>
<script type="text/javascript" src="capi/js/view/search.js"></script>
<script type="text/javascript" src="capi/js/view/result.js"></script>
<script type="text/javascript" src="capi/js/view/draw.js"></script>
<script type="text/javascript" src="capi/js/view/radar.js"></script>
<script type="text/javascript" src="capi/js/view/map.js"></script>
<script type="text/javascript" src="capi/js/view/route.js"></script>
<script type="text/javascript" src="capi/js/view/route_option.js"></script>
<script type="text/javascript" src="api-app/js/common.js"></script>
<script type="text/javascript" src="api-app/js/top-controller.js"></script>
<script type="text/javascript" src="api-app/js/course.js"></script>
<script type="text/javascript" src="api-app/js/course-controller.js"></script>
<script type="text/javascript" src="api-app/js/info-controller.js"></script>
<script type="text/javascript" src="api-app/js/generic.js"></script>
<script type="text/javascript" src="api-app/js/generic-controller.js"></script>
<script type="text/javascript" src="api-app/js/process.js"></script>
<script type="text/javascript" src="api-app/js/process-controller.js"></script>
<script type="text/javascript" src="api-app/js/route.js"></script>
<script type="text/javascript" src="api-app/js/route-controller.js"></script>
<script type="text/javascript" src="api-app/js/search-controller.js"></script>
<script type="text/javascript" src="api-app/js/all-controller.js?20191031"></script>
<script type="text/javascript" src="api-app/js/pubmed-controller.js?20191031"></script>
<script type="text/javascript" src="api-app/js/pminfo-controller.js"></script>

<script type="text/javascript" src="tab.js"></script>
<script type="text/javascript" src="main.js"></script>
</head>
<body>
<div class="head">
 <div class="head_link">
  <div id="lang_select">lang:<select class="uiparts_theme common_button"><option>ja</option><option>en</option></select></div>
  <div class="about">about</div>
  <div class="bioportal"><a href="http://www.obofoundry.org/ontology/txpo.html" target="_blank">TXPO(OBO-Foundry)</a></div>
  <div class="bioportal"><a href="http://bioportal.bioontology.org/ontologies/TXPO" target="_blank">TXPO(BioPortal)</a></div>
  <div class="github"><a href="https://github.com/txpo-ontology/TXPO" target="_blank">GitHub</a></div>
 </div>
 <div class="head_block">
  <div class="head_logo"><div><img class="icon" src="img/toxpilot_logo.svg"></div><div><h1>TOXPILOT</h1></div></div><div><div class="div_text_title"><h1><span class="text_title"></span></h1></div></div>
  <div class="head_logo2"><div><img class="icon" src="img/2_Flat_logo_on_transparent.svg"></div><div class="tooltip">Back to Top</div></div>
 </div>
</div>
<div class="main_body">
 <ul id="tab_head" class="tab_head"><li id="head_7"><span class="text_tab_7"></span></li><li id="head_2"><span class="text_tab_2"></span></li><li id="head_4"><span class="text_tab_4"></span></li><li id="head_6"><span class="text_tab_6"></span></li><li id="head_5"><span class="text_tab_5"></span></li><li id="head_3"><span class="text_tab_3"></span></li><li id="head_1"><span class="text_tab_1"></span><li id="head_8"><span class="text_tab_8"></span></li></ul>
 <div class="contents">
  <div id="body_1" class="body"></div>
  <div id="body_2" class="body fix"></div>
  <div id="body_3" class="body"></div>
  <div id="body_4" class="body"></div>
  <div id="body_5" class="body"></div>
  <div id="body_6" class="body"></div>
  <div id="body_7" class="body"></div>
  <div id="body_8" class="body"></div>
 </div>

</div>
  <div class="indicatorArea"><img src="img/loading.gif" alt="" class="indicator"></div>
  <?php
include_once "about.html"
?>
</body>
</html>
