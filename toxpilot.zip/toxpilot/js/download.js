/**
 *
 */


function downloadSVG(source) {

//    var doctype = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link rel="stylesheet" href="draw.css" /></head><div>';
    var doctype = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'+
    	'<style>\n'+
    	'.map_main_panel {\n'+
    	'	height:100%;\n'+
    	'}\n'+
    	'\n'+
    	'/* nodes */\n'+
    	'\n'+
    	'text {\n'+
    	'    font-weight: 300;\n'+
    	'    font-family:"Helvetica Neue", Helvetica, Arial, sans-serf;\n'+
    	'    font-size: 12px;\n'+
    	'}\n'+
    	'.node rect,\n'+
    	'.node circle {\n'+
    	'    stroke: #999;\n'+
    	'    fill: #fff;\n'+
    	'    stroke-width: 1.5px;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_participant circle{\n'+
    	'    stroke: #999;\n'+
    	'    fill: #ddf;\n'+
    	'    stroke-width: 1.5px;\n'+
    	'}\n'+
    	'\n'+
    	'.node {\n'+
    	'    cursor: pointer;\n'+
    	'}\n'+
    	'\n'+
    	'/* individual */\n'+
    	'\n'+
    	'\n'+
    	'.shape_unknown rect {\n'+
    	'	fill:#8df;\n'+
    	'}\n'+
    	'.shape_undefined rect {\n'+
    	'	fill:#8df;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.shape_root rect,\n'+
    	'.shape_root circle\n'+
    	' {\n'+
    	'    stroke: #999;\n'+
    	'	fill:#f44;\n'+
    	'    stroke-width: 1.5px;\n'+
    	'}\n'+
    	'.shape_result rect,\n'+
    	'.shape_result circle\n'+
    	' {\n'+
    	'	fill:#99f;\n'+
    	'}\n'+
    	'.shape_cause rect,\n'+
    	'.shape_cause circle {\n'+
    	'	fill:#3f3;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_mouse rect,\n'+
    	'.shape_mouse circle {\n'+
    	'	fill:#FD0;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_rat rect,\n'+
    	'.shape_rat circle {\n'+
    	'	fill:#FD0;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_mouse.shape_vitro rect,\n'+
    	'.shape_mouse.shape_vitro circle {\n'+
    	'	fill:#f94;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_rat.shape_vitro rect,\n'+
    	'.shape_rat.shape_vitro circle {\n'+
    	'	fill:#f94;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.shape_vivo rect,\n'+
    	'.shape_vivo circle {\n'+
    	'	fill:#FD0;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_vitro rect,\n'+
    	'.shape_vitro circle {\n'+
    	'	fill:#F00;\n'+
    	'}\n'+
    	'.shape_canonical rect,\n'+
    	'.shape_vitro_invalid circle,\n'+
    	'.shape_vivo_invalid circle,\n'+
    	'.shape_canonical circle {\n'+
    	'	fill:#fcc;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'\n'+
    	'.shape_node rect {\n'+
    	'	fill:#8df;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_part_process rect {\n'+
    	'	fill:#8df;\n'+
    	'}\n'+
    	'/*\n'+
    	'.shape_participant rect,\n'+
    	'.shape_participant circle\n'+
    	' {\n'+
    	'	fill:#ff7;\n'+
    	'}*/\n'+
    	'\n'+
    	'.shape_combine rect,\n'+
    	'.shape_combine circle {\n'+
    	'    stroke: #999;\n'+
    	'    stroke-width: 3.0px;\n'+
    	'/*    stroke-dasharray: 5,5;*/\n'+
    	'	fill:#00f;\n'+
    	'}\n'+
    	'\n'+
    	'.shape_notice rect,\n'+
    	'.shape_notice circle {\n'+
    	'	stroke:#f00;\n'+
    	'	stroke-width:5px;\n'+
    	'}\n'+
    	'\n'+
    	'.highlighted g.label {\n'+
    	'	background-image: url(../../img/bg-red.png);\n'+
    	'	fill:#ff0000;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'\n'+
    	'/* edges */\n'+
    	'\n'+
    	'.edgePath path {\n'+
    	'	fill:none;\n'+
    	'    stroke: #333;\n'+
    	'    stroke-width: 3px;\n'+
    	'	stroke-opacity:1.0;\n'+
    	'    cursor: pointer;\n'+
    	'}\n'+
    	'path.arrowhead{\n'+
    	'    fill: #333;\n'+
    	'	fill-opacity:0.9;\n'+
    	' }\n'+
    	'\n'+
    	'\n'+
    	'/* selected path */\n'+
    	'.edgePath path.path_selected {\n'+
    	'    stroke-width: 10px;\n'+
    	'    stroke: #FF0000;\n'+
    	'	stroke-opacity:1;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'\n'+
    	'/* part */\n'+
    	'.edge_has_part path,\n'+
    	'.edge_partOf path\n'+
    	' {\n'+
    	'	stroke: #00f;\n'+
    	'	stroke-dasharray: 3,3,15,3;\n'+
    	'}\n'+
    	'.edge_has_part path.arrowhead,\n'+
    	'.edge_partOf path.arrowhead\n'+
    	'{\n'+
    	'	fill: #00f;\n'+
    	'}\n'+
    	'\n'+
    	'/* result */\n'+
    	'.edge_hasResult path {\n'+
    	'	stroke: #000;\n'+
    	'}\n'+
    	'.edge_hasResult path.arrowhead\n'+
    	'{\n'+
    	'	fill: #000;\n'+
    	'}\n'+
    	'\n'+
    	'/* pathway */\n'+
    	'.edge_has_Pathway path,\n'+
    	'.edge_PathwayOf path\n'+
    	' {\n'+
    	'	stroke: #0ff;\n'+
    	'	stroke-dasharray: 3,3,15,3;\n'+
    	'}\n'+
    	'.edge_has_Pathway path.arrowhead,\n'+
    	'.edge_PathwayOf path.arrowhead\n'+
    	'{\n'+
    	'	fill: #0ff;\n'+
    	'}\n'+
    	'\n'+
    	'/* Molecular_reaction */\n'+
    	'.edge_has_Molecular_reaction path,\n'+
    	'.edge_Molecular_reactionwayOf path\n'+
    	' {\n'+
    	'	stroke: #f0f;\n'+
    	'	stroke-dasharray: 3,3,15,3;\n'+
    	'}\n'+
    	'.edge_has_Molecular_reaction path.arrowhead,\n'+
    	'.edge_Molecular_reactionOf path.arrowhead\n'+
    	'{\n'+
    	'	fill: #f0f;\n'+
    	'}\n'+
    	'\n'+
    	'/* hasParticipant */\n'+
    	'.edge_hasParticipant path\n'+
    	' {\n'+
    	'	stroke: #0f0;\n'+
    	'	stroke-linecap:round;\n'+
    	'	stroke-dasharray: 1,8;\n'+
    	'}\n'+
    	'.edge_hasParticipant path.arrowhead\n'+
    	'{\n'+
    	'	fill: #0f0;\n'+
    	'}\n'+
    	'\n'+
    	'/* hasAgent */\n'+
    	'.edge_hasAgent path\n'+
    	' {\n'+
    	'	stroke: #fd0;\n'+
    	'	stroke-linecap:round;\n'+
    	'	stroke-dasharray: 1,8;\n'+
    	'}\n'+
    	'.edge_hasAgent path.arrowhead\n'+
    	'{\n'+
    	'	fill: #fd0;\n'+
    	'}\n'+
    	'\n'+
    	'/* hasInput */\n'+
    	'.edge_hasInput path\n'+
    	' {\n'+
    	'	stroke: #00f;\n'+
    	'	stroke-linecap:round;\n'+
    	'	stroke-dasharray: 1,8;\n'+
    	'}\n'+
    	'.edge_hasInput path.arrowhead\n'+
    	'{\n'+
    	'	fill: #00f;\n'+
    	'}\n'+
    	'\n'+
    	'/* hasOutput */\n'+
    	'.edge_hasOutput path\n'+
    	' {\n'+
    	'	stroke: #f00;\n'+
    	'	stroke-linecap:round;\n'+
    	'	stroke-dasharray: 1,8;\n'+
    	'}\n'+
    	'.edge_hasOutput path.arrowhead\n'+
    	'{\n'+
    	'	fill: #f00;\n'+
    	'}\n'+
    	'\n'+
    	'path.arrowhead_none {\n'+
    	'	stroke:rgba(1,1,1,0) !important;\n'+
    	'	stroke-width:1 !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath path.dp_path   {\n'+
    	'/*	stroke-linecap: round;*/\n'+
    	'	stroke-linecap: unset;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_0 path.dp_path   {\n'+
    	'	stroke:#e3fdfd;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_1 path.dp_path   {\n'+
    	'	stroke:#cbf1f5;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_2 path.dp_path   {\n'+
    	'	stroke:#a6e3e9;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_3 path.dp_path   {\n'+
    	'	stroke:#71c9ce;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_4 path.dp_path   {\n'+
    	'	stroke:#81c1ef;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_5 path.dp_path {\n'+
    	'	stroke:#1fab89;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.edgePath path.arrowhead_none   {\n'+
    	'/*	d: path("M 9.35 4.68 L 9.35 5.32");*/\n'+
    	'	d: path("M 8.7 4.666 L 9.75 4.666 L 9.75 5.333 L8.7 5.333 L8.7 4.666");\n'+
    	'	stroke-linecap: round;\n'+
    	'	stroke-linejoin: round;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.edgePath.edge_depth_0 path.arrowhead_none   {\n'+
    	'	stroke:#e3fdfd !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_1 path.arrowhead_none   {\n'+
    	'	stroke:#cbf1f5 !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_2 path.arrowhead_none   {\n'+
    	'	stroke:#a6e3e9 !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_3 path.arrowhead_none   {\n'+
    	'	stroke:#71c9ce !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_4 path.arrowhead_none   {\n'+
    	'	stroke:#81c1ef !important;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_depth_5 path.arrowhead_none   {\n'+
    	'	stroke:#1fab89 !important;\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.edgePath.edge_width_0 path.dp_path   {\n'+
    	'	stroke:rgba(1,1,1,0);\n'+
    	'	stroke-width:0;\n'+
    	'	}\n'+
    	'\n'+
    	'.edgePath.edge_width_1 path.dp_path   {\n'+
    	'	stroke-width:80;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_width_2 path.dp_path   {\n'+
    	'	stroke-width:100;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_width_3 path.dp_path   {\n'+
    	'	stroke-width:120;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_width_4 path.dp_path   {\n'+
    	'	stroke-width:140;\n'+
    	'}\n'+
    	'\n'+
    	'.edgePath.edge_width_5 path.dp_path   {\n'+
    	'	stroke-width:160;\n'+
    	'}\n'+
    	'\n'+
    	'/* universal */\n'+
    	'.universal path {\n'+
    	'/*    stroke-width: 10px;*/\n'+
    	'	stroke: #ff0000\n'+
    	'\n'+
    	'}\n'+
    	'\n'+
    	'.line_color_f0 path {\n'+
    	'	stroke: #f39700\n'+
    	'}\n'+
    	'.line_color_f1 path {\n'+
    	'	stroke: #00a7db\n'+
    	'}\n'+
    	'.line_color_f2 path {\n'+
    	'	stroke: #009944\n'+
    	'}\n'+
    	'.line_color_f3 path {\n'+
    	'	stroke: #00ada9\n'+
    	'}\n'+
    	'.line_color_f4 path {\n'+
    	'	stroke: #522866\n'+
    	'}\n'+
    	'.line_color_f5 path {\n'+
    	'	stroke: #0078ba\n'+
    	'}\n'+
    	'.line_color_f6 path {\n'+
    	'	stroke: #e44d93\n'+
    	'}\n'+
    	'.line_color_f7 path {\n'+
    	'	stroke: #a9cc51\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.line_color_0 path {\n'+
    	'	stroke: #e60012\n'+
    	'}\n'+
    	'.line_color_1 path {\n'+
    	'	stroke: #9caeb7\n'+
    	'}\n'+
    	'.line_color_2 path {\n'+
    	'	stroke: #d7c447\n'+
    	'}\n'+
    	'.line_color_3 path {\n'+
    	'	stroke: #9b7cb6\n'+
    	'}\n'+
    	'.line_color_4 path {\n'+
    	'	stroke: #bb641d\n'+
    	'}\n'+
    	'.line_color_5 path {\n'+
    	'	stroke: #e85298\n'+
    	'}\n'+
    	'.line_color_6 path {\n'+
    	'	stroke: #6cbb5a\n'+
    	'}\n'+
    	'.line_color_7 path {\n'+
    	'	stroke: #b6007a\n'+
    	'}\n'+
    	'.line_color_8 path {\n'+
    	'	stroke: #019a66\n'+
    	'}\n'+
    	'.line_color_9 path {\n'+
    	'	stroke: #814721\n'+
    	'}\n'+
    	'\n'+
    	'.under_color_f0  {\n'+
    	'	background: linear-gradient(transparent 50%,  #f39700 70%);\n'+
    	'}\n'+
    	'.under_color_f1  {\n'+
    	'	background: linear-gradient(transparent 50%,  #00a7db 70%);\n'+
    	'}\n'+
    	'.under_color_f2  {\n'+
    	'	background: linear-gradient(transparent 50%,  #009944 70%);\n'+
    	'}\n'+
    	'.under_color_f3  {\n'+
    	'	background: linear-gradient(transparent 50%,  #00ada9 70%);\n'+
    	'}\n'+
    	'.under_color_f4  {\n'+
    	'	background: linear-gradient(transparent 50%,  #522866 70%);\n'+
    	'}\n'+
    	'.under_color_f5  {\n'+
    	'	background: linear-gradient(transparent 50%,  #0078ba 70%);\n'+
    	'}\n'+
    	'.under_color_f6  {\n'+
    	'	background: linear-gradient(transparent 50%,  #e44d93 70%);\n'+
    	'}\n'+
    	'.under_color_f7  {\n'+
    	'	background: linear-gradient(transparent 50%,  #a9cc51 70%);\n'+
    	'}\n'+
    	'\n'+
    	'\n'+
    	'.under_color_0  {\n'+
    	'	background: linear-gradient(transparent 50%,  #e60012 70%);\n'+
    	'}\n'+
    	'.under_color_1  {\n'+
    	'	background: linear-gradient(transparent 50%,  #9caeb7 70%);\n'+
    	'}\n'+
    	'.under_color_2  {\n'+
    	'	background: linear-gradient(transparent 50%,  #d7c447 70%);\n'+
    	'}\n'+
    	'.under_color_3  {\n'+
    	'	background: linear-gradient(transparent 50%,  #9b7cb6 70%);\n'+
    	'}\n'+
    	'.under_color_4  {\n'+
    	'	background: linear-gradient(transparent 50%,  #bb641d 70%);\n'+
    	'}\n'+
    	'.under_color_5  {\n'+
    	'	background: linear-gradient(transparent 50%,  #e85298 70%);\n'+
    	'}\n'+
    	'.under_color_6  {\n'+
    	'	background: linear-gradient(transparent 50%,  #6cbb5a 70%);\n'+
    	'}\n'+
    	'.under_color_7  {\n'+
    	'	background: linear-gradient(transparent 50%,  #b6007a 70%);\n'+
    	'}\n'+
    	'.under_color_8  {\n'+
    	'	background: linear-gradient(transparent 50%,  #019a66 70%);\n'+
    	'}\n'+
    	'.under_color_9  {\n'+
    	'	background: linear-gradient(transparent 50%,  #814721 70%);\n'+
    	'}\n' +
    	'</style></head><div>';
    var prefix = {
            xmlns: "http://www.w3.org/2000/xmlns/",
            xlink: "http://www.w3.org/1999/xlink",
            svg: "http://www.w3.org/2000/svg"
        }

    var filename = "chart.svg";
//    var svg = d3.select(source).select("svg")
    var svg = d3.select(source)
        .attr("xmlns", prefix.svg)
        .attr("version", "1.1")
        .node()

        var nodes = $(".node");
    var maxx = 0;
    var maxy = 0;
    for (var i in nodes){
    	if (isNaN(i)){
    		continue;
    	}
    	var node = nodes[i];
    	var trans = $(node).attr("transform");
	if (trans != null && trans.indexOf("translate(") == 0){
    		trans = trans.replace("translate(", "");
    		trans = trans.replace(")", "");
    		trans = trans.split(",");
    	} else {
    		continue;
    	}


    	if (trans.length > 0){
    		var x = trans[0]-0;
    		var y = trans[1]-0;
    		if (maxx < x){
    			maxx = x;
    		}
    		if (maxy < y){
    			maxy = y;
    		}
    	}
    }

    maxx = Math.ceil(maxx+400);
    maxy = Math.ceil(maxy+200);

	$(svg).attr("width", maxx);
	$(svg).attr("height", maxy);

	d3.select(source).select("g").attr("transform", "translate(100,100)");

	var str = (new XMLSerializer()).serializeToString(svg);

	str = str.replace(/url\(http:\/\/localhost\/([a-z_]*)\/#/g, 'url(#');

    var d3Object = new Blob([doctype +  str + "</div></html>"], { "type" : "text\/xml" })

    var dd = new Date();
    var fileName = "map_" + dd.getFullYear() + padding(dd.getMonth()+1, 2, "0") + padding(dd.getDate(), 2, "0") + "_" + padding(dd.getHours(), 2, "0") + padding(dd.getMinutes(), 2, "0") + padding(dd.getSeconds(), 2, "0");


    var bat = '"C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe" --headless --disable-gpu --screenshot="%~dp0\\' + fileName +'.png" --window-size=' + maxx + ',' + maxy + ' --hide-scrollbars %~dp0\\' + fileName +'.html';
    var batObject = new Blob([bat], { "type" : "text" })


    download(d3Object, fileName + ".html");

    download(batObject, fileName + ".bat");

    function download(bo, file){
        var url = window.URL.createObjectURL(bo)
        var a = d3.select("body").append("a")



        a.attr("class", "downloadLink")
            .attr("download", file)
            .attr("href", url)
            .text("test")
            .style("display", "none")

            a.node().click()

        setTimeout(function() {
          window.URL.revokeObjectURL(url)
          a.remove()
        }, 10)
    }

    function padding(n, d, p){
    	p = p || '0';
    	return (p.repeat(d)+n).slice(-d);
    }
}
