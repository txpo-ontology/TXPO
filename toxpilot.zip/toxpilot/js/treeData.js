/**
 *
 */

var TreeData = function(idhead, initOpen){
	this.idhead = idhead;
	if (initOpen == null){
		initOpen = true;
	}
	this.initOpen = initOpen;
	this.clean();
};

TreeData.prototype.clean = function(){
	this.treeData = {};
	this.rootNode = undefined;
	this.labelList = {};
	this.resourceList = {};
	this.currentid = 0;

};

/**
 * 自ノードデータに子ノードデータを追加する
 * @param myID
 * @param childID
 */
TreeData.prototype.addSubClass = function(myID, childID, pupdate, update, type){
	var myNode = this.getNodeJson(myID, pupdate);

	if (this.rootNode == null){
		this.rootNode = myNode;
	}

	if (childID != null){
		var childNode = this.getNodeJson(childID, update, type);
		this.addChildren(myNode, childNode);
	}
};

/**
 * 自ノードデータの親を設定する
 * @param myID		自ノードID
 * @param parentID	親ノードID
 */
TreeData.prototype.setSuperClass = function(myID, parentID){
	var myNode = this.getNodeJson(myID);

	var parentNode = this.getNodeJson(parentID);

	if (this.rootNode == null){
		this.rootNode = parentNode;
	}


	if (this.rootNode == myNode){
		this.rootNode = parentNode;
	}

	this.addChildren(parentNode, myNode);


};

/**
 * ノードIDからノードを取得・生成する。
 * @param node
 * @returns {___anonymous1517_1574}
 */
TreeData.prototype.getNodeJson = function(id, update, type){


	var ret = this.treeData[id];
	if (ret != null && update){
		ret.name = this.labelList[id];
	}
	if (ret == undefined){
		ret = {'name' : this.labelList[id], 'id' : id, 'resource' : this.resourceList[id], 'open' : this.initOpen, 'type': type, 'children' : []}; // データ形式はどうにかする
		this.treeData[id] = ret;
	}

	return ret;
};

/**
 *
 * @param label
 * @returns {String}
 */
TreeData.prototype.createNodeID = function(label, res){
	var ret = this.idhead + '_' + (++this.currentid);
	this.labelList[ret] = label;
	this.resourceList[ret] = res;

	return ret;
};

/**
 * ラベルから、それに該当するノードIDを返す
 * @param label
 * @param create
 * @returns
 */
TreeData.prototype.getNodeID = function(label, res, create, updateLabel, type){
	var ret = null;

	var workRes = res;

	if (res != null && type != null){
		workRes = workRes + "$" + type;
	}

	for (var key in this.labelList){
		if (workRes != null && this.resourceList[key] == workRes){
			if (ret == null){
				ret = key;
			} else {
				if (!(ret instanceof Array)){
					var tmp = [];
					tmp.push(ret);
					ret = tmp;
				}
				ret.push(key);
			}
		}
		if (workRes == null && label != null && this.labelList[key] == label){
			ret = key;
			break;
		}
	}
	if (ret != null && updateLabel){
		this.labelList[ret] = label;
	}

	if (ret == null && create){
		ret = this.createNodeID(label, workRes);
	}

	return ret;
};

TreeData.prototype.addChildren = function(parent, child){

	child.parent = parent;
	if (parent.children.indexOf(child) < 0){
		// 親に子が追加済みでなければ追加
		parent.children.push(child);
	}
};


TreeData.prototype.setRoot = function(root){
	if (root != null){
		this.rootNode = this.getNodeJson(root);
		return;
	}
	var roots = [];
	// rootを探索
	var children = [];
	for (var i in this.treeData){
		var datum = this.treeData[i];
		for (var j in datum.children){
			if (children.indexOf(datum.children[j].resource) < 0){
				children.push(datum.children[j].resource);
			}
		}
	}
	for (var i in this.treeData){
		var datum = this.treeData[i];
		if (children.indexOf(datum.resource) < 0){
//			this.rootNode = datum;
//			break;
			roots.push(datum.id);
		}
	}

	root = this.getNodeID('root', 'root', true, false);
	for (var i in roots){
		this.setSuperClass(roots[i], root);
	}
	this.rootNode =  this.getNodeJson(root);
}


/**
 * 指定ノードをオープン/クローズする
 * 親が閉じている場合は再帰的に開く
 * @param node
 * @param isOpen
 */
TreeData.prototype.open = function(id, isOpen, nodes){
	// 循環を防ぐ
	if (nodes == null){
		nodes = [];
	}
	if (nodes[id] != null){
		return;
	}

	nodes[id] = isOpen;

	if (isOpen == undefined){
		isOpen = true;
	}
	this.treeData[id].open = isOpen;

	if (isOpen){
		// 開く場合のみ再帰的に開く
		var parent = this.treeData[id].parent;

		if (parent != null){
			this.open(parent.id, isOpen, nodes);
		}
	}

};

/**
 * 全ノードをオープン/クローズする
 * @param node
 * @param isOpen
 */
TreeData.prototype.openAll = function(isOpen){

	for (var key in this.treeData){
		this.treeData[key].open = isOpen;
	}

};


/**
 * 指定したノードをハイライト/ハイライト解除する
 * @param node
 * @param isHighlight
 */
TreeData.prototype.highlight = function(id, isHighlight){
	if (isHighlight == undefined){
		isHighlight = true;
	}
	this.treeData[id].highlight = isHighlight;

	if (isHighlight){
		this.open(id);
	}

};

/**
 * ハイライトを全解除する
 */
TreeData.prototype.highlightClear = function(){
	for (var id in this.treeData){
		this.treeData[id].highlight = false;
	}
};


