/**
 *
 */

function viewTree(treeId, treeData, cb, isList){
	var node;
	node = treeData.rootNode;
	if (node == null){
		return;
	}

	cleanTree(treeId); // データクリア

	drawTree(node, null, node.id, treeId);

	ddtreemenu.createTree("tree_root_"+treeId, true, 5, cb, openCloseCB, isList);


	function openCloseCB(id, isOpen){
		treeData.treeData[id].open = isOpen;
	}
};

function openNode(treeId, treeData, nodeId){
	var subId = nodeId;

	treeData.treeData[nodeId]

	var ul = $('#'+nodeId).parent()[0];

	ddtreemenu.expandSubTree("tree_root_"+treeId, ul);
}

function drawTree(node, pid, id, treeId, depth){
	if (depth == null){
		depth = 0;
	}

	if (pid == null){
		pid = 'tree_root_'+treeId;
	}

	var sid = id + '_span';
	if ($('#' +sid).length > 0){
		// 既に追加済み
		return;
	}
	$('#'+pid).append(
			$('<li><span id="' + sid + '">' + getLabelFromResource(node.name)+'</span></li>')
			.attr({
				'id': id
			})
			);
	if (node.highlight){
		$('#'+sid).addClass('highlight');
	}
	if (node.type){
		$('#'+sid).addClass(node.type);
	}
	if (node.children.length > 0){
		$('#'+id).append(
				$('<ul></ul>')
				.attr({
					'id': id+'_ul',
					'rel': node.open ? 'open' : 'closed'
				})
				);
		for (var i=0; i<node.children.length; i++){
			drawTree(node.children[i], id+'_ul', node.children[i].id, treeId, depth+1);
		}

	}

}

function clearClassNode(base_id, clazz, value){
	$('#'+base_id + ' .treeview li span').removeClass(clazz);
}

function setClassToNode(nid, clazz, value){
	if (value == null){
		value = true;
	}
	if (value){
		$('#'+nid + '_span').addClass(clazz);
	} else {
		$('#'+nid + '_span').removeClass(clazz);
	}

}

function cleanTree(treeId){
	$('#' + treeId).html('<ul id="tree_root_' + treeId + '" class="treeview" rel="open"></ul>'); // データクリア
}

function getLabelFromResource(res){
	if (res == null){
		return '';
	}
	var index = res.indexOf('#');
	var ret = res;
	if (index >= 0){
		ret = res.substring(index+1);
	}
	return escapeHtml(ret);
}

function escapeHtml(str){
	  str = str.replace(/&/g, '&amp;');
	  str = str.replace(/>/g, '&gt;');
	  str = str.replace(/</g, '&lt;');
	  str = str.replace(/"/g, '&quot;');
	  str = str.replace(/'/g, '&#x27;');
	  str = str.replace(/`/g, '&#x60;');
	  return str;
	}

