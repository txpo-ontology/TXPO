<?php
// GET処理分岐用



$cmds = [
	['pathes'=>['about'], 'file'=>'get_about.php'],
	['pathes'=>['data', 'tree','course'], 'file'=>'get_data_tree_course.php'],
	['pathes'=>['data', 'tree','process', '{option}'], 'file'=>'get_data_tree_process.php'],
	['pathes'=>['data', 'tree','molecule'], 'file'=>'get_data_tree_molecule.php'],
	['pathes'=>['data', 'tree','role'], 'file'=>'get_data_tree_role.php'],
	['pathes'=>['data', 'tree','finding'], 'file'=>'get_data_tree_finding.php'],
	['pathes'=>['data', 'tree','structure'], 'file'=>'get_data_tree_structure.php'],
	['pathes'=>['data', 'tree'], 'file'=>'get_data_tree.php'],
//	['pathes'=>['data', 'map','{id}', '{relation}'], 'file'=>'get_map_relations.php'],
	['pathes'=>['data', 'map','type'], 'file'=>'get_map_type.php'],
//	['pathes'=>['data', 'map','course','{id}','test', '{type}','{abnormal_id}'], 'file'=>'get_map_course_tree.php'],
	['pathes'=>['data', 'map','course','{id}','{type}','{abnormal_id}'], 'file'=>'get_map_course_tree.php'],
	['pathes'=>['data', 'map','process','{id}','{type}','{abnormal_id}'], 'file'=>'get_map_process.php'],
	['pathes'=>['data', 'map','oneroute','{id}','{find_type}','{direction}','{depth}'], 'file'=>'get_map_oneroute.php'],
	//	['pathes'=>['data', 'map','generic','{id}','{type}','{abnormal_id}'], 'file'=>'get_map_generic.php'],
	['pathes'=>['data', 'map','chain','{id}','{type}','{abnormal_id}'], 'file'=>'get_map_chain.php'],
	['pathes'=>['data', 'map','all','{type}','{abnormal_id}'], 'file'=>'get_map_chain.php'],
	['pathes'=>['data', 'concept','parent', '{id}'], 'file'=>'get_data_concept_parent.php'],
	['pathes'=>['data', 'concept','siblings', '{id}'], 'file'=>'get_data_concept_siblings.php'],
	['pathes'=>['data', 'concept','{id}','type'], 'file'=>'get_data_concept_type.php'],
	['pathes'=>['data', 'process','{id}','course'], 'file'=>'get_data_process_course.php'],
	['pathes'=>['data', 'concept','{id}','relation'], 'file'=>'get_data_process_relation.php'],
	['pathes'=>['data', 'concept','{id}','natlang'], 'file'=>'get_data_process_natlang.php'],
	['pathes'=>['data', 'concept','{id}','{mapping}'], 'file'=>'get_data_concept.php'],
	['pathes'=>['data', 'process','{id}','natlang'], 'file'=>'get_data_process_natlang.php'],
	['pathes'=>['data', 'gene','course', '{id}'], 'file'=>'get_data_gene_course.php'],
	['pathes'=>['data', 'pubmed', '{id}' , '{opt}'], 'file'=>'get_data_pubmed.php'],

	['pathes'=>['search'], 'file'=>'get_search.php'],
];

// 有効なバージョン一覧
$valid_vers = array();

preg_match('|' . dirname($_SERVER['SCRIPT_NAME']) . '/([\w%,\./\[\]:]*)|', $_SERVER['REQUEST_URI'], $matches);
$pathes = explode('/', $matches[1]);
$size = count($pathes);

$ver = isset($pathes[0]) ? htmlspecialchars($pathes[0]) : null;


foreach (glob($lib_dir . '/*') as $file){
	if (is_file($file . '/' . $valid_filename)){
		$valid_vers[] = basename($file);
	}
}

if ($ver == '' && $size == 1){
	// 利用可能バージョン
	echo json_encode($valid_vers);
	exit();
}

if (!file_exists($lib_dir .'/'. $ver . '/' . $valid_filename)){
	// TODO バージョン不一致エラー
	echo 'no such version:'.$ver;
	exit();
}

include ($lib_dir .'/'. $ver . '/' . $valid_filename);


$lang = isset($pathes[1]) ? htmlspecialchars($pathes[1]) : null;

if ($lang == '' && $size == 2){
	// 利用可能バージョン
	echo json_encode($valid_langs);
	exit();
}

if (!(in_array($lang, $valid_langs))){
	// TODO 言語不一致エラー
	echo 'no such lang:'.$lang;
	exit();
}

if ($lang == 'en'){
	$lang = '';
}

$output = implode(':', $pathes);

if (count($pathes) < 3){
	// TODO コマンド未指定
	echo 'no command';
	exit();
}


// argsに埋め込みパラメータが格納される
$args = [];

foreach ($cmds as $cmd){
//	if (count($cmd['pathes']) == (count($pathes)-2)){
		$i = 2;
		$hit = true;
		foreach ($cmd['pathes'] as $path){
			if (preg_match("/^\{(.*)\}$/u", $path, $result) == 1){
				if (count($pathes) > $i){
					$args[$result[1]] = $pathes[$i];
				}
			} else {
				if (count($pathes) > $i){
					if ($path != $pathes[$i]){
						$hit = false;
						break;
					}
				} else {
					$hit = false;
					break;
				}
			}
			$i++;
		}
		if ($hit){
			include ($lib_dir .'/'. $ver . '/' . ($cmd['file']));
			exit();
		}
//	}

}


echo ($method . ":" . $output . ":". count($pathes));





?>