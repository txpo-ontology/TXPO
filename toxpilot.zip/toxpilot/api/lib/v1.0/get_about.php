<?php
// 作用機序マップデータ取得用

include_once "http_get.php";


$query =
"PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX dc: <http://purl.org/dc/elements/1.1/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>

select ?license ?creator ?ver ?comment ?description{
  ?s owl:versionInfo ?ver;
                               dc:creator ?creator;
                               dc:license ?license.
  		optional {
  ?s dc:description ?description.
  		}
  		optional {
  ?s rdfs:comment ?comment.
  FILTER(lang(?comment) = '" . $lang . "')
}


}";
//echo $query;

header("Content-Type: application/sparql-results+json;charset=UTF-8");
$http = new Http();
echo json_encode($http->get($query));


?>