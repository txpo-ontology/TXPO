<?php
// プロセスマップデータ取得用

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";
include_once "get_data_process_course_lib.php";
include_once "get_data_gene_course_lib.php";

//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test
if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$type_id = null;
if (array_key_exists('type', $args)){
	$type_id = $args['type'];
}
if ($type_id == null || $type_id == ''){
	$type_id = 'rp';
}

$type = [];

foreach ($type_map as $key => $value){
	if (strpos($type_id, $key) !== false){
		$type[] = $value['id'];
	}
}

//$type = ['hasResult', 'has_part'];



$http = new Http();

/*
// プロセスが属する作用機序の取得
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
"select distinct ?base ?label{
  ?base (rdfs:subClassOf/owl:someValuesFrom)+ <" . $id .">;
   rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] .">;
   rdfs:label ?label.
} order by (?base)";

$tmp = $http->get($query);
*/
$tmp = get_process_course($id, $lang, $const);
//echo $query;
//echo "\n------\n";


// コアプロセスは自分自身
$cores = array();
$cores[] = $id;

//$base = null;
$bases = [];
foreach ($tmp as $mecha){
//	$base = $mecha['base']['value'];
	$bases[] = $mecha['id'];
	$bases = array_values(array_unique($bases));
//	break;
}

$gene_map = array();

if (count($bases) > 0){
//	$tmp_processes = get_gene_course($bases[0], $lang, $const);
	$tmp_processes = get_gene_course(null, $lang, $const);

	foreach ($tmp_processes as $process){
		foreach ($process['gene'] as $gene){
			$gene_type = '';
			foreach ($gene['being'] as $being){
				if (isset($being['t']) && strpos($gene_type, $being['t']) === false){
					$gene_type .= $being['t'].' ';
				}
			}
			foreach ($gene['assay'] as $assay){
				if (isset($assay['t']) && strpos($gene_type, $assay['t']) === false){
					$gene_type .= $assay['t'].' ';
				}
			}
			$gene_type = trim($gene_type);
			if ($gene_type == ''){
				$gene_type  ="canonical";
			}
			$gene_map[$gene['id']] = $gene_type;
		}
	}
}


// 自身のis-a
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct  ?parent ?plabel ?child ?clabel {\n".
"<" . $id . "> rdfs:subClassOf+ ?parent.\n".
"?parent rdfs:label ?plabel.\n".
"  ?child rdfs:subClassOf ?parent;\n".
"  rdfs:label ?clabel.\n".
"{\n".
"?parent rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.\n".
"} union {\n".
"?parent rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
"} \n".

"FILTER (lang(?plabel) = '" . $lang ."')\n".
"FILTER (lang(?clabel) = '" . $lang ."')\n".
"} ORDER BY lang(?plabel)";

$tmp = $http->get($query);

//echo $query;
//echo "\n------\n";

//child -> parent の関連を再帰的に取得

function get_isa($child, $arry, $ret, $depth){
	if ($ret == null){
		$ret = [];
	}
	if ($depth == 4){ // (depth +1)
		return $ret;
	}

	$cands = [];

	foreach($arry as $value){
		if ($value['child']['value'] == $child){
			/*
			$ret[] = ['parent'=>$value['parent']['value'], 'child'=>$value['child']['value'], 'clabel'=>$value['clabel']['value']];
			$parent = $value['parent']['value'];


			return get_isa($parent, $arry, $ret, $depth+1);
			*/
			if (!in_array($value['parent']['value'], $cands)){
				$cands[] = ['p'=>$value['parent']['value'], 'l'=>$value['clabel']['value']];
			}
		}
	}
	foreach ($cands as &$cand){
		$cnt = 0;
		foreach($arry as $val){
			if ($val['parent']['value'] == $cand['p']){
				$cnt++;
			}
		}
		$cand['cnt'] = $cnt;
	}


	// 親が複数ある時、親の登場する回数が少ない順に並べて最初に登場したものを親とする
	// （複数ある時は汎化した親である可能性が高いため）
	$tmp = [];
	foreach ($cands as $key=>$value){
		$tmp[$key] = $value['cnt'];
	}
	array_multisort($tmp, SORT_ASC, $cands);
	foreach ($cands as $cand){
		if ($cand['cnt'] > 0){
			$ret[] = ['parent'=>$cand['p'], 'child'=>$child, 'clabel'=>$cand['l']];
			$parent = $cand['p'];
			return get_isa($parent, $arry, $ret, $depth+1);
		}
	}


	return $ret;
}
$isa = get_isa($id, $tmp, null, 0);


// TODO 自身の兄弟
// （ is-aではなくanother-partにて関連している兄弟を取得）
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ?parent ?plabel ?sibling ?slabel{\n".
"{\n".
"?parent rdfs:subClassOf ?n;\n".
" rdfs:label ?plabel.\n".
"?n owl:someValuesFrom <" . $id .">;\n".
" owl:onProperty <" . $const['DATA_HAS_PART'] .">.\n".
"FILTER (lang(?plabel) = '" . $lang . "')\n".
"MINUS {?parent rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.}\n".
"} optional {\n".
"?parent rdfs:subClassOf ?sc.\n".
"FILTER (isBlank(?sc))\n".
"?sc owl:onProperty <" . $const['DATA_HAS_PART'] . ">;\n".
" owl:someValuesFrom ?sibling.\n".
"?sibling rdfs:label ?slabel.\n".
"FILTER (lang(?slabel) = '" . $lang . "')\n".
"}\n".
"} ORDER BY lang(?plabel)";
$siblings = $http->get($query);

//echo $query;
//echo "\n------\n";

// 属する作用機序に所属するノードと関連を取得
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ?parent ?process ?label ?rtype ?relation ?rlabel\n".
"{\n".
"{\n".
"{<" . implode(">  (rdfs:subClassOf/(owl:someValuesFrom|owl:allValuesFrom))+ ?process.}\n union {<", $bases).
">  (rdfs:subClassOf/(owl:someValuesFrom|owl:allValuesFrom))+ ?process.}\n".
" ?process rdfs:subClassOf+ <" . $const['DATA_PRIMITIVE_PROCESS'] .">;\n".
" rdfs:label ?label;\n".
" rdfs:subClassOf ?parent.\n".
" FILTER (lang(?label) = '" . $lang . "')\n".
" FILTER (isIri(?parent))\n".
/*
"<" . $base . "> (rdfs:subClassOf/owl:someValuesFrom)+ ?process;\n".
" rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] .">.\n".
*/

"} optional {\n".
"{\n".
"?process rdfs:subClassOf ?n.\n".
" ?n owl:onProperty ?rtype;\n".
" (owl:someValuesFrom|owl:allValuesFrom) ?relation.\n".
"   filter not exists {
        ?relation rdfs:subClassOf+ <" . $const['DATA_ANATOMICAL_ENTITY'] . ">.
    }".
"?relation rdfs:label ?rlabel.\n".
" FILTER (lang(?rlabel) = '" . $lang . "')\n".
" FILTER (isBlank(?n))\n".
"}\n".
"}\n".
"} order by (lang(?label))";

//echo $query;

$data = $http->get($query);

$ret = array();
$ret['concepts'] = array();
$ret['relations'] = array();

// concepts / relations
// conceptsにはid,parent,label情報
// relationsにはfrom-to, label, series情報


$relations = array();


// is-aを設定


if (in_array($type_map['s']['id'], $type)){
	foreach ($isa as $datum){
		$relations[] = ['f'=>$datum['parent'], 't'=>$datum['child'], 'l'=>$type_map['s']['l']];

		// is-aは普通に含める（パラメータによる）
		$ret['concepts'][] = ['p'=>$datum['parent'], 'id'=>$datum['child'], 'l'=>$datum['clabel']];
	}
	array_pop($relations); // 最後の親は削除
}


// まずはrelationを抽出
foreach ($data as $datum){
	if (array_key_exists('rtype', $datum) && in_array($datum['rtype']['value'], $type)){
//		$relations[] = ['f'=>$datum['process']['value'], 't'=>$datum['relation']['value'], 'l'=>$datum['tlabel']['value'], "s"=>$id];
		$relations[] = ['f'=>$datum['process']['value'], 't'=>$datum['relation']['value'], 'l'=>$const_label[$datum['rtype']['value']]];
	}
}

// TODO
// baseプロセスから、上位のみ・下位のみに探索したrelationのみを残す（引数による）

function get_oneway($base, $src_list, &$dst_list, $dir_dst){
	$dir_src = 'f';
	if ($dir_dst == 'f'){
		$dir_src = 't';
	}
	foreach ($src_list as $rel){

//echo($rel[$dir_src] . "==" . $base . "?<br>");
		if ($rel[$dir_src] == $base){
			if (!contains($dst_list, $rel)){
				$dst_list[] = $rel;
				get_oneway($rel[$dir_dst], $src_list, $dst_list, $dir_dst);
			}
		}
	}
}

function contains(&$arry, $obj){
	$obj = json_encode($obj);
	foreach ($arry as $o){
		if (json_encode($o) == $obj){
			return true;
		}
	}
	return false;
}


function get_non_relations($src_list, &$dst_list){
	// TODO from側が既存の関連プロセスに含まれる場合のみ追加する
	foreach ($src_list as $rel){
		if (!is_dir_relation($rel, $dst_list)){
			if (!contains($dst_list, $rel)){
				$dst_list[] = $rel;
			}
		}
	}
}

// 方向性を問われる関連か
function is_dir_relation($rel, &$list){
	global $type_map;
	$type = $rel['l'];

	if ($type == $type_map['s']['l'] ||
		$type == $type_map['r']['l'] ||
		$type == $type_map['p']['l'] ||
		$type == $type_map['m']['l'] ||
		$type == $type_map['w']['l']){
		return true;
	} else {
		// from側が既存の関連プロセスに含まれる場合は例外
		foreach ($list as $tmp){
			if ($tmp['f'] == $rel['f'] || $tmp['t'] == $rel['f']){
				return false;
			}
		}
		return true;
	}
	return false;
}

$tmp_relations = [];
get_oneway($id, $relations, $tmp_relations, 'f');
get_oneway($id, $relations, $tmp_relations, 't');

// 同じ分子に複数のプロセスが関連していた場合、それも拾ってしまうのでとりあえずコメントアウト
 get_non_relations($relations, $tmp_relations);

$relations = $tmp_relations;

// 向きにかかわらず兄弟は設定
foreach ($siblings as $datum){
	$relations[] = ['f'=>$datum['parent']['value'], 't'=>$datum['sibling']['value'], 'l'=>'has_part'];

	$ret['concepts'][] = ['p'=>null, 'id'=>$datum['sibling']['value'], 'l'=>$datum['slabel']['value']];
	$ret['concepts'][] = ['p'=>null, 'id'=>$datum['parent']['value'], 'l'=>$datum['plabel']['value']];
}


$relation_groups = [];

// relationをグループにまとめる
foreach ($relations as $relation){
	$group = null;
	$group_f = null;
	$group_t = null;
	$index_f;
	$index_t;
//	echo('f:'.$relation['f']. " t:".$relation['t']."\n");
	foreach ($relation_groups as $relation_group){
		if (in_array($relation['f'], $relation_group)){
			$index_f = array_search($relation_group, $relation_groups);
			$group_f = $relation_group;
			break;
		}
	}
	foreach ($relation_groups as $relation_group){
		if (in_array($relation['t'], $relation_group)){
			$index_t = array_search($relation_group, $relation_groups);
			$group_t = $relation_group;
			break;
		}
	}
	if ($group_f == null && $group_t == null){
		$group = [];
	}
	if ($group_f == null && $group_t != null){
		$group = $group_t;
	}
	if ($group_f != null && $group_t == null){
		$group = $group_f;
	}
	if ($group_f != null && $group_t != null){
		if ($index_f == $index_t){
			$group = $group_f;
		} else {
			if ($index_f > $index_t){
				array_splice($relation_groups, $index_f,1);
				array_splice($relation_groups, $index_t,1);
			} else {
				array_splice($relation_groups, $index_t,1);
				array_splice($relation_groups, $index_f,1);
			}
			$relation_groups = array_values($relation_groups);
			$group = array_unique(array_merge($group_f, $group_t));
		}
	}
	if (!in_array($relation['f'], $group)){
		$group[] = $relation['f'];
	}
	if (!in_array($relation['t'], $group)){
		$group[] = $relation['t'];
	}
	if (!in_array($group, $relation_groups)){
		$relation_groups[] = $group;
	}
}
//var_dump($relation_groups);


// 有効な関連ノードを抽出
$valid_relation = [];
foreach ($relation_groups as $relation_group){
	$hit = false;
	foreach ($relation_group as $relation){
		if (in_array($relation, $cores)){
			$hit = true;
			break;
		}
	}
	if ($hit){
		$valid_relation = array_merge($valid_relation, $relation_group);
	}
}


// コアノードに関連しないrelationsは結果に含めない
foreach ($relations as $relation){
	if (in_array($relation['f'], $valid_relation) || in_array($relation['t'], $valid_relation)){
		$ret['relations'][] = $relation;
	}
}


$tmp = [];
// relationに登場しないノードは結果に含めない
foreach ($data as $datum){

	$s = $datum['process']['value'];
	$hit = false;

	$val = ['p'=>$datum['parent']['value'], 'id'=>$datum['process']['value'], 'l'=>$datum['label']['value']];

	if (!in_array($val, $ret['concepts'])){
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}
	}

	if ($hit && !in_array($datum['process']['value'], $tmp)){
		$tmp_type = null;
		if (isset($gene_map[$datum['process']['value']])){
			$tmp_type = $gene_map[$datum['process']['value']];
		}
		$ret['concepts'][] = ['p'=>$datum['parent']['value'], 'id'=>$datum['process']['value'], 'l'=>$datum['label']['value'], 't'=>$tmp_type];

		if (isset($gene_map[$datum['process']['value']])){
			$concept['t'] = $gene_map[$datum['process']['value']];
		}


		$tmp[] = $datum['process']['value'];
	}

	if (isset($datum['relation'])){
		$s = $datum['relation']['value'];
		$hit = false;
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}

		if ($hit && !in_array($datum['relation']['value'], $tmp)){
			$concept = ['p'=>null, 'id'=>$datum['relation']['value'], 'l'=>$datum['rlabel']['value']];
			if (isset($gene_map[$datum['relation']['value']])){
				$concept['t'] = $gene_map[$datum['relation']['value']];
			}
			$ret['concepts'][] = $concept;
			$tmp[] = $datum['relation']['value'];
		}
	}
}


$ret['result'] = true;
$ret['id'] = $id;

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>