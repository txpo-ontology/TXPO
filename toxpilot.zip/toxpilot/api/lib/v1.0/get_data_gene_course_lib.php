<?php
// 作用機序が持つプロセスの遺伝子情報取得用

include_once "http_get.php";
include_once "get_util.php";

ini_set('xdebug.var_display_max_depth', -1);


function get_gene_course($id, $lang, $const){


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);


$http = new Http();

$reltypes = [$const['DATA_HAS_PARTICIPANT'],$const['DATA_HAS_INPUT'],$const['DATA_HAS_OUTPUT'],$const['DATA_HAS_AGENT']];

// geneプロセスの取得
$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?p ?id ?l ?gene ?gl ?role ?rl ?assay ?al ?atype ?ptype ?being ?mtype {";

if ($id != null){
	$query .= "
	<" . $id . "> (rdfs:subClassOf/owl:someValuesFrom)+ ?id;
	rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.
";
}

$query .= "
	?id rdfs:subClassOf+ <" . $const['DATA_PRIMITIVE_PROCESS'] . ">;
	 rdfs:subClassOf ?p;
	 rdfs:label ?l.
	FILTER (lang(?l) = '" . $lang . "')
	FILTER (isIri(?p))
	?id rdfs:subClassOf ?n.
	{
		?n owl:onProperty <" .
	implode(">.\n\t} union {\n\t\t?n owl:onProperty <" , $reltypes).">.
	}
	?n (owl:someValuesFrom | owl:allValuesFrom) ?gene.
	?gene rdfs:subClassOf* <". $const['DATA_COMPOUND'] . ">;
	 rdfs:label ?gl.
	FILTER (lang(?gl) = '" . $lang . "')
	FILTER (isBlank(?n))
	optional {
		?gene rdfs:subClassOf* ?gprnt1.
		?gprnt1 rdfs:subClassOf ?rn1.
		?rn1 owl:onProperty <" . $const['DATA_HAS_RELATED_ASSAY'] . ">;
		(owl:someValuesFrom | owl:allValuesFrom) ?assay.
		?assay rdfs:label ?al.
		FILTER(regex(?al, '^in '))
		FILTER(lang(?al) = '" . $lang . "')
		optional{
			?assay rdfs:subClassOf* <" . $const['DATA_IN_VIVO'] . ">.
			bind('vivo' as ?atype)
		}
		optional{
			?assay rdfs:subClassOf* <" . $const['DATA_IN_VITRO'] . ">.
			bind('vitro' as ?atype)
		}
	}
	optional {
		?gene rdfs:subClassOf* ?gprnt3.
		?gprnt3 rdfs:subClassOf ?rn3.
		?rn3 owl:onProperty <" . $const['DATA_HAS_QUARITY'] . ">;
		(owl:someValuesFrom | owl:allValuesFrom) ?quarity.
		?quarity rdfs:subClassOf* <" . $const['DATA_QUARITY_PREDICTED'] . ">.
		bind('predicted' as ?ptype)
	}
	optional{
		?gene rdfs:subClassOf* ?gprnt2.
		?gprnt2 rdfs:subClassOf ?rn2.
		?rn2 owl:onProperty <" . $const['DATA_INHERES_IN'] . ">;
			owl:someValuesFrom ?being.
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_MOUSE'] . ">.
			bind('mouse' as ?mtype)
		}
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_RAT'] . ">.
			bind('rat' as ?mtype)
		}
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_HUMAN'] . ">.
			bind('human' as ?mtype)
		}
	}


	optional {
		?gene rdfs:subClassOf ?rn2.
		?rn2 owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;
			owl:someValuesFrom ?role.
		?role rdfs:label ?rl.
		FILTER(lang(?rl) = '" . $lang . "')
	}
} order by ?id";


//echo $query;

$data = $http->get($query);

$processes = array();

$dic = array();

foreach($data as $datum){
	if (isset($processes[$datum['id']['value']])){
		$process = $processes[$datum['id']['value']];
	} else {
		addToDic($dic, $datum['id']['value'], $datum['l']);
		$process = ['p'=>$datum['p']['value'], 'id'=>$datum['id']['value'], 'gene'=>array()];
	}
	if (isset($process['gene'][$datum['gene']['value']])){
		$gene = $process['gene'][$datum['gene']['value']];
	} else {
		$gene = ['id'=>$datum['gene']['value'], 'role'=>array(), 'assay'=>array(), 'being'=>array()];
		addToDic($dic, $datum['gene']['value'], $datum['gl']);
	}
	if (isset($datum['role'])){
		if (!in_array(['id'=>$datum['role']['value']], $gene['role'])){
			$gene['role'][] = ['id'=>$datum['role']['value']]; // この時点ではarrayに直で格納？
			addToDic($dic, $datum['role']['value'], $datum['rl']);
		}
	}
	if (isset($datum['assay'])){
		if (!in_array(['id'=>$datum['assay']['value']], $gene['assay'])){
			$at = null;
			if (isset($datum['atype'])){
				$at = $datum['atype']['value'];
			}
			if (isset($datum['ptype'])){
				if ($at == null){
					$at = $datum['ptype']['value'];
				} else {
					$at .= " " .$datum['ptype']['value'];
				}
			}
			if ($at == null){
				$at = 'other';
			}

			$gene['assay'][] = ['id'=>$datum['assay']['value'], 't'=>$at]; // この時点ではarrayに直で格納？
			addToDic($dic, $datum['assay']['value'], $datum['al']);
		}
	}
	if (isset($datum['being'])){
		if (!in_array(['id'=>$datum['being']['value']], $gene['being'])){
			$mt = null;
			if (isset($datum['mtype'])){
				$mt = $datum['mtype'];
				$gene['being'][] = ['id'=>$datum['being']['value'], 't'=>$mt['value']]; // この時点ではarrayに直で格納？
			} else {
				$gene['being'][] = ['id'=>$datum['being']['value'], 't'=>'other'];
			}
		}
	}

	$process['gene'][$datum['gene']['value']] = $gene;
	$processes[$datum['id']['value']] = $process;
}


//var_dump($dic);

foreach ($processes as &$process){
	$process['l'] = $dic[$process['id']];
	foreach ($process['gene'] as &$gene){
		$gene['l'] = $dic[$gene['id']];

		foreach ($gene['role'] as &$role){
			$role['l'] = $dic[$role['id']];
		}
		foreach ($gene['assay'] as &$assay){
			$assay['l'] = $dic[$assay['id']];
		}
	}
}

return $processes;
}




?>