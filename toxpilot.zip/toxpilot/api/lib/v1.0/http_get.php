<?php

set_time_limit(420);

class Http{

//	private $endpoint = 'http://localhost:3030/20180405_test1108/query';
//	private $endpoint = 'http://localhost:3030/20180405b/query';
	private $endpoint = 'http://202.241.38.110:3030/hepatotoxicity/query';
//	private $endpoint = 'http://localhost:3030/20180405/query';
//	private $endpoint = 'http://localhost:3030/20180405/query';
/*
	function get($query){
		$data = http_build_query (
			['query'=>$query]
		);

		$header = [
		"Accept:application/sparql-results+json"
		];

		$options = [
		"http"=>["method"=>"GET", "header"=>implode("\r\n", $header)]
		];

		$data = file_get_contents($this->endpoint. '?'. $data, false, stream_context_create($options));
		$data = json_decode($data, true);
		$data = $data['results']['bindings'];

		return $data;
	}
*/
	function get($query){
		$data = http_build_query (
				['query'=>$query]
				);

		$header = [
		"Accept:application/sparql-results+json"
		];
		$options = [
				CURLOPT_RETURNTRANSFER=>true,
				CURLOPT_TIMEOUT=>420
		];



		$ch = curl_init($this->endpoint. '?'. $data);
		curl_setopt_array($ch, $options);

		$data = curl_exec($ch);
		$info = curl_getinfo($ch);
		$error = curl_errno($ch);
		if ($error !== CURLE_OK){
			return ['error'=>'Network Error ('.$error . ") : [".curl_error($ch)."]"];
		}
		if ($info['http_code'] !== 200){
			return ['error'=>'Error Code:'.$info['http_code']];
		}

		$data = json_decode($data, true);
		$data = $data['results']['bindings'];

//		var_dump($data);
		return $data;
	}

}

?>