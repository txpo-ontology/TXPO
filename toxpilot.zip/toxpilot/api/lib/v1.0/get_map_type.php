<?php
// 作用機序マップデータ取得用

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";


$types = [];

foreach ($type_map as $key=>$value){
	$types[$key] = $value['l'];
}

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($types);

?>