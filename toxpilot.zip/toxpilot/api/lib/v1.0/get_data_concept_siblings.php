<?php
// 兄弟概念取得用
// 指定された概念の兄弟概念一覧を取得する

include_once "http_get.php";
include_once "get_util.php";
include_once "get_data_type_lib.php";
include_once "get_data_course_lib.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = true;
$ret['id'] = $id;
$ret['type'] = get_type($id, $const); // TODO course/process/molecule/finding/structure

/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */

$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
select distinct ?sibling ?l
{
 <" . $id . ">  rdfs:subClassOf ?p.
 ?sibling rdfs:subClassOf+ ?p;
 rdfs:label ?l.
?sibling rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.
 {?p rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">}
 FILTER(lang(?l) = '". $lang ."')
 FILTER(isUri(?p))
}";


$siblings = $http->get($query);

$ret = array();
$ret['result'] = true;
$ret['type'] = '';
$ret['siblings'] = array();
$ret['relations'] = array();

foreach ($siblings as $datum){
	$ret['siblings'][] = ['id'=>$datum['sibling']['value'], 'l'=>$datum['l']['value']];
}


foreach ($siblings as $datum){
	$sid = $datum['sibling']['value'];
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?reason ?rnlabel ?result ?rslabel{\n".
	"{\n".
	"<" . $sid . "> rdfs:subClassOf ?n.\n".
	"?n owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">;\n".
	" owl:someValuesFrom ?result.\n".
	"?result rdfs:label ?rslabel.\n".
	"FILTER (isBlank(?n))\n".
	"FILTER (lang(?rslabel) = '" . $lang . "')\n".
	"} union {\n".
	"?reason rdfs:subClassOf ?n2.\n".
	"?n2 owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">;\n".
	"owl:someValuesFrom <" . $sid . ">.\n".
	"?reason rdfs:label ?rnlabel.\n".
	"FILTER (isBlank(?n2))\n".
	"FILTER (lang(?rnlabel) = '" . $lang . "')\n".
	"}\n".
	"}";

	$rrs = $http->get($query);

	$relation = array();
	$relation['cause'] = array();
	$relation['result'] = array();
	foreach ($rrs as $rr){
		if (isset($rr['reason'])){
			$relation['cause'][] = ['id'=>$rr['reason']['value'], 'l'=>$rr['rnlabel']['value']];
		} else if (isset($rr['result'])){
			$relation['result'][] = ['id'=>$rr['result']['value'], 'l'=>$rr['rslabel']['value']];
		}

	}

	$ret['relations'][$sid] = $relation;
}


foreach ($siblings as $datum){
	$sid = $datum['sibling']['value'];
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?o ?l {\n".
	" ?o (rdfs:subClassOf/owl:someValuesFrom)+ <" . $sid . ">;\n".
	"  rdfs:label ?l;\n".
	"  rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.\n".
	" FILTER (lang(?l) = '" . $lang . "')\n".
	"}";

	$crss = $http->get($query);

	$course = array();
	$course_parents = array();
	foreach ($crss as $crs){
		$course[] = ['id'=>$crs['o']['value'], 'l'=>$crs['l']['value']];

		$tmp_cps = get_course_parents($crs['o']['value'], $lang, $const);

		$course_parents = array_merge($course_parents, $tmp_cps);
		$course_parents = array_unique($course_parents);
	}

	// course_parentsを昇順ソート
	sort($course);
	sort($course_parents);

	$ret['courses'][$sid] = $course;
	$ret['cparents'][$sid] = $course_parents;
}



header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>