<?php
// 検索用
set_time_limit(120); // 検索ではタイムアウト値を長めにとる


include "http_get.php";

if (isset($_GET['q'])){
	$q = $_GET['q'];
} else {
	// 該当なし
	// TODO エラーを返す

}


/**
 * 〇作用機序単体
 * 　作用機序
 * 〇プロセス単体
 * 　プロセス
 * 〇作用機序＋プロセス
 * 　作用機序内のプロセス
 * 〇作用機序＋分子／構造／所見
 * 　作用機序内プロセスに登場するもの
 * 〇プロセス＋分子／構造／所見
 * 　該当プロセスに登場するもの
 * 〇分子／構造／所見＋分子／構造／所見
 * 　各分子／構造／所見 間の プロセスが共通するもの
 */

$solo = (count($q) == 1);


$vals = [];
$tmp_query = '';

$word_list = []; // 検索ワードあり条件
$blank_list = []; // 検索ワードなし条件

foreach ($q as $elm){
	$params = splitParam($elm);
	if (isset($params['w']) && $params['w'] != ''){
		$params['w'] = preg_quote($params['w']); // エスケープ処理
		$params['w'] = preg_replace('/\\\/u', "\\\\\\", $params['w']); // エスケープ処理
		$word_list[] = $params;
	} else {
		$params['w'] = '';
		$blank_list[] = $params;
	}
}
if (count($word_list) > 0 || count($blank_list) > 2){
	// suggestでなければ要素ソート
	$sort = ['c', 'p', 's', 'f', 'r', 'm', 'q'];
	usort($word_list, function($x, $y) use ($sort){
		$k=array_flip($sort);
		return $k[$x['tp']] > $k[$y['tp']];
	});

	usort($blank_list, function($x, $y) use ($sort){
		$k=array_flip($sort);
		return $k[$x['tp']] > $k[$y['tp']];
	});
}


$params_list = array_merge($word_list, $blank_list);
//	echo "[".$elm."]";


foreach ($params_list as $params){
	if (isset($params['tp'])){
		$type = $params['tp'];

		if ($type == 'c' || $type == 'course'){
			$tmp = makeCourseQuery($params, $solo);
		}
		if ($type == 'p' || $type == 'process'){
			$tmp = makeProcessQuery($params, $solo);
		}
		if ($type == 'f' || $type == 'finding'){
			$tmp = makeFindingQuery($params, $solo);
		}
		if ($type == 's' || $type == 'structure'){
			$tmp = makeStructureQuery($params, $solo);
		}
		if ($type == 'r' || $type == 'role'){
			$tmp = makeRoleQuery($params, $solo);
		}
		if ($type == 'm' || $type == 'molecule'){
			$tmp = makeMoreculeQuery($params, $solo);
		}
		if ($type == 'q' || $type == 'quarity'){
			$tmp = makeQuarityQuery($params, $solo);
		}
		$vals = array_merge($vals, $tmp['type']);
		$tmp_query .= $tmp['query'];
	}
}
$vals = array_unique($vals);

$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ";

$query .= '?' . implode(' ?', $vals) . " {\n";
$query .= $tmp_query;
$query .= '}';

if (in_array('p', $vals)){
	$query .= ' order by ?p';
}

function splitParam($args){
	// カンマ区切り
	// tp:検索対象
	// w:ワード（空白区切り複数）
	// m:マッチ種別
	// t:ターゲット
	$ret = [];
	$elms = explode(',', $args);

	foreach ($elms as $elm){
		$keyset = explode('=', $elm);
		if (count($keyset) > 1){
			$ret[$keyset[0]] = $keyset[1];
		}
	}
	return $ret;
}



// process
function makeProcessQuery($args, $only){
	global $lang;
	global $const;

	$word = '';
	if (isset($args['w'])){
		$word = $args['w'];
	}

	$target = 'myself';
	if (isset($args['t']) && $only){
		// 兄弟・親検索はプロセスの単体検索の場合のみ有効
		$target = $args['t'];
	}

//	echo "[".$target."]:".$only;

	if ($target == 'm' || $target == 'myself' || $target='parent'){

		// 該当するプロセス
		if ($only){
		$query =
			"{\n".
			"{\n".
			"?p rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">;\n".
			" rdfs:subClassOf ?a.\n".
			"?a rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.\n".
			"} union {\n".
			"?p rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">;\n".
			" rdfs:subClassOf ?a.\n".
			"?a rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
			"} \n".
			"?p ?prop1 ?pl_;\n".
			" rdfs:label ?pl.\n".
			"FILTER (?prop1 = rdfs:label || ?prop1 = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
			"FILTER (lang(?pl) = '" . $lang . "' || lang(?pl) = '')\n";

			if (isset($args['m']) && $args['m'] == 'full'){
				$query .= "FILTER (?pl_ = '" . $word . "')\n";
			} else {
				if (preg_match('/.*[＠@\\\\[].*/', $word) == 1){
					$query .= "FILTER (regex(?pl_, '" . $word . "', 'i'))\n";
				} else {
					$query .= "FILTER((regex(?pl_, '" . $word . "', 'i') && regex(?pl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?pl_, '.*(" . $word . ".*[＠@\\\\[]).*', 'i'))\n";
				}
			}
			$query .= "} \n";
			$type = ['a', 'p', 'pl'];
		} else {
			$query =
			"{\n".
			"{\n".
			"?p rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.\n".
			"} union {\n".
			"?p rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
			"} \n".
			"?p ?prop1 ?pl_;\n".
			" rdfs:label ?pl.\n".
			"FILTER (?prop1 = rdfs:label || ?prop1 = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
			"FILTER (lang(?pl) = '" . $lang . "' || lang(?pl) = '')\n";

			if (isset($args['m']) && $args['m'] == 'full'){
				$query .= "FILTER (?pl_ = '" . $word . "')\n";
			} else {
				if (preg_match('/.*[＠@\\\\[].*/', $word) == 1){
					$query .= "FILTER (regex(?pl_, '" . $word . "', 'i'))\n";
				} else {
					$query .= "FILTER((regex(?pl_, '" . $word . "', 'i') && regex(?pl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?pl_, '.*(" . $word . ".*[＠@\\\\[]).*', 'i'))\n";
				}
			}
			$query .= "} \n";
			$type = ['p', 'pl'];
			}
	}
	if ($target == 'sibling'){
		$query =
		"{\n".
		"?p rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">;\n".
		" rdfs:subClassOf ?a.\n".
		"?a rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.\n".
		"optional{\n".
		" ?p rdfs:subClassOf ?pr.\n".
		" ?sp rdfs:subClassOf ?pr;\n".
		" ?prop1 ?spl_;\n".
		" rdfs:label ?spl\n".
		" FILTER (?prop1 = rdfs:label || ?prop1 = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
		"}\n".
		"} union {\n".
		"?p rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">;\n".
		" rdfs:subClassOf ?a.\n".
		"?a rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
		"} \n".
		"?p ?prop ?pl_;\n".
		" rdfs:label ?pl.\n".
		"FILTER (?prop = rdfs:label || ?prop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
		"minus{?sp rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.}\n".
		"FILTER (!bound(?pl) || (lang(?pl) = '" . $lang . "' || lang(?pl) = '') && (!bound(?spl) || (lang(?spl) = '" . $lang . "' || lang(?spl) = '')))\n";

		if (isset($args['m']) && $args['m'] == 'full'){
			$query .= "FILTER (?pl_ = '" . $word . "' || ?spl_ = '" . $word . "')\n";
		} else {
			if (preg_match('/.*[＠@\\\\[].*/', $word) == 1){
				$query .= "FILTER (regex(?pl_, '" . $word . "', 'i') || regex(?spl_, '" . $word . "', 'i'))\n";
			} else {
				$query .= "FILTER(((regex(?pl_, '" . $word . "', 'i') && regex(?pl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?pl_, '.*(" . $word . ".*[＠@\\\\[]).*', 'i')) || \n";
				$query .= "((regex(?spl_, '" . $word . "', 'i') && regex(?spl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?spl_, '.*(" . $word . ".*[＠@\\\\[]).*', 'i')))\n";
			}
		}
		$query .= "} \n";
		$type = ['a', 'p', 'pl', 'sp', 'spl'];
	}

	return ['query'=>$query, 'type'=>$type];
}


// course
function makeCourseQuery($args, $only){
	global $lang;
	global $const;
	// 該当する作用機序

	$word = '';
	if (isset($args['w'])){
		$word = $args['w'];
	}


	if ($only){
		$query =
		"{ \n".
		"?cs rdfs:subClassOf+ <". $const['DATA_TOX_MECHA'].">;\n". // 毒性発現作用機序
		" ?prop ?cl_;\n".
		" rdfs:label ?cl.\n".
		"FILTER (?prop = rdfs:label || ?prop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
		"FILTER (lang(?cl) = '". $lang ."' || lang(?cl) = '')\n";

		if (isset($args['m']) && $args['m'] == 'full'){
			$query .= "FILTER (str(?cl_) = '" . $word . "')\n";
		} else {
			$query .= "FILTER (regex(?cl_, '" . $word . "', 'i'))\n";
		}
		$query .= "} \n";

		$type = ['cs', 'cl'];
	} else {
		$query =
		"{ \n".
		"?cs rdfs:subClassOf+ <". $const['DATA_TOX_MECHA'].">;\n". // 毒性発現作用機序
		" ?cprop ?cl_;\n".
		" rdfs:label ?cl.\n".
 		"?cs (rdfs:subClassOf/owl:someValuesFrom)+ ?p;\n".
 		" (rdfs:subClassOf/owl:someValuesFrom)* ?pp.\n".
 		"?pp rdfs:subClassOf ?n_.
    ?n_ owl:someValuesFrom ?p;
    owl:onProperty ?pr.
    FILTER (?pr != <" . $const['DATA_CONTAINS_PROCESS'] . ">)".
 		"FILTER (?cprop = rdfs:label || ?cprop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".
 		"FILTER (lang(?cl) = '". $lang ."' || lang(?cl) = '')\n";

		if (isset($args['m']) && $args['m'] == 'full'){
			$query .= "FILTER (str(?cl) = '" . $word . "')\n";
		} else {
			if (preg_match('/.*[＠@\\\\[].*/', $word) == 1){
				$query .= "FILTER (regex(?cl_, '" . $word . "', 'i'))\n";
			} else {
				$query .= "FILTER((regex(?cl_, '" . $word . "', 'i') && regex(?cl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?cl, '.*(" . $word . ".*[＠@\\\\[]).*', 'i'))\n";
			}
		}
		$query .= "} \n";

		$type = ['cs', 'cl'];
	}

	return ['query'=>$query, 'type'=>$type];

}


// morecule
function makeMoreculeQuery($args, $only){
	global $const;
	// 該当する分子、それに関連するプロセス
	return makeProcessRelationQuery($args, [$const['DATA_MOLECULE'], $const['DATA_COMPOUND']], [$const['DATA_HAS_PARTICIPANT'],$const['DATA_HAS_INPUT'],$const['DATA_HAS_OUTPUT'],$const['DATA_HAS_AGENT']], 'm', $only);
}


// role
function makeRoleQuery($args, $only){
	global $const;
	// 該当するロール、それに関連する分子
//	return makeProcessRelationQuery($args, $const['DATA_MOLECULE'], $const['DATA_HAS_PARTICIPANT'], 'm', $only);
	global $lang;

	$word = '';
	if (isset($args['w'])){
		$word = $args['w'];
	}

	$reltypes = [$const['DATA_HAS_PARTICIPANT'],$const['DATA_HAS_INPUT'],$const['DATA_HAS_OUTPUT'],$const['DATA_HAS_AGENT']];

	// 該当するオブジェクト、それに関連するプロセス
	if ($only){
		$query =
		"{".
		" ?rs rdfs:subClassOf+ <" . $const['DATA_ROLE_BASE'] . ">;\n".
		"  ?rprop ?rl_;\n".
		"  rdfs:label ?rl.\n".
		"FILTER (?rprop = rdfs:label || ?rprop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n";
		if (isset($args['w'])){
			if (isset($args['m']) && $args['m'] == 'full'){
				$query .=
				"  FILTER(str(?rl_) = '" . $word . "' )\n";
			} else {
				$query .=
				"  FILTER(regex(?rl_, '" . $word . "', 'i'))\n";
			}
		}
		$query .=
		"  FILTER(lang(?rl) = '" . $lang . "' || lang(?rl) = '')\n".
		"}";

		$type = ['rs', 'rl'];
	} else {
		$query =
		"{".
		"?p rdfs:subClassOf ?mn.\n".
		"?mn (owl:someValuesFrom|owl:allValuesFrom) ?ms.\n".

		"{ ?mn owl:onProperty <" .
		implode(">.\n} union { ?mn owl:onProperty <" , $reltypes).
		">.}\n".
		" ?ms rdfs:subClassOf ?rn.\n".
		" ?rn owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;\n".
		"  (owl:someValuesFrom|owl:allValuesFrom) ?rs.\n".
		" ?rs rdfs:subClassOf+ <" . $const['DATA_ROLE_BASE'] . ">;\n".
		"  ?rprop ?rl_;\n".
		"  rdfs:label ?rl.\n".
		"FILTER (?rprop = rdfs:label || ?rprop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n";

		if (isset($args['w'])){
			if (isset($args['m']) && $args['m'] == 'full'){
				$query .=
				"  FILTER(?rl_ = '" . $args['w'] . "' )\n";
			} else {
				if (preg_match('/.*[＠@\\\\[].*/', $word) == 1){
					$query .= "  FILTER(regex(?rl_, '" . $word . "', 'i'))\n";
				} else {
					$query .= "  FILTER((regex(?rl_, '" . $word . "', 'i') && regex(?rl_, '^(?!.*[＠@\\\\[]).*$')) || regex(?rl_, '.*(" . $word . ".*[＠@\\\\[]).*', 'i'))\n";
				}
			}
		}
		$query .=
		"  FILTER(lang(?rl) = '" . $lang . "' || lang(?rl) = '')\n".
		"}";

		$type = ['rs', 'rl'];
	}
	return ['query'=>$query, 'type'=>$type];

}


// finding
function makeFindingQuery($args, $only){
	global $const;
	return makeProcessRelationQuery($args, $const['DATA_FINDING_BASE'], [$const['DATA_HAS_FINDINGS']], 'f', $only);
}



// structure
function makeStructureQuery($args, $only){
	global $const;
	// 該当する構造、それに関連するプロセス
	return makeProcessRelationQuery($args, $const['DATA_ANATOMICAL_ENTITY'], [$const['DATA_OCCURS_IN']], 's', $only);

}

// quarity
function makeQuarityQuery($args, $only){
	global $const;
	// 該当する分子、それに関連するプロセス
	return makeProcessRelationQuery($args, $const['DATA_QUARITY'], [$const['DATA_HAS_QUARITY'],$const['DATA_HAS_STATE']], 'q', $only);
}


// プロセス関連オブジェクト
function makeProcessRelationQuery($args, $bases, $reltypes, $prefix, $only){
	global $lang;
	// 該当するオブジェクト、それに関連するプロセス

	if (is_array($bases)){
		$base = implode(">.\n} union { ?" . $prefix ."s rdfs:subClassOf+ <" , $bases);
		$nbase = implode(">.\n} union { ?" . $prefix ." rdfs:subClassOf+ <" , $bases);
	} else {
		$base = $bases;
		$nbase = $bases;
	}

	if ($only){
		$query =
		"{".
		" {?" . $prefix . "s rdfs:subClassOf+ <" . $base . ">.}\n".
		" ?" . $prefix . "s rdfs:label ?" . $prefix ."l;\n".
		"  ?" . $prefix ."prop ?" . $prefix ."l_.\n".
		"FILTER (?" . $prefix ."prop = rdfs:label || ?" . $prefix ."prop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n";

		if (isset($args['w'])){
			if (isset($args['m']) && $args['m'] == 'full'){
				$query .=
				"  FILTER(str(?" . $prefix . "l_) = '" . $args['w'] . "' )\n";
			} else {
				if ($args['w'] != ''){
					if (preg_match('/.*[＠@\\\\[].*/', $args['w']) == 1){
						$query .=
						"  FILTER(regex(?" . $prefix . "l_, '" . $args['w'] . "', 'i'))\n";
					} else {
						$query .=
						"  FILTER((regex(?" . $prefix . "l_, '" . $args['w'] . "', 'i') && regex(?" . $prefix . "l_, '^(?!.*[＠@\\\\[]).*$')) || regex(?" . $prefix . "l_, '.*(" . $args['w'] . ".*[＠@\\\\[]).*', 'i'))\n";
					}
				}
			}
		}
		$query .=
		"  FILTER(lang(?" . $prefix . "l) = '" . $lang . "' || lang(?" . $prefix . "l) = '')\n".
		"}";

		$type = [$prefix . 's', $prefix . 'l'];
	} else {
		$query =
		"{".
		" {?" . $prefix . "s rdfs:subClassOf+ <" . $base . ">.}\n".
		" ?" . $prefix . "s rdfs:subClassOf ?" . $prefix .";\n".
		"  rdfs:label ?" . $prefix ."l;\n".
		"  ?" . $prefix ."prop ?" . $prefix ."l_.\n".
		" ?p rdfs:subClassOf ?" . $prefix ."n.\n".
		" ?" . $prefix ."n (owl:someValuesFrom|owl:allValuesFrom) ?" . $prefix ."s.\n".
//		"  rdfs:label ?pl.\n".
//		" ?" . $prefix ."n owl:onProperty <" . $reltype . ">;\n".
		"FILTER (?" . $prefix ."prop = rdfs:label || ?" . $prefix ."prop = <http://www.geneontology.org/formats/oboInOwl#hasExactSynonym>)\n".

		"{ ?" . $prefix ."n owl:onProperty <" .
		implode(">.\n} union { ?" . $prefix ."n owl:onProperty <" , $reltypes).
		">.}\n".

		" {?" . $prefix ." rdfs:subClassOf+ <" . $nbase . ">.}\n";
		if (isset($args['w'])){
			if (isset($args['m']) && $args['m'] == 'full'){
				$query .=
				"  FILTER(?" . $prefix . "l_ = '" . $args['w'] . "' )\n";
			} else {
				if (preg_match('/.*[＠@\\\\[].*/', $args['w']) == 1){
					$query .=
					"  FILTER(regex(?" . $prefix . "l_, '" . $args['w'] . "', 'i'))\n";
				} else {
					$query .=
					"  FILTER((regex(?" . $prefix . "l_, '" . $args['w'] . "', 'i') && regex(?" . $prefix . "l_, '^(?!.*[＠@\\\\[]).*$')) || regex(?" . $prefix . "l_, '.*(" . $args['w'] . ".*[＠@\\\\[]).*', 'i'))\n";
				}
			}
		}
		$query .=
		"  FILTER(lang(?" . $prefix . "l) = '" . $lang . "' || lang(?" . $prefix . "l) = '')\n".
		"}";

		$type = [ $prefix . 's', $prefix . 'l'];
	}

	return ['query'=>$query, 'type'=>$type];
}


/*
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"select distinct ?s ?l {\n".
"?s rdfs:subClassOf <" . $const['DATA_REMARK_BASE'] . ">;\n".
" rdfs:label ?lpolypeptides.\n".
" FILTER(lang(?l) = '" . $lang . "')\n".
"}";
*/

//echo $query;

header("Content-Type: application/sparql-results+json;charset=UTF-8");
$http = new Http();


echo json_encode($http->get($query));


?>