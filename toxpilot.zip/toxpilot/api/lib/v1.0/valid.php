<?php


// 各バージョンごとの情報を記述する

$test = false;

// 本バージョンにて利用可能な言語
$valid_langs = ['en', 'ja'];

/*
$base_uri = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics';

// 定数
$const =
[
'BASE_URI' => $base_uri, // ベース
'DATA_TOX_PROCESS' => $base_uri.'#[TXG]_0001715', // 毒性作用機序依存プロセス
'DATA_TOX_MECHA' =>$base_uri.'#[TXG]_0000009', // 毒性発現作用機序
'DATA_COMPOUND' =>'http://purl.obolibrary.org/obo/CHEBI_24431', // 化合物
//'DATA_COMPOUND' =>'http://purl.obolibrary.org/obo/CHEBI_50860', // 化合物
'DATA_MOLECULE' =>'http://purl.obolibrary.org/obo/CHEBI_25367', // 分子
//'DATA_MOLECULE' =>'http://purl.obolibrary.org/obo/CHEBI_24431', // 分子
'DATA_HAS_PART' =>'http://purl.obolibrary.org/obo/BFO_0000051', // has_part
'DATA_DEFINITION' => 'http://purl.obolibrary.org/obo/IAO_0000115', // definition
'DATA_HAS_RESULT' => $base_uri.'#[TXG]_0000069', // has_result
'DATA_DYSFUNC' => $base_uri.'#[TXG]_0000716', // dysfunctioning
'DATA_HAS_CONTEXT' => $base_uri.'#[TXG]_0000774', // has_context
'DATA_HAS_FAMILY' => $base_uri.'#[TXG]_0002260', // has_family
'DATA_HAS_ROLE' => $base_uri.'#[TXG]_0001518', // hasRole
'DATA_HAS_PARTICIPANT' => $base_uri.'#[TXG]_0001519', // hasParticipant
'DATA_HAS_INPUT' => $base_uri.'#[TXG]_0001969', // hasInput
'DATA_HAS_OUTPUT' => $base_uri.'#[TXG]_0001394', // hasOutput
'DATA_HAS_AGENT' => $base_uri.'#[TXG]_0001868', // hasAgent
'DATA_HAS_RELATED_ASSAY' => $base_uri.'#[TXG]_0000756', // hasRelatedAssay
'DATA_HAS_FINDINGS' => $base_uri.'#[TXG]_0001873', // has_findings
'DATA_OCCURS_IN' =>'http://purl.obolibrary.org/obo/BFO_0000066', // occurs_in
'DATA_PRIMITIVE_PROCESS' => $base_uri.'#[TXG]_0000271', // prmitiveプロセス
'DATA_PRIMITIVE_PATHWAY' => $base_uri.'#[TXG]_0000614', // 生体パスウェイ
'DATA_ASSAY' =>$base_uri.'#[TXG]_0000487', // assay
'DATA_FUNC_PROCESS' => $base_uri.'#[TXG]_0000145', // 機能関連プロセス
'DATA_PHEM_PROCESS' => $base_uri.'#[TXG]_0000357', // 現象関連プロセス
'DATA_FINDING_BASE' => $base_uri.'#[TXG]_0001507', // 病理所見
'DATA_ROLE_BASE' => 'http://purl.obolibrary.org/obo/BFO_0000023', // ロール
'DATA_ANATOMICAL_ENTITY' => 'http://purl.obolibrary.org/obo/UBERON_0001062', // 解剖学的エンティティ


'DATA_IN_VITRO_HUMAN' =>$base_uri.'#[TXG]_0000795', // in vitro(human)
'DATA_IN_VIVO_RAT' =>$base_uri.'#[TXG]_0000773', // in vivo(rat)

];
*/
//$base_uri_ = 'http://bioportal.bioontology.org/ontologies/txpo';
$base_uri_ = 'http://purl.obolibrary.org/obo';
$base_uri = $base_uri_ . '/';

// 定数
$const =
[
		'BASE_URI' => $base_uri_, // ベース
		'DATA_TOX_PROCESS' => $base_uri.'TXPO_0001715', // 毒性作用機序依存プロセス
		'DATA_TOX_THING' => $base_uri.'TXPO_0001731', // 毒性作用機序依存物質
		'DATA_TOX_MECHA' =>$base_uri.'TXPO_0000009', // 毒性発現作用機序
		'DATA_COMPOUND' =>'http://purl.obolibrary.org/obo/CHEBI_24431', // 化合物
		'DATA_ORGANIC_MOLECULAR' =>'http://purl.obolibrary.org/obo/CHEBI_50860', // 有機化合物
		'DATA_MOLECULE' =>'http://purl.obolibrary.org/obo/CHEBI_25367', // 分子
		//'DATA_MOLECULE' =>'http://purl.obolibrary.org/obo/CHEBI_24431', // 分子
		'DATA_QUARITY' => 'http://purl.obolibrary.org/obo/BFO_0000019', // 性質
		'DATA_HAS_PART' =>'http://purl.obolibrary.org/obo/BFO_0000051', // has_part
		'DATA_HAS_QUARITY' => 'http://purl.obolibrary.org/obo/RO_0000086', // has_quarity
		'DATA_HAS_STATE' => $base_uri.'TXPO_0001733', // has_state
		'DATA_DEFINITION' => 'http://purl.obolibrary.org/obo/IAO_0000115', // definition
		'DATA_HAS_RESULT' => $base_uri.'TXPO_0000069', // has_result
		'DATA_DYSFUNC' => $base_uri.'TXPO_0000716', // dysfunctioning
		'DATA_HAS_CONTEXT' => $base_uri.'TXPO_0000774', // has_context
		'DATA_HAS_FAMILY' => $base_uri.'TXPO_0002260', // has_family
		'DATA_HAS_ROLE' =>  'http://purl.obolibrary.org/obo/RO_0000087', // hasRole
		'DATA_HAS_PATHWAY' =>  $base_uri.'TXPO_0002524', // hasPathway
		'DATA_HAS_CORE_PROCESS' => $base_uri.'TXPO_0000004', // has_core_process
		'DATA_HAS_MOLECULAR_REACTION' =>  $base_uri.'TXPO_0000012', // has molecular reaction
		'DATA_HAS_PARTICIPANT' => 'http://purl.obolibrary.org/obo/RO_0000057', // hasParticipant
		'DATA_HAS_INPUT' => 'http://purl.obolibrary.org/obo/RO_0002233', // hasInput
		'DATA_HAS_OUTPUT' => 'http://purl.obolibrary.org/obo/RO_0002234', // hasOutput
		'DATA_HAS_AGENT' => $base_uri.'TXPO_0001868', // hasAgent
		'DATA_HAS_RELATED_ASSAY' => $base_uri.'TXPO_0000756', // hasRelatedAssay
		'DATA_HAS_FINDINGS' => $base_uri.'TXPO_0001873', // has_findings
		'DATA_PARTICIPANT_IN' => 'http://purl.obolibrary.org/obo/RO_0000056', // participant in
		'DATA_OCCURS_IN' =>'http://purl.obolibrary.org/obo/BFO_0000066', // occurs_in
		'DATA_CONTAINS_PROCESS' => 'http://purl.obolibrary.org/obo/BFO_0000067', // contains process
		'DATA_PRIMITIVE_PROCESS' => $base_uri.'TXPO_0000271', // prmitiveプロセス
//		'DATA_PRIMITIVE_PATHWAY' => $base_uri.'TXPO_0000614', // 生体パスウェイ (廃止)
//		'DATA_ASSAY' =>$base_uri.'TXPO_0000487', // assay (廃止)
		'DATA_FUNC_PROCESS' => $base_uri.'TXPO_0000145', // 機能関連プロセス
//		'DATA_PHEM_PROCESS' => $base_uri.'TXPO_0000357', // 現象関連プロセス (廃止)
		'DATA_FINDING_BASE' => $base_uri.'TXPO_0001507', // 病理所見
		'DATA_ROLE_BASE' => 'http://purl.obolibrary.org/obo/BFO_0000023', // ロール
		'DATA_ANATOMICAL_ENTITY' => 'http://purl.obolibrary.org/obo/UBERON_0001062', // 解剖学的エンティティ
//		'DATA_INHERES_IN' => 'http://purl.obolibrary.org/obo/RO_0000052', // inheres in
		'DATA_INHERES_IN' => $base_uri.'TXPO_0003360', // is entity in organism
		'DATA_PROCESS_DEPEND' => $base_uri.'TXPO_0000808', // 疾患経過依存プロセス
		'DATA_PROCESS_VIEWPOINT' => $base_uri.'TXPO_0000420', // 視点に基づくプロセス
		'DATA_QUARITY_PREDICTED' =>  $base_uri.'TXPO_0000657', // 特性
		'DATA_MOST_DILI' => $base_uri.'TXPO_0004323', // Most-DILI Concern

		'DATA_IN_VITRO_HUMAN' => $base_uri.'TXPO_0000795', // in vitro(human)
		'DATA_IN_VITRO' => 'http://ncicb.nci.nih.gov/xml/owl/EVS/Thesaurus.owl#C15958', // in vitro
		'DATA_IN_VIVO_RAT' => $base_uri.'TXPO_0000773', // in vivo(rat)
		'DATA_IN_VIVO' => $base_uri.'TXPO_0000489', // in vivo

		'DATA_ANIMAL_MOUSE' => 'http://purl.obolibrary.org/obo/NCBITaxon_10090',
		'DATA_ANIMAL_RAT' => 'http://purl.obolibrary.org/obo/NCBITaxon_10114',
		'DATA_ANIMAL_HUMAN' => 'http://purl.obolibrary.org/obo/NCBITaxon_9606',

];

$const_label =
[
		$base_uri.'TXPO_0000069' => 'has result',
		'http://purl.obolibrary.org/obo/BFO_0000051' => 'has part',
		$base_uri.'TXPO_0002524' => 'has pathway',
		$base_uri.'TXPO_0000012' => 'has molecular reaction',
		$base_uri.'TXPO_0001873' => 'has finding',
		$base_uri.'TXPO_0001868' => 'has agent',
		'http://purl.obolibrary.org/obo/RO_0000057' => 'has participant',
		$base_uri.'TXPO_0001868' => 'has agent',
		'http://purl.obolibrary.org/obo/RO_0002233' => 'has input',
		'http://purl.obolibrary.org/obo/RO_0002234' => 'has output',

];

$except_courses = [
//		$base_uri. 'TXPO_0001986', // ミトコンドリア障害
		$base_uri. 'TXPO_0003763', // 病理所見に基づく機序
		$base_uri. 'TXPO_0000262', // ATP枯渇
		$base_uri. 'TXPO_0001277', // 胆汁うっ滞
		$base_uri. 'TXPO_0000677', // 酸化ストレス
];


if ($test){
	$except_courses = [];
}

?>