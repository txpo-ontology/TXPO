<?php

set_time_limit(120);

class Mapping {

	private $apikey = '19660f04-be9f-4534-92a1-37a04e59e67f';

	private $base_url = 'http://data.bioontology.org/ontologies/';

	function get($id){
		$data = urlencode($id);

		$idx = strpos($id, '/obo/');

		$acro = 'TXPO';

		if ($idx !== FALSE){
			$tmp_acro = substr($id, strlen('/obo/') + $idx);
			$idx = strpos($tmp_acro, '_');
			if ($idx !== FALSE){
				$acro = substr($tmp_acro, 0, $idx);
			}
		}


		$header = [
		"Accept:application/json"
		];
/*
		$options = [
		"http"=>["method"=>"GET"]
		];
*/
		$options = [
				CURLOPT_RETURNTRANSFER=>true,
				CURLOPT_TIMEOUT=>5
		];


//		$data = file_get_contents($this->base_url . $acro . '/classes/' . $data . "/mappings?format=json&apikey=".$this->apikey, false, stream_context_create($options));

		$ch = curl_init($this->base_url . $acro . '/classes/' . $data . "/mappings?format=json&apikey=".$this->apikey);
		curl_setopt_array($ch, $options);

		$data = curl_exec($ch);
		$info = curl_getinfo($ch);
		$error = curl_errno($ch);
		if ($error !== CURLE_OK){
			return ['error'=>'Network Error ('.$error . ") : [".curl_error($ch)."]"];
		}
		if ($info['http_code'] !== 200){
			return ['error'=>'Error Code:'.$info['http_code']];
		}

		$data = json_decode($data, true);

//		var_dump($data);
		return $data;
	}

}

?>