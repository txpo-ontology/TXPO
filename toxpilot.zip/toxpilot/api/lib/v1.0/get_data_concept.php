<?php
// 概念取得用
// 大枠の種別および基本情報を取得したうえで、各情報取得用モジュールに移譲する

include_once "http_get.php";
include_once "get_util.php";

include_once "get_data_type_lib.php";
include_once "get_data_gene_course_lib.php";
include_once "get_data_gene_process_lib.php";
include_once "get_data_process_course_lib.php";
include_once "get_data_concept_mapping_lib.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}

$external = 'false';

if (array_key_exists('mapping', $args)){
	$external = $args['mapping'];
}


$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = true;
$ret['id'] = $id;
$ret['type'] = get_type($id, $const); // TODO course/process/molecule/role/finding/structure
/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */


function get_annotation(&$ret){
	global $const, $http, $id, $lang;
	$query ="
	PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>
	PREFIX owl:<http://www.w3.org/2002/07/owl#>
	PREFIX dc: <http://purl.org/dc/elements/1.1/>
	select distinct ?p ?pl ?o ?ol ?optp ?optpl ?opto
	{
	 {
	<" . $id . "> ?p ?o.
	FILTER (!isBlank(?o))";

	if ($lang != 'ja'){
		$query .= "
		FILTER (!isLiteral(?o) || (lang(?o) = '" . $lang . "' || lang(?o) = ''))";
	}

	$query .=
	"
	 } optional {
	  ?p rdfs:label ?pl.
	 } optional {
	  ?o rdfs:label ?ol.";


	if ($lang != 'ja'){
		$query .=
		"	  FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')";
	}

	$query .=
	"
	 } optional {
	 ?opt owl:annotatedSource <" . $id . ">;
	  owl:annotatedTarget ?o;
	  owl:annotatedProperty ?p;
	  ?optp ?opto.
	  optional {
	   ?optp rdfs:label ?optpl.
	  FILTER (lang(?optpl) = '" . $lang . "')
	}
	  FILTER (?optp != owl:annotatedSource)
	  FILTER (?optp != owl:annotatedTarget)
	  FILTER (?optp != owl:annotatedProperty)
	  FILTER (?optp != rdf:type)
	 }
	}";

//	echo($query);

	$tmp_concept = $http->get($query);
	$word = null;
	$annotations = [];
	$dic = [];
	$dirty = [];
	if (isset($ret['dic'])){
		$dic = $ret['dic'];
	}

	$p = null;
	foreach ($tmp_concept as $datum){

		// spo
		$list = null;
		if (isset($annotations[$datum['p']['value']])){
			$list = $annotations[$datum['p']['value']];
		} else {
			$list = [];
		}
		$an = ['p'=> $datum['p'], 'o'=>$datum['o']];

		if (!contains($list, $an)){
			$list[] = $an;
		}
		$annotations[$datum['p']['value']] = $list;


		if (isset($datum['optp'])){
			$key = $an['p']['value'].':'.$an['o']['value'];
			$list = null;
			if (array_key_exists($key, $dirty)){
				if  (array_key_exists($key, $dic)){
					$list = $dic[$key];
				} else {
					$list = [];
				}
			} else {
				$list = [];
			}
			$list[] = ['p'=> $datum['optp'], 'o'=>$datum['opto']];
			$dirty[$key] = $list;
		}

		if (isset($datum['pl'])){
			$list = null;
			if (isset($dic[$datum['p']['value']])){
				$list = $dic[$datum['p']['value']];
			} else {
				$list = [];
			}
			$pl = $datum['pl'];
			if (!contains($list, $pl)){
				$list[] = $datum['pl'];
			}
			$dic[$datum['p']['value']] = $list;
		}

		if (isset($datum['optpl'])){
			$list = null;
			if (isset($dic[$datum['optp']['value']])){
				$list = $dic[$datum['optp']['value']];
			} else {
				$list = [];
			}
			$optpl = $datum['optpl'];
			if (!contains($list, $optpl)){
				$list[] = $datum['optpl'];
			}
			$dic[$datum['optp']['value']] = $list;
		}


		if (isset($datum['ol'])){
			// p-pp-po
			$list = null;
			if (isset($dic[$datum['o']['value']])){
				$list = $dic[$datum['o']['value']];
			} else {
				$list = [];
			}
			$ol = $datum['ol'];
			if (!contains($list, $ol)){
				$list[] = $ol;
			}
			$dic[$datum['o']['value']] = $list;
		}

	}

	foreach ($annotations as $key=>&$annos){
		foreach ($annos as &$an){
			$key = $an['p']['value'].':'.$an['o']['value'];
			if (array_key_exists($key, $dirty)){
				$an['opt'] = $dirty[$key];
			}
		}
	}

	$ret['annotations'] = $annotations;
	$ret['dic'] = $dic;

	return $ret;
}

function get_equivalent(&$ret){
	global $const, $http, $id, $lang;
	$query =
	/*
	 "
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl:<http://www.w3.org/2002/07/owl#>
	select distinct ?pl ?op ?o ?ol {
	<" . $id . "> ?p ?oo.
	?oo owl:onProperty ?prop;
	?op ?o.
	FILTER (?op != owl:onProperty)
	?prop rdfs:label ?pl.
	?o rdfs:label ?ol.
	FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
	}";
	*/
	"
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
select distinct ?pl ?op ?o ?ol ?oa1 ?ot1 ?oal1 ?pl2 ?op2 ?o2 ?ol2 ?oa2 ?ot2 ?oal2 ?pl3 ?op3 ?o3 ?ol3 ?oa3 ?ot3 ?oal3 ?pl4 ?op4 ?o4 ?ol4 {
 {
<" . $id . "> owl:equivalentClass ?oo.
 ?oo owl:onProperty ?prop;
 ?op ?o.
 FILTER (?op != owl:onProperty)
 FILTER (?o != owl:Restriction)
 ?prop rdfs:label ?pl.
 optional {
  ?o rdfs:label ?ol.
   FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
 }
  } union {
	 <" . $id . "> owl:equivalentClass ?oo.
    ?oo ?ot1 ?o.
 FILTER (isBlank(?o))
  ?o rdf:first ?oa1;
          rdf:rest ?ob1.
  ?oa1 rdfs:label ?oal1.
  FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
  FILTER(isBlank(?ob1))
  ?ob1 rdf:first ?ob11.
  ?ob11 owl:onProperty ?prop2;
   ?op2 ?o2.
  FILTER (?op2 != owl:onProperty)
  FILTER (?o2 != owl:Restriction)
  ?prop2 rdfs:label ?pl2.
  optional {
   ?o2 rdfs:label ?ol2.
   FILTER (lang(?ol2) = '" . $lang . "' || lang(?ol2) = '')
  }
}

 optional {
 {
  ?o2 ?ot2 ?bl2.
  FILTER (isBlank(?bl2))
  ?bl2 rdf:first ?oa2;
   rdf:rest ?ob2.
  ?oa2 rdfs:label ?oal2.
  FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
  FILTER(isBlank(?ob2))
  FILTER (?ot2 = owl:intersectionOf)
  ?ob2 rdf:first ?ob21.
  ?ob21 owl:onProperty ?prop3;
   ?op3 ?o3.
  FILTER (?op3 != owl:onProperty)
  FILTER (?o3 != owl:Restriction)
 ?prop3 rdfs:label ?pl3.
  optional {
   ?o3 rdfs:label ?ol3.
   FILTER (lang(?ol3) = '" . $lang . "' || lang(?ol3) = '')
  }
 } union {
  ?o2 ?ot2 ?bl2.
  FILTER (isBlank(?bl2))
  ?bl2 rdf:rest* ?bl3.
  ?bl3 rdf:first ?oa2.
  ?oa2 rdfs:label ?oal2.
  FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
  FILTER (?ot2 = owl:unionOf)
 }

 optional {
  {
  ?o3 ?ot3 ?bl3.
  FILTER (isBlank(?bl3))
  ?bl3 rdf:first ?oa3;
   rdf:rest ?ob3.
  ?oa3 rdfs:label ?oal3.
  FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
  FILTER(isBlank(?ob3))
    FILTER (?ot3 = owl:intersectionOf)
  ?ob3 rdf:first ?ob31.
  ?ob31 owl:onProperty ?prop4;
   ?op4 ?o4.
  FILTER (?op4 != owl:onProperty)
  FILTER (?o4 != owl:Restriction)
  ?prop4 rdfs:label ?pl4.
  optional {
   ?o4 rdfs:label ?ol4.
   FILTER (lang(?ol4) = '" . $lang . "' || lang(?ol4) = '')
  }
 } union {
  ?o3 ?ot3 ?bl3.
  FILTER (isBlank(?bl3))
  ?bl3 rdf:rest* ?bl4.
  ?bl4 rdf:first ?oa3.
  ?oa3 rdfs:label ?oal3.
  FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
  FILTER (?ot3 = owl:unionOf)
 }
 }


 }
}";

	// TODO owl:complementOf をunionで繋ぐ

//		echo($query);

	$tmp_concept = $http->get($query);
	$word = null;
	$objects = [];
	$dic = [];
	if (isset($ret['dic'])){
		$dic = $ret['dic'];
	}

	$p = null;
	foreach ($tmp_concept as $datum){

		// spo
		$list = null;
		if (isset($objects[$datum['o']['value']])){
			$list = $objects[$datum['o']['value']];
		} else {
			$list = [];
		}
		if (!contains_data($list, $datum)){
			$list[] = $datum;
		}
		$objects[$datum['o']['value']] = $list;

		$list = null;
		if (isset($datum['o'])){
			if (isset($dic[$datum['o']['value']])){
				$list = $dic[$datum['o']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol'])){
				$ol = $datum['ol'];
				if (!contains($list, $ol)){
					$list[] = $ol;
				}
				$dic[$datum['o']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa1'])){
			if (isset($dic[$datum['oa1']['value']])){
				$list = $dic[$datum['oa1']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal1'])){
				$oal1 = $datum['oal1'];
				if (!contains($list, $oal1)){
					$list[] = $oal1;
				}
				$dic[$datum['oa1']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o2'])){
			if (isset($dic[$datum['o2']['value']])){
				$list = $dic[$datum['o2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol2'])){
				$ol2 = $datum['ol2'];
				if (!contains($list, $ol2)){
					$list[] = $ol2;
				}
				$dic[$datum['o2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa2'])){
			if (isset($dic[$datum['oa2']['value']])){
				$list = $dic[$datum['oa2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal2'])){
				$oal2 = $datum['oal2'];
				if (!contains($list, $oal2)){
					$list[] = $oal2;
				}
				$dic[$datum['oa2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o3'])){
			if (isset($dic[$datum['o3']['value']])){
				$list = $dic[$datum['o3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol3'])){
				$ol3 = $datum['ol3'];
				if (!contains($list, $ol3)){
					$list[] = $ol3;
				}
				$dic[$datum['o3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa3'])){
			if (isset($dic[$datum['oa3']['value']])){
				$list = $dic[$datum['oa3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal3'])){
				$oal3 = $datum['oal3'];
				if (!contains($list, $oal3)){
					$list[] = $oal3;
				}
				$dic[$datum['oa3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o4'])){
			if (isset($dic[$datum['o4']['value']])){
				$list = $dic[$datum['o4']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol4'])){
				$ol3 = $datum['ol4'];
				if (!contains($list, $ol4)){
					$list[] = $ol4;
				}
				$dic[$datum['o4']['value']] = $list;
			}
		}

	}
	$ret['equivalents'] = $objects;
	$ret['dic'] = $dic;

	return $ret;
}


function get_object(&$ret){
	global $const, $http, $id, $lang;
	$query =
/*
	"
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl:<http://www.w3.org/2002/07/owl#>
	select distinct ?pl ?op ?o ?ol {
	 <" . $id . "> ?p ?oo.
	 ?oo owl:onProperty ?prop;
	    ?op ?o.
	 FILTER (?op != owl:onProperty)
	 ?prop rdfs:label ?pl.
	 ?o rdfs:label ?ol.
	 FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
	}";
*/
	"
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
select distinct ?pl ?op ?o ?ol ?oa1 ?ot1 ?oal1 ?pl2 ?op2 ?o2 ?ol2 ?oa2 ?ot2 ?oal2 ?pl3 ?op3 ?o3 ?ol3 ?oa3 ?ot3 ?oal3 ?pl4 ?op4 ?o4 ?ol4 {
 <" . $id . "> ?p ?oo.
FILTER (?p != owl:equivalentClass)
  {
 ?oo owl:onProperty ?prop;
 ?op ?o.
 FILTER (?op != owl:onProperty)
 FILTER (?o != owl:Restriction)
 ?prop rdfs:label ?pl.
 optional {
  ?o rdfs:label ?ol.
   FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
 }
  } union {
    ?oo ?ot1 ?bl1.
  FILTER (?ot1 = owl:complementOf)
  FILTER (isBlank(?bl1))
   ?bl1 owl:onProperty ?prop;
 ?op ?o.
 FILTER (?op != owl:onProperty)
 FILTER (?o != owl:Restriction)
 ?prop rdfs:label ?pl.
 optional {
  ?o rdfs:label ?ol.
   FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
 }
 } union {
  ?oo ?ot1 ?bl1.
    BIND(?oo as ?o)
  FILTER (?ot1 = owl:complementOf)
  FILTER (isBlank(?bl1))
  ?bl1 owl:onProperty ?prop;
   ?op ?o.
  FILTER (?op != owl:onProperty)
  FILTER (?o != owl:Restriction)
  ?prop rdfs:label ?pl.
  optional {
   ?o rdfs:label ?ol.
   FILTER (lang(?ol) = 'ja')
  }
 } union{
  ?oo ?ot1 ?bl1.
  BIND(?oo as ?o)
  FILTER (isBlank(?bl1))
  ?bl1 rdf:first ?oa1;
   rdf:rest ?ob1.
  ?oa1 rdfs:label ?oal1.
  FILTER (lang(?oal1) = 'ja')
  FILTER(isBlank(?ob1))
  FILTER (?ot1 = owl:intersectionOf)
  ?ob1 rdf:first ?ob11.
  ?ob11 owl:onProperty ?prop2;
   ?op2 ?o2.
  FILTER (?op2 != owl:onProperty)
  FILTER (?o2 != owl:Restriction)
  ?prop2 rdfs:label ?pl2.
  optional {
   ?o2 rdfs:label ?ol2.
   FILTER (lang(?ol2) = 'ja')
  }
 }

 optional {
 {
  ?o ?ot1 ?bl1.
  FILTER (isBlank(?bl1))
  ?bl1 rdf:first ?oa1;
   rdf:rest ?ob1.
  ?oa1 rdfs:label ?oal1.
  FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
  FILTER(isBlank(?ob1))
  FILTER (?ot1 = owl:intersectionOf)
  ?ob1 rdf:first ?ob11.
  ?ob11 owl:onProperty ?prop2;
   ?op2 ?o2.
  FILTER (?op2 != owl:onProperty)
  FILTER (?o2 != owl:Restriction)
  ?prop2 rdfs:label ?pl2.
  optional {
   ?o2 rdfs:label ?ol2.
   FILTER (lang(?ol2) = '" . $lang . "' || lang(?ol2) = '')
  }
 } union {
  ?o ?ot1 ?bl1.
  FILTER (isBlank(?bl1))
  ?bl1 rdf:rest* ?bl2.
  ?bl2 rdf:first ?oa1.
  ?oa1 rdfs:label ?oal1.
  FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
  FILTER (?ot1 = owl:unionOf)
 }

 optional {
 {
  ?o2 ?ot2 ?bl2.
  FILTER (isBlank(?bl2))
  ?bl2 rdf:first ?oa2;
   rdf:rest ?ob2.
  ?oa2 rdfs:label ?oal2.
  FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
  FILTER(isBlank(?ob2))
  FILTER (?ot2 = owl:intersectionOf)
  ?ob2 rdf:first ?ob21.
  ?ob21 owl:onProperty ?prop3;
   ?op3 ?o3.
  FILTER (?op3 != owl:onProperty)
  FILTER (?o3 != owl:Restriction)
 ?prop3 rdfs:label ?pl3.
  optional {
   ?o3 rdfs:label ?ol3.
   FILTER (lang(?ol3) = '" . $lang . "' || lang(?ol3) = '')
  }
 } union {
  ?o2 ?ot2 ?bl2.
  FILTER (isBlank(?bl2))
  ?bl2 rdf:rest* ?bl3.
  ?bl3 rdf:first ?oa2.
  ?oa2 rdfs:label ?oal2.
  FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
  FILTER (?ot2 = owl:unionOf)
 }

 optional {
  {
  ?o3 ?ot3 ?bl3.
  FILTER (isBlank(?bl3))
  ?bl3 rdf:first ?oa3;
   rdf:rest ?ob3.
  ?oa3 rdfs:label ?oal3.
  FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
  FILTER(isBlank(?ob3))
    FILTER (?ot3 = owl:intersectionOf)
  ?ob3 rdf:first ?ob31.
  ?ob31 owl:onProperty ?prop4;
   ?op4 ?o4.
  FILTER (?op4 != owl:onProperty)
  FILTER (?o4 != owl:Restriction)
  ?prop4 rdfs:label ?pl4.
  optional {
   ?o4 rdfs:label ?ol4.
   FILTER (lang(?ol4) = '" . $lang . "' || lang(?ol4) = '')
  }
 } union {
  ?o3 ?ot3 ?bl3.
  FILTER (isBlank(?bl3))
  ?bl3 rdf:rest* ?bl4.
  ?bl4 rdf:first ?oa3.
  ?oa3 rdfs:label ?oal3.
  FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
  FILTER (?ot3 = owl:unionOf)
 }
 }

 }
 }
}";

	// TODO owl:complementOf をunionで繋ぐ

//	echo($query);

	$tmp_concept = $http->get($query);
	$word = null;
	$objects = [];
	$dic = [];
	if (isset($ret['dic'])){
		$dic = $ret['dic'];
	}

	$p = null;
	foreach ($tmp_concept as $datum){

		// spo
		$list = null;
		if (isset($objects[$datum['o']['value']])){
			$list = $objects[$datum['o']['value']];
		} else {
			$list = [];
		}
		if (!contains_data($list, $datum)){
			$list[] = $datum;
		}
		$objects[$datum['o']['value']] = $list;

		$list = null;
		if (isset($datum['o'])){
			if (isset($dic[$datum['o']['value']])){
				$list = $dic[$datum['o']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol'])){
				$ol = $datum['ol'];
				if (!contains($list, $ol)){
					$list[] = $ol;
				}
				$dic[$datum['o']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa1'])){
			if (isset($dic[$datum['oa1']['value']])){
				$list = $dic[$datum['oa1']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal1'])){
				$oal1 = $datum['oal1'];
				if (!contains($list, $oal1)){
					$list[] = $oal1;
				}
				$dic[$datum['oa1']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o2'])){
			if (isset($dic[$datum['o2']['value']])){
				$list = $dic[$datum['o2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol2'])){
				$ol2 = $datum['ol2'];
				if (!contains($list, $ol2)){
					$list[] = $ol2;
				}
				$dic[$datum['o2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa2'])){
			if (isset($dic[$datum['oa2']['value']])){
			$list = $dic[$datum['oa2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal2'])){
				$oal2 = $datum['oal2'];
				if (!contains($list, $oal2)){
					$list[] = $oal2;
				}
				$dic[$datum['oa2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o3'])){
			if (isset($dic[$datum['o3']['value']])){
				$list = $dic[$datum['o3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol3'])){
				$ol3 = $datum['ol3'];
				if (!contains($list, $ol3)){
					$list[] = $ol3;
				}
				$dic[$datum['o3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa3'])){
			if (isset($dic[$datum['oa3']['value']])){
				$list = $dic[$datum['oa3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal3'])){
				$oal3 = $datum['oal3'];
				if (!contains($list, $oal3)){
					$list[] = $oal3;
				}
				$dic[$datum['oa3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o4'])){
			if (isset($dic[$datum['o4']['value']])){
				$list = $dic[$datum['o4']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol4'])){
				$ol3 = $datum['ol4'];
				if (!contains($list, $ol4)){
					$list[] = $ol4;
				}
				$dic[$datum['o4']['value']] = $list;
			}
		}

	}
	$ret['objects'] = $objects;
	$ret['dic'] = $dic;

	return $ret;
}

// TODO inheritでもandの処理を追加
function get_inherit_object(&$ret){
	global $const, $http, $id, $lang;
	$query =
	/*
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl:<http://www.w3.org/2002/07/owl#>
	select distinct ?pl ?op ?o ?ol
	{
	 <" . $id . "> rdfs:subClassOf+ ?prnt.
	?prnt ?p ?oo.
	 ?oo owl:onProperty ?prop;
	    ?op ?o.
	 FILTER (?op != owl:onProperty)
	 ?prop rdfs:label ?pl.
	 ?o rdfs:label ?ol.
	 FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
	}";*/
	"
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
select distinct ?prnt ?pl ?op ?o ?ol ?oa1 ?ot1 ?oal1 ?pl2 ?op2 ?o2 ?ol2 ?oa2 ?ot2 ?oal2 ?pl3 ?op3 ?o3 ?ol3 ?oa3 ?ot3 ?oal3 ?pl4 ?op4 ?o4 ?ol4 {
 <" . $id . "> rdfs:subClassOf+ ?prnt.
 ?prnt ?p ?oo.
 {
  ?oo owl:onProperty ?prop;
  ?op ?o.
  FILTER (?op != owl:onProperty)
  FILTER (?o != owl:Restriction)
  ?prop rdfs:label ?pl.
  optional {
   ?o rdfs:label ?ol.
   FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
  }
 } union {
  <" . $id . "> rdfs:subClassOf+ ?prnt.
  ?prnt ?p ?oo.
  ?oo ?ot1 ?bl1.
  FILTER (?ot1 = owl:complementOf)
  FILTER (isBlank(?bl1))
  ?bl1 owl:onProperty ?prop;
   ?op ?o.
  FILTER (?op != owl:onProperty)
  FILTER (?o != owl:Restriction)
  ?prop rdfs:label ?pl.
  optional {
   ?o rdfs:label ?ol.
   FILTER (lang(?ol) = '" . $lang . "' || lang(?ol) = '')
  }
 }

 union {
  ?oo ?ot1 ?o.
  FILTER (isBlank(?o))
  ?o rdf:first ?oa1;
   rdf:rest ?ob1.
  ?oa1 rdfs:label ?oal1.
  FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
  FILTER(isBlank(?ob1))
  ?ob1 rdf:first ?ob11.
  ?ob11 owl:onProperty ?prop2;
   ?op2 ?o2.
  FILTER (?op2 != owl:onProperty)
  FILTER (?o2 != owl:Restriction)
  ?prop2 rdfs:label ?pl2.
  optional {
   ?o2 rdfs:label ?ol2.
   FILTER (lang(?ol2) = '" . $lang . "' || lang(?ol2) = '')
  }
 }

 optional {
  {
   ?o ?ot1 ?bl1.
   FILTER (isBlank(?bl1))
   ?bl1 rdf:first ?oa1;
    rdf:rest ?ob1.
   ?oa1 rdfs:label ?oal1.
   FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
   FILTER(isBlank(?ob1))
   FILTER (?ot1 = owl:intersectionOf)
   ?ob1 rdf:first ?ob11.
   ?ob11 owl:onProperty ?prop2;
    ?op2 ?o2.
   FILTER (?op2 != owl:onProperty)
   FILTER (?o2 != owl:Restriction)
   ?prop2 rdfs:label ?pl2.
   optional {
    ?o2 rdfs:label ?ol2.
    FILTER (lang(?ol2) = '" . $lang . "' || lang(?ol2) = '')
   }
  } union {
   ?o ?ot1 ?bl1.
   FILTER (isBlank(?bl1))
   ?bl1 rdf:rest* ?bl2.
   ?bl2 rdf:first ?oa1.
   ?oa1 rdfs:label ?oal1.
   FILTER (lang(?oal1) = '" . $lang . "' || lang(?oal1) = '')
   FILTER (?ot1 = owl:unionOf)
  }
  union {
   <" . $id . "> rdfs:subClassOf+ ?prnt.
   ?prnt owl:equivalentClass ?oo.
   ?oo ?ot1 ?bl1.
   BIND(?oo as ?o)
   FILTER (?ot1 = owl:complementOf)
   FILTER (isBlank(?bl1))
   ?bl1 owl:onProperty ?prop;
    ?op ?o.
   FILTER (?op != owl:onProperty)
   FILTER (?o != owl:Restriction)
   ?prop rdfs:label ?pl.
   optional {
    ?o rdfs:label ?ol.
    FILTER (lang(?ol) = 'ja')
   }
  } union{
   <" . $id . "> rdfs:subClassOf+ ?prnt.
   ?prnt owl:equivalentClass ?oo.
   ?oo ?ot1 ?bl1.
   BIND(?oo as ?o)
   FILTER (isBlank(?bl1))
   ?bl1 rdf:first ?oa1;
    rdf:rest ?ob1.
   ?oa1 rdfs:label ?oal1.
   FILTER (lang(?oal1) = 'ja')
   FILTER(isBlank(?ob1))
   FILTER (?ot1 = owl:intersectionOf)
   ?ob1 rdf:first ?ob11.
   ?ob11 owl:onProperty ?prop2;
    ?op2 ?o2.
   FILTER (?op2 != owl:onProperty)
   FILTER (?o2 != owl:Restriction)
   ?prop2 rdfs:label ?pl2.
   optional {
    ?o2 rdfs:label ?ol2.
    FILTER (lang(?ol2) = 'ja')
   }
  }

  optional {
   {
    ?o2 ?ot2 ?bl2.
    FILTER (isBlank(?bl2))
    ?bl2 rdf:first ?oa2;
     rdf:rest ?ob2.
    ?oa2 rdfs:label ?oal2.
    FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
    FILTER(isBlank(?ob2))
    FILTER (?ot2 = owl:intersectionOf)
    ?ob2 rdf:first ?ob21.
    ?ob21 owl:onProperty ?prop3;
     ?op3 ?o3.
    FILTER (?op3 != owl:onProperty)
    FILTER (?o3 != owl:Restriction)
    ?prop3 rdfs:label ?pl3.
    optional {
     ?o3 rdfs:label ?ol3.
     FILTER (lang(?ol3) = '" . $lang . "' || lang(?ol3) = '')
    }
   } union {
    ?o2 ?ot2 ?bl2.
    FILTER (isBlank(?bl2))
    ?bl2 rdf:rest* ?bl3.
    ?bl3 rdf:first ?oa2.
    ?oa2 rdfs:label ?oal2.
    FILTER (lang(?oal2) = '" . $lang . "' || lang(?oal2) = '')
    FILTER (?ot2 = owl:unionOf)
   }

   optional {
    {
     ?o3 ?ot3 ?bl3.
     FILTER (isBlank(?bl3))
     ?bl3 rdf:first ?oa3;
      rdf:rest ?ob3.
     ?oa3 rdfs:label ?oal3.
     FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
     FILTER(isBlank(?ob3))
     FILTER (?ot3 = owl:intersectionOf)
     ?ob3 rdf:first ?ob31.
     ?ob31 owl:onProperty ?prop4;
      ?op4 ?o4.
     FILTER (?op4 != owl:onProperty)
     FILTER (?o4 != owl:Restriction)
     ?prop4 rdfs:label ?pl4.
     optional {
      ?o4 rdfs:label ?ol4.
      FILTER (lang(?ol4) = '" . $lang . "' || lang(?ol4) = '')
     }
    } union {
     ?o3 ?ot3 ?bl3.
     FILTER (isBlank(?bl3))
     ?bl3 rdf:rest* ?bl4.
     ?bl4 rdf:first ?oa3.
     ?oa3 rdfs:label ?oal3.
     FILTER (lang(?oal3) = '" . $lang . "' || lang(?oal3) = '')
     FILTER (?ot3 = owl:unionOf)
    }
   }
  }
 }
}";

//		echo($query);

	$tmp_concept = $http->get($query);
	$word = null;
	$objects = [];
	$dic = [];
	if (isset($ret['dic'])){
		$dic = $ret['dic'];
	}

	$p = null;
	foreach ($tmp_concept as $datum){

		if (!isset($datum['prnt']) || $datum['prnt']['type'] == 'bnode'){
			continue;
		}

		// spo
		$list = null;
		if (isset($objects[$datum['o']['value']])){
			$list = $objects[$datum['o']['value']];
		} else {
			$list = [];
		}
		if (!contains_data($list, $datum)){
			$list[] = $datum;
		}
		$objects[$datum['o']['value']] = $list;

		$list = null;
		if (isset($datum['o'])){
			if (isset($dic[$datum['o']['value']])){
				$list = $dic[$datum['o']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol'])){
				$ol = $datum['ol'];
				if (!contains($list, $ol)){
					$list[] = $ol;
				}
				$dic[$datum['o']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa1'])){
			if (isset($dic[$datum['oa1']['value']])){
				$list = $dic[$datum['oa1']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal1'])){
				$oal1 = $datum['oal1'];
				if (!contains($list, $oal1)){
					$list[] = $oal1;
				}
				$dic[$datum['oa1']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o2'])){
			if (isset($dic[$datum['o2']['value']])){
				$list = $dic[$datum['o2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol2'])){
				$ol2 = $datum['ol2'];
				if (!contains($list, $ol2)){
					$list[] = $ol2;
				}
				$dic[$datum['o2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa2'])){
			if (isset($dic[$datum['oa2']['value']])){
				$list = $dic[$datum['oa2']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal2'])){
				$oal2 = $datum['oal2'];
				if (!contains($list, $oal2)){
					$list[] = $oal2;
				}
				$dic[$datum['oa2']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o3'])){
			if (isset($dic[$datum['o3']['value']])){
				$list = $dic[$datum['o3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol3'])){
				$ol3 = $datum['ol3'];
				if (!contains($list, $ol3)){
					$list[] = $ol3;
				}
				$dic[$datum['o3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['oa3'])){
			if (isset($dic[$datum['oa3']['value']])){
				$list = $dic[$datum['oa3']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['oal3'])){
				$oal3 = $datum['oal3'];
				if (!contains($list, $oal3)){
					$list[] = $oal3;
				}
				$dic[$datum['oa3']['value']] = $list;
			}
		}

		$list = null;
		if (isset($datum['o4'])){
			if (isset($dic[$datum['o4']['value']])){
				$list = $dic[$datum['o4']['value']];
			} else {
				$list = [];
			}
			if (isset($datum['ol4'])){
				$ol4 = $datum['ol4'];
				if (!contains($list, $ol4)){
					$list[] = $ol4;
				}
				$dic[$datum['o4']['value']] = $list;
			}
		}

	}
	$ret['inherits'] = $objects;
	$ret['dic'] = $dic;

	return $ret;
}


function get_mappings(&$ret){
	global $id;

	$tmp = get_concept_mappings($id);

	$ret['mapping'] = $tmp;

	return $ret;
}

function contains_data($list, $datum){
	foreach($list as $item){
		if (isset($item['ol'])){
			if ($item['ol']['value'] == $datum['ol']['value']){
				if (!isset($item['ot1']) && isset($datum['ot1'])){
					return false;
				} else {
					return true;
				}
			}
		}
	}
	return false;
}

function get_molecule_course($gene_processes){
	$ary = [];
	$ret = [];

	foreach($gene_processes as $key => $process){
		if (isset($process['course'])){
			$courses = $process['course'];
			foreach ($courses as $course){
				if (!in_array($course['id'], $ary)){
					$ret[] = $course;
					$ary[] = $course['id'];
				}
			}

		}
	}
	return $ret;
}

/*
$hit = false;

if (!get_compound($ret)){
	$hit = get_morecule($ret);
} else {
	$hit = true;
}
if (!$hit){
	get_process($ret);
}
*/
get_annotation($ret);
get_equivalent($ret);
get_object($ret);
get_inherit_object($ret);

if ($external !== 'false'){
	get_mappings($ret);
}

// TODO 種別ごとに固有情報を追加

if ($ret['type'] == 'course'){
	//　作用機序の時は分子・遺伝子情報一覧を付加
	$gene_processes = get_gene_course($id, $lang, $const);
	$ret['genes'] = $gene_processes;
}

if ($ret['type'] == 'process'){
	// 所属する作用機序情報を付加
	$process_courses = get_process_course($id, $lang, $const);
	$ret['courses'] = $process_courses;
}

if ($ret['type'] == 'molecule'){
	//　作用機序の時は分子・遺伝子情報一覧を付加
	$gene_processes = get_gene_molecule($id, $lang, $const);
	$ret['genes'] = $gene_processes;
//	$process_courses = get_process_course($id, $lang, $const);
	$process_courses = get_molecule_course($gene_processes);
	$ret['courses'] = $process_courses;
}
if ($ret['type'] == 'role'){
	//　作用機序の時は分子・遺伝子情報一覧を付加
	$gene_processes = get_gene_role($id, $lang, $const);
	$ret['genes'] = $gene_processes;
}
if ($ret['type'] == 'finding'){
	//　作用機序の時は分子・遺伝子情報一覧を付加
	$gene_processes = get_gene_finding($id, $lang, $const);
	$ret['genes'] = $gene_processes;
	$process_courses = get_process_course($id, $lang, $const);
	$ret['courses'] = $process_courses;
	$process_relation = get_process_relation($id, $lang, $const);
	$ret['processes'] = $process_relation;
}
if ($ret['type'] == 'structure'){
	//　作用機序の時は分子・遺伝子情報一覧を付加
	$gene_processes = get_gene_structure($id, $lang, $const);
	$ret['genes'] = $gene_processes;
	$process_courses = get_process_course($id, $lang, $const, $const['DATA_OCCURS_IN']);
	$ret['courses'] = $process_courses;
	$process_relation = get_process_relation($id, $lang, $const);
	$ret['processes'] = $process_relation;
}


function contains($list, $elm){
	foreach ($list as $item){
		$hit = true;
		foreach ($item as $key => $value){
			if (isset($elm[$key])){
				if (json_encode($value) != json_encode($elm[$key])){
					$hit = false;
					break;
				}
			}
		}
		if ($hit){
			return $hit;
		}
	}
	return false;
}



//var_dump($ret);

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>