<?php
// 作用機序マップデータ取得用

ini_set('xdebug.var_display_max_children', -1);
ini_set('xdebug.var_display_max_data', -1);
ini_set('xdebug.var_display_max_depth', -1);


include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";
include_once "get_data_gene_course_lib.php";


if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}

$type_id = null;
if (array_key_exists('type', $args)){
	$type_id = $args['type'];
}
if ($type_id == null || $type_id == ''){
	$type_id = 'rp';
}


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);


$gene_map = array();

//$tmp_processes = get_gene_course($id, $lang, $const);
$tmp_processes = get_gene_course(null, $lang, $const);
//exit();
foreach ($tmp_processes as $process){
	foreach ($process['gene'] as $gene){
		$gene_type = '';
		foreach ($gene['assay'] as $assay){
			if (isset($assay['t']) && strpos($gene_type, $assay['t']) === false){
				$gene_type .= $assay['t'].' ';
			}
		}
		foreach ($gene['being'] as $being){
			if (isset($being['t']) && strpos($gene_type, $being['t']) === false){
				$gene_type .= $being['t'].' ';
			}
		}
		$gene_type = trim($gene_type);
		if ($gene_type == ''){
			$gene_type  ="canonical";
		}
//echo $gene['id']." ->" . $gene_type ."<br>\n";
		$gene_map[$gene['id']] = $gene_type;
	}
}

//var_dump($tmp_processes);
//var_dump($gene_map);


$type = [];

foreach ($type_map as $key => $value){
	if (strpos($type_id, $key) !== false){
		$type[] = $value['id'];
	}
}

//$type = ['hasResult', 'has_part'];

$http = new Http();

$courses = [];


// コアプロセスの取得
/*
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
"select distinct ?parent ?os\n".
"{\n".
"<" . $id . "> rdfs:subClassOf* ?parent.
?parent rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
 rdfs:subClassOf ?n.
    ?n owl:onProperty <" . $const['DATA_HAS_PART'] . ">;
       owl:someValuesFrom ?os.
 FILTER (isIri(?os))
}";
*/
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
"select distinct ?parent ?os\n".
"{\n".
"<" . $id . "> rdfs:subClassOf* ?parent.
?parent rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
 rdfs:subClassOf ?n.
    ?n owl:onProperty <" . $const['DATA_HAS_CORE_PROCESS'] . ">;
       (owl:someValuesFrom|owl:someValuesFrom) ?os.
 FILTER (isIri(?os))
}";

$tmp = $http->get($query);
$cores = array();
$mycores = array();
foreach ($tmp as $core){
	$cores[] = $core['os']['value'];

	if (!in_array($core['parent']['value'], $courses)){
		$courses[] = $core['parent']['value'];
	}

	if ($core['parent']['value'] == $id){
		$mycores[] = $core['os']['value'];
	}
}



// 作用機序のhas_partではなくいきなりsubClassOfで関連を取ってくるパターン
// おそらくこれでいける

$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?ancestor ?parent ?process ?label ?rtype ?rancestor ?rparent ?relation ?rlabel
{
 {
  {
   {
  <" . $id . "> rdfs:subClassOf* ?parents.
  ?parents rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   (rdfs:subClassOf/(owl:someValuesFrom|owl:allValuesFrom))* ?process.
  minus {
    ?process rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.
    }
   } minus {
    {
  ?crs rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   rdfs:subClassOf ?cn.
  ?cn owl:onProperty <" . $const['DATA_HAS_PART'] . ">;
      (owl:someValuesFrom|owl:allValuesFrom) ?process.
    } minus {
  <" . $id ."> rdfs:subClassOf* ?parents.
  ?parents rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   rdfs:subClassOf ?cn2.
  ?cn2 owl:onProperty <" . $const['DATA_HAS_PART'] . ">;
   (owl:someValuesFrom|owl:allValuesFrom) ?process.
    }
   }
  ?process rdfs:label ?label;
    rdfs:subClassOf ?parent.
  FILTER (isIri(?parent))
  FILTER(lang(?label) = '" . $lang . "')
  } optional {
   {
    {
 ?process rdfs:subClassOf ?n1.
 ?n1 owl:onProperty ?rtype;
  (owl:someValuesFrom|owl:allValuesFrom) ?relation.
 ?relation rdfs:label ?rlabel;
    rdfs:subClassOf ?rparent.
 FILTER (isIri(?rparent))
 FILTER (lang(?rlabel) = '" . $lang . "')
 FILTER (isBlank(?n1))
    } minus {
     {
  ?crs rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   rdfs:subClassOf ?cn.
  ?cn owl:onProperty <" . $const['DATA_HAS_PART'] . ">;
      (owl:someValuesFrom|owl:allValuesFrom) ?relation.
     } minus {
  <" . $id ."> rdfs:subClassOf* ?parents.
  ?parents rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   rdfs:subClassOf ?cn2.
  ?cn2 owl:onProperty <" . $const['DATA_HAS_PART'] . ">;
   (owl:someValuesFrom|owl:allValuesFrom) ?relation.
     }
    } minus {
        ?relation rdfs:subClassOf+ <" . $const['DATA_ANATOMICAL_ENTITY'] . ">.
    }
   } optional {
   ?rparent rdfs:subClassOf* ?rancestor.
   ?rancestor rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.
   }
  }
 } optional {
   ?parent rdfs:subClassOf* ?ancestor.
      ?ancestor rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.
 }
} order by (lang(?label))";

//echo $query;

$data = $http->get($query);


$ret = array();
$ret['concepts'] = array();
$ret['relations'] = array();


// ancestors
// 子が持つ親一覧をマップに格納する
$parent_map = array();

// 直上の親のみ
$parent_map2 = array();


foreach ($data as $datum){
/*
	if (!array_key_exists('rtype', $datum) || in_array($datum['rtype']['value'], $type)){

	} else {
		continue;
	}
*/

	if (isset($datum['ancestor'])){
		if (!array_key_exists($datum['process']['value'], $parent_map)){
			$parent_map[$datum['process']['value']] = [$datum['ancestor']['value']];
		}
		$list = &$parent_map[$datum['process']['value']];
		if (!in_array($datum['ancestor']['value'], $list) && !in_array($datum['ancestor']['value'], $mycores)){
			$list[] = $datum['ancestor']['value'];
		}
	} else {
		if (isset($datum['parent']) && !isGene($gene_map, [$datum['parent'], $datum['process']])){
			if (!array_key_exists($datum['process']['value'], $parent_map)){
				$parent_map[$datum['process']['value']] = [$datum['parent']['value']];
			}
			$list = &$parent_map[$datum['process']['value']];
			if (!in_array($datum['parent']['value'], $list) && !in_array($datum['parent']['value'], $mycores)){
				$list[] = $datum['parent']['value'];
			}
		}
	}
	if (isset($datum['rancestor'])){
		if (!array_key_exists($datum['relation']['value'], $parent_map)){
			$parent_map[$datum['relation']['value']] = [$datum['rancestor']['value']];
		}
		$list = &$parent_map[$datum['relation']['value']];
		if (!in_array($datum['rancestor']['value'], $list) && !in_array($datum['rancestor']['value'], $mycores)){
			$list[] = $datum['rancestor']['value'];
		}
	} else {
		if (isset($datum['rparent']) && !isGene($gene_map, [$datum['rparent'], $datum['relation']])){
			if (!array_key_exists($datum['relation']['value'], $parent_map)){
				$parent_map[$datum['relation']['value']] = [$datum['rparent']['value']];
			}
			$list = &$parent_map[$datum['relation']['value']];
			if (!in_array($datum['relation']['value'], $list) && !in_array($datum['rparent']['value'], $mycores)){
				$list[] = $datum['relation']['value'];
			}
		}
	}

	if (isset($datum['parent']) && !isGene($gene_map, [$datum['parent'], $datum['process']])){
		if (!array_key_exists($datum['process']['value'], $parent_map2)){
			$parent_map2[$datum['process']['value']] = [$datum['parent']['value']];
		}
		$list = &$parent_map2[$datum['process']['value']];
		if (!in_array($datum['parent']['value'], $list) && !in_array($datum['parent']['value'], $mycores)){
			$list[] = $datum['parent']['value'];
		}
	}
	if (isset($datum['rparent']) && !isGene($gene_map, [$datum['rparent'], $datum['relation']])){
		if (!array_key_exists($datum['relation']['value'], $parent_map2)){
			$parent_map2[$datum['relation']['value']] = [$datum['rparent']['value']];
		}
		$list = &$parent_map2[$datum['relation']['value']];
		if (!in_array($datum['rparent']['value'], $list) && !in_array($datum['rparent']['value'], $mycores)){
			$list[] = $datum['rparent']['value'];
		}
	}

}
// 遺伝子ノードかチェック
function isGene($gene_map, $data){
	foreach ($data as $datum){
		if (isset($gene_map[$datum['value']])){
			return true;
		}
	}
	return false;
}

//var_dump ($data);

//var_dump ($parent_map);

// TODO rparentの親になっているものは子に纏めて削除してよいのではないか


// concepts / relations
// conceptsにはid,parent,label情報
// relationsにはfrom-to, label, series情報


$relations = array();

$dic = [];

// まずはrelationを抽出
foreach ($data as $datum){

//	$ret['concepts'][] = ['p'=>$datum['parent']['value'], 's'=>$datum['process']['value'], 'l'=>$datum['label']];

	if (array_key_exists('rtype', $datum) && in_array($datum['rtype']['value'], $type)){

		$hit = false;
		foreach ($relations as $relation){

			if ($relation['f'] == $datum['process']['value'] && $relation['t'] == $datum['relation']['value']){
				$hit = true;
				break;
			}
		}
		if (!$hit){

			// TODO 一つの親を複数の子が継承しているパターン入力には対応できない
			$f = $datum['process']['value'];
			$t = $datum['relation']['value'];

			if (count($courses) > 1){
				// 階層が存在する場合は子を優先
				// （TODO 適切な処理ではないので要再検討）
				foreach ($parent_map as $key => $value){
					if (in_array($f, $value)){
						$f = $key;
					}
					if (in_array($t, $value)){
						$t = $key;
					}
				}
			}

			$relations[] = ['f'=>$f, 't'=>$t, 'l'=>$const_label[$datum['rtype']['value']], "s"=>$id];
		}
	}

}

//var_dump($relations);


$relation_groups = [];

// relationをグループにまとめる
foreach ($relations as $relation){
	$group = null;
	$group_f = null;
	$group_t = null;
	$index_f;
	$index_t;
//	echo('f:'.$relation['f']. " t:".$relation['t']."\n");
	foreach ($relation_groups as $relation_group){
		if (in_array($relation['f'], $relation_group)){
			$index_f = array_search($relation_group, $relation_groups);
			$group_f = $relation_group;
			break;
		}
	}
	foreach ($relation_groups as $relation_group){
		if (in_array($relation['t'], $relation_group)){
			$index_t = array_search($relation_group, $relation_groups);
			$group_t = $relation_group;
			break;
		}
	}
	if ($group_f == null && $group_t == null){
		$group = [];
	}
	if ($group_f == null && $group_t != null){
		$group = $group_t;
	}
	if ($group_f != null && $group_t == null){
		$group = $group_f;
	}
	if ($group_f != null && $group_t != null){
//echo ($index_f . ":"); var_dump($group_f);
//echo ($index_t . ":"); var_dump($group_t);
//echo ($index_f.":".$index_t);
//echo ("----\n");
		if ($index_f == $index_t){
			$group = $group_f;
		} else {
//var_dump($relation_groups);
//echo ("------->\n");
			if ($index_f > $index_t){
				array_splice($relation_groups, $index_f,1);
				array_splice($relation_groups, $index_t,1);
			} else {
				array_splice($relation_groups, $index_t,1);
				array_splice($relation_groups, $index_f,1);
			}
			$relation_groups = array_values($relation_groups);
			$group = array_unique(array_merge($group_f, $group_t));
//var_dump($relation_groups);
//echo ("-------\n");
		}
	}
	if (!in_array($relation['f'], $group)){
		$group[] = $relation['f'];
	}
	if (!in_array($relation['t'], $group)){
		$group[] = $relation['t'];
	}
//	$group = array_unique($group);
	if (!in_array($group, $relation_groups)){
		$relation_groups[] = $group;
	}
}
//var_dump($relation_groups);


// 有効な関連ノードを抽出
$valid_relation = [];
foreach ($relation_groups as $relation_group){
	$hit = false;
	foreach ($relation_group as $relation){
		if (in_array($relation, $cores)){
			$hit = true;
			break;
		}
	}
	if ($hit){
		$valid_relation = array_merge($valid_relation, $relation_group);
	}
}

//var_dump($valid_relation);


// コアノードに関連しないrelationsは結果に含めない?
foreach ($relations as $relation){
	if (in_array($relation['f'], $valid_relation) || in_array($relation['t'], $valid_relation)){
		$ret['relations'][] = $relation;
	}
}
/*
// TODO 関連ノードの有効チェックが不審なのでコメントアウト。
// ERストレスで出てくるはずの分子が出てこない。（ex.アポトーシス阻害に関連する分子）
// ただし、本処理を無効にすることで、ニーマンピック病A/B型で浮いた関連が表示されてしまう。
$ret['relations'] = $relations;
*/



$tmp = [];

//var_dump($parent_map2);

// relationに登場しないノードは結果に含めない
foreach ($data as $datum){
/*
	if (!array_key_exists('rtype', $datum) || in_array($datum['rtype']['value'], $type)){

	} else {
		continue;
	}
*/

	$s = $datum['process']['value'];
	/* hitしようがしまいがここはとりあえずconcept格納するものとする
	$hit = false;
	if (in_array($s, $cores)){
		$hit = true;
	} else {
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}
	}
	*/
//	if ($hit && !in_array($datum['process']['value'], $tmp)){
	if (!in_array($datum['process']['value'], $tmp)){
	addToDic($dic, $datum['process']['value'], $datum['label']);
		$tmp_type = null;
		if (isset($gene_map[$datum['process']['value']])){
			$tmp_type = $gene_map[$datum['process']['value']];
		}

		$ret['concepts'][] = ['p'=>$datum['parent']['value'], 'id'=>$datum['process']['value'], 'l'=>$datum['label']['value'], 't'=>$tmp_type];


		$tmp[] = $datum['process']['value'];
	}

	if (isset($datum['relation'])){
		$s = $datum['relation']['value'];
		$hit = false;
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}

		if ($hit && !in_array($datum['relation']['value'], $tmp)){
		addToDic($dic, $datum['relation']['value'], $datum['rlabel']);
			$concept = ['p'=>$datum['rparent']['value'], 'id'=>$datum['relation']['value'], 'l'=>$datum['rlabel']['value']];
			if (isset($gene_map[$datum['relation']['value']])){
				$concept['t'] = $gene_map[$datum['relation']['value']];
			}
			$ret['concepts'][] = $concept;
			$tmp[] = $datum['relation']['value'];
		}
	}

}


//var_dump($parent_map);


$new_rels = array();
$del_rels = array();
		// 親は複数の子を持つ可能性があるので、この時点では繋ぎ変えるのではなく、関連を追加するのみ
		// 後でまとめて親とその関連を削除する
/*
foreach ($ret['relations'] as $relation){
	$new_rel = null;
	foreach ($parent_map as $key => $tlist){
		if ($relation['f'] != $key && in_array($relation['f'], $tlist)){

//echo "f:". $relation['f'] . "=>".$parents['id']."\n";
//var_dump($parents);
			if ($new_rel == null){
				$new_rel =  ['f'=>$relation['f'], 't'=>$relation['t'], 'l'=>$relation['l'], 's'=>$relation['s']];
			}
			$new_rel['f'] = $key;
		}
	}
	foreach ($parent_map as $key => $tlist){
		if ($relation['t'] != $key && in_array($relation['t'], $tlist)){
//echo "t:". $relation['t'] . "=>".$parents['id']."\n";
//var_dump($parents);
			if ($new_rel == null){
				$new_rel =  ['f'=>$relation['f'], 't'=>$relation['t'], 'l'=>$relation['l'], 's'=>$relation['s']];
			}
			$new_rel['t'] = $key;
		}
	}
	if ($new_rel != null){
		if (!in_array($relation, $del_rels)){
			$del_rels[] = $relation;
		}
		$new_rels[] = $new_rel;
	}
}
*/
$new_rels = [];

if (count($courses) > 1){
	// 階層が存在する場合は関連において子を優先する
	// （TODO 適切な処理ではないので要再検討）
foreach ($ret['relations'] as $relation){
//echo "check f:".$relation['f']." t:".$relation['t']."<br>";
	//	echo('f:<br>');
	$tmp_rels = [];

	$tmp_rels = get_inherited_relations($relation, $parent_map, $ret['relations'], $parent_map2);
	if ($tmp_rels !== false){
		$del_rels[] = $relation;
		if (count($tmp_rels) > 0){
			$tmp_rels = get_valid_relations($tmp_rels, $relation, $parent_map, $ret['relations']);
			$new_rels = array_merge($new_rels, $tmp_rels);
		}
	}
}
}

// 継承関連を生成する
// 対象外かどうか、この時点では考慮せず、存在しうる可能性をすべて列挙する
function get_inherited_relations($relation, $parent_map, $relations, $parent_map2){
	$fs = [];
	$ts = [];
	$ret = [];
	$excepts = [];
//var_dump($relation);
	foreach ($parent_map as $key => $tlist){
		if ($relation['t'] == $key || in_array($relation['t'], $tlist)){
			if (!in_array($key, $ts)){
				$ts[] =  $key;
			}
		}
	}
	foreach ($parent_map as $key => $tlist){
		if ($relation['f'] == $key || in_array($relation['f'], $tlist)){
			if (!in_array($key, $fs)){
				$fs[] =  $key;
			}
		}
	}
/*
var_dump($fs);
var_dump($ts);
*/
	// 例外１ 自分しかいない
	if (count($fs) <=1 && count($ts) <=1){
		// 自分しかいないので対象外
		return false;
	}

	// 例外２ 自分以外の一関連のみ、かつ、既存の関連がない場合は最上位同士の関連を追加するのみ
	if (count($fs) ==2 && count($ts) ==2){
		foreach ($fs as $f){
			if ($f != $relation['f']){
				foreach ($ts as $t){
					if ($t != $relation['t']){
						$tmp = ['f'=>$f, 't'=>$t, 'l'=>$relation['l'], 's'=>$relation['s']];
						if (!has_same_relations($tmp, $relations)){
							$ret[] = $tmp;
							return $ret;
						}
					}
				}
			}
		}
		return $ret;
	}

	// 例外３ どちらか片方がひとつのみの場合、最下位とそのひとつのみの関連を追加
	if (count($fs) == 1 || count($ts) == 1){
//var_dump($relation);
		if (count($fs) == 1){
			$f = $fs[0];
			// tsのうち最下位を取得
			$c = 0;
			$t = null;
			foreach ($ts as $t_){
				if (count($parent_map[$t_]) > $c){
//echo ($t_."<br>");
					$t = $t_;
					$c = count($parent_map[$t_]);
				}
			}
			if ($t != null){
				$tmp = ['f'=>$f, 't'=>$t, 'l'=>$relation['l'], 's'=>$relation['s']];
				if (!has_same_relations($tmp, $relations)){
					$ret[] = $tmp;
//var_dump($ret);
					return $ret;
				}
			}
		}
		if (count($ts) == 1){
			$t = $ts[0];
			// tsのうち最下位を取得
			$c = 0;
			$f = null;
			foreach ($fs as $f_){
				if (count($parent_map[$f_]) > $c){
					$f = $f_;
//echo ($f_."<br>");
					$c = count($parent_map[$f_]);
				}
			}
			if ($f != null){
				$tmp = ['f'=>$f, 't'=>$t, 'l'=>$relation['l'], 's'=>$relation['s']];
				if (!has_same_relations($tmp, $relations)){
					$ret[] = $tmp;
//var_dump($ret);
					return $ret;
				}
			}
		}

	}



	$tmp_excepts = [];
	foreach ($fs as $f){
		foreach ($ts as $t){
			$myself = false;
			if ($f == $relation['f'] && $t == $relation['t']){
//				continue;
				$myself = true;
			}
			$tmp = ['f'=>$f, 't'=>$t, 'l'=>$relation['l'], 's'=>$relation['s']];
//			if (is_valid_relation($relation, $tmp, $parent_map, $relations)){
			if (!has_same_relations($tmp, $relations) && !$myself){
				$ret[] =  $tmp;
			} else {
				// 例外処理候補の既存リンク（継承が２段以上にわたる場合は最下位のみ残す）
				$tmp_excepts[] = $tmp;
			}
		}
	}
//var_dump($tmp_excepts);

	// 例外関連のうち、完全上位互換リンクがあった場合、そのfとtを含むcandidateはリンクから除外する
	// TODO 一つ上だけでなく、祖先を対象とする
	// 親から順に関連をなめて、最上位のみのこす
	/*
	foreach ($tmp_excepts as $except){
		foreach ($tmp_excepts as $except2){
			if (in_array($except2['f'], $parent_map2[$except['f']]) && in_array($except2['t'],$parent_map2[$except['t']])){
				$excepts[] = $except2['f'];
				$excepts[] = $except2['t'];
			}
		}
	}*/

	foreach ($tmp_excepts as $except){
		$f_ancestors = $parent_map[$except['f']];
		$t_ancestors = $parent_map[$except['t']];
		foreach ($f_ancestors as $f_anc){
			foreach ($t_ancestors as $t_anc){
				foreach ($tmp_excepts as $except2){
					if ($except2['f']== $f_anc && $except2['t'] == $t_anc){
						$excepts[] = $except2['f'];
						$excepts[] = $except2['t'];
						break;
					}
				}
			}
		}
	}



//var_dump($excepts);
	$tmp_ret = $ret;
	$ret = [];
	foreach ($tmp_ret as $tmp){
		if (!in_array($tmp['f'], $excepts) && !in_array($tmp['t'], $excepts)){
			$ret[] = $tmp;
		}
	}

//var_dump($ret);

	// 対象有り（ヒットするものがあるかは別）
	return $ret;
}


function has_same_relations($relation, $relations){
	foreach ($relations as $rel){
		if ($rel['f'] == $relation['f'] && $rel['t'] == $relation['t']){
			return true;
		}
	}
	return false;
}


function get_valid_relations($cands, $relation, $parent_map, $relations){
	$tmp_rels = $relations;//array_merge($relations, $cands);
/*
	$tmp_rels = array_merge($relations, $cands);
	$idx = 0;
	foreach ($tmp_rels as $tmp_rel){
		if ($tmp_rel['f'] == $relation['f'] && $tmp_rel['t'] == $relation['t']){
			unset($tmp_rels[$idx]);
			break;
		}

		$idx++;
	}
*/

	$ret = [];
	foreach ($cands as $candidate){
//echo "cand:<br>";
//var_dump($candidate);
		if (is_valid_relation($relation, $candidate, $parent_map, $tmp_rels)){
//echo "valid<br>";
			$ret[] =  $candidate;
		}
	}
//var_dump($ret);
	return $ret;
}



// 現在の関連一覧を基に、追加すべき関連かどうかを判定する
function is_valid_relation($base_relation, $relation, $parent_map, $relations){
	$base_f_ancestors = $parent_map[$base_relation['f']];
	$base_t_ancestors = $parent_map[$base_relation['t']];


	$f_ancestors = $parent_map[$relation['f']];
	$t_ancestors = $parent_map[$relation['t']];
	$f_ancestors[] = $relation['f'];
	$t_ancestors[] = $relation['t'];

	$f_ancestors = array_diff($f_ancestors, $base_f_ancestors);
	$t_ancestors = array_diff($t_ancestors, $base_t_ancestors);
/*
var_dump($f_ancestors);
var_dump($t_ancestors);
*/
	// 始点が同じ、かつ、終点が同一継承元を持つ
	foreach ($relations as $tmp_rel){
		if ($tmp_rel['f'] == $relation['f'] && array_key_exists($tmp_rel['t'], $parent_map)){
//echo "t:".$tmp_rel['t']."<br>";
			$tmp_t_ancestors = $parent_map[$tmp_rel['t']];
			$tmp_t_ancestors = array_diff($tmp_t_ancestors, $base_t_ancestors);
			$tmp_t_ancestors[] = $tmp_rel['t'];
//var_dump($tmp_t_ancestors);
//var_dump($t_ancestors);
			$same = array_intersect($t_ancestors, $tmp_t_ancestors);
			if (count($same) > 0 && (count($tmp_t_ancestors) != count($same))){
//			if (count($same) > 0){
//var_dump($tmp_rel);
//echo "invalid1<br>";

				return false;
			}
		}
	}

	// 終点が同じ、かつ、始点が同一継承元を持つ
	foreach ($relations as $tmp_rel){
		if ($tmp_rel['t'] == $relation['t'] && array_key_exists($tmp_rel['f'], $parent_map)){
//echo "f:".$tmp_rel['f']."<br>";
			$tmp_f_ancestors = $parent_map[$tmp_rel['f']];
			$tmp_f_ancestors = array_diff($tmp_f_ancestors, $base_f_ancestors);
			$tmp_f_ancestors[] = $tmp_rel['f'];
//var_dump($f_ancestors);
//var_dump($tmp_f_ancestors);

// TODO
// $f_ancestorsの中に$tmp_f_ancestorsがすべて含まれる場合はvalid
// 共通部がありかつ差分もある場合はinvalid

			$same = array_intersect($f_ancestors, $tmp_f_ancestors);
			if (count($same) > 0 && (count($tmp_f_ancestors) != count($same))){
//			if (count($same) > 0){
//var_dump($tmp_rel);
//echo "invalid2<br>";
				return false;
			}
		}
	}

	return true;
}


//var_dump($ret['relations'] );


//var_dump($parent_map);
/*
var_dump($new_rels);
var_dump($del_rels);
*/
$tmp_rels = $ret['relations'];


//var_dump($tmp_rels);


foreach ($del_rels as $del_rel){
	$idx = array_search($del_rel, $tmp_rels);
	if ($idx >= 0){
		unset($tmp_rels[$idx]);
	}
}

//var_dump($tmp_rels);


$tmp_rels = array_values($tmp_rels);
$tmp_rels = array_merge($tmp_rels, $new_rels);
$ret['relations'] = $tmp_rels;



// 親ノード削除
/*
foreach ($parent_map as $key => $tlist){
	$i = 0;
	foreach ($ret['concepts'] as $concept){
		if ($concept != null){
			if (in_array($concept['id'], $tlist) && $key != $concept['id']){
				unset ($ret['concepts'][$i]);
			}
		}
		$i++;
	}
	$ret['concepts'] = array_values($ret['concepts']);
}
*/

$sub_relation_types = [];
foreach ($type_map as $key=>$value){
	if ($key != 'r' && $key != 'p' && $key != 'w' && $key != 's'){
		$sub_relation_types[] = $type_map[$key]['l'];
	}
}

$tmp_con = [];

$del_relations = [];

foreach ($ret['concepts'] as $concept){
	/*
	if (in_array($concept['id'], $mycores)){
		$tmp_con[] = $concept;
		continue;
	}
	*/
	$hit = false;
	$sub_hit = false;
	$tmp_del_relations = [];
	foreach ($ret['relations'] as &$rel){
		if ($rel['f'] == $concept['id'] || $rel['t'] == $concept['id']){
			if ($rel['f'] == $concept['id'] && in_array($rel['l'], $sub_relation_types)){
				// 自分が始点でサブ関連の場合はヒット対象としない
				$tmp_del_relations[] = $rel;
			} else {
				$hit = true;
				break;
			}
		}
	}

	if ($hit){
		$tmp_con[] = $concept;
		continue;
	} else {
		$del_relations = array_merge($del_relations, $tmp_del_relations);
	}
}

foreach ($ret['relations'] as $key => &$value){
	if (in_array($value, $del_relations)){
		unset($ret['relations'][$key]);
	}
}
$ret['relations'] = array_values($ret['relations']);

$ret['concepts'] = $tmp_con;


// 最後に残ったConcept間でis-aを設定
if (in_array($type_map['s']['id'], $type)){
	$relations = [];
	foreach ($ret['concepts'] as $concept){

		$id = get_parent($concept['id'], $ret['concepts'], $parent_map2);
		if ($id != null){


			$relations[] = ['f'=>$id, 't'=>$concept['id'], 'l'=>$type_map['s']['l']];
		}

	}
	$ret['relations'] = array_merge($ret['relations'], $relations);
}

function get_parent($myself, $concepts, $parent_map2){
	$ids = $parent_map2[$myself];
	foreach ($ids as $id){
		foreach ($concepts as $concept){
			if ($concept['id'] == $id){
				return $concept['id'];
			}
		}
	}
	return null;
}

$ret['result'] = true;
$ret['id'] = $id;


header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>