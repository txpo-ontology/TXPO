<?php
// PubMedデータ取得用

set_time_limit(120);

class PubMed {

	private $base_url = 'https://eutils.ncbi.nlm.nih.gov/';
	private $get_param = 'entrez/eutils/esearch.fcgi?db=pubmed&term=';
	private $jump_url = 'https://www.ncbi.nlm.nih.gov/pubmed/?term=';
	private $summary_param = 'entrez/eutils/esummary.fcgi?db=pubmed&id=';

	// optの形式
	function get($key, $count=10){
		$ret = [];
		//
		$header = [
				"Accept:application/xml"
		];
		/*
		 $options = [
		 "http"=>["method"=>"GET"]
		 ];
		 */
		$options = [
				CURLOPT_RETURNTRANSFER=>true,
				CURLOPT_TIMEOUT=>5,
				CURLOPT_SSL_VERIFYPEER=>false,
				CURLOPT_SSL_VERIFYHOST=>false
		];

		// test "glutathione"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms]
//		$param = urlencode('("glutathione"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms])');
		$param = $key;

		$param .= '&retmax='.strval($count); // 最大$count(10)件

//echo ($this->base_url . $this->get_param . $param);
		$ch = curl_init($this->base_url . $this->get_param . $param);
		curl_setopt_array($ch, $options);

		$xml = curl_exec($ch);
		$info = curl_getinfo($ch);
		$error = curl_errno($ch);
		if ($error !== CURLE_OK){
			return ['error'=>'Network Error ('.$error . ") : [".curl_error($ch)."]"];
		}

		$data = new SimpleXMLElement($xml);
//var_dump($data);

		$ret['count'] = (string)$data->Count;
		$ret['ids'] = [];

		$ids = [];
		$ids_ = $data->IdList;
		$summary = [];
		if (isset($ids_->Id)){
			$ids_ = $ids_->Id;
			foreach ($ids_ as $id){
				$ret['ids'][] = (string)$id;
				$ids[] = $id;
			}

			$ids = implode(",", $ids);
//$ids = $ids[0];


			$summary = $this->summary($ids);
		}



//		var_dump($summary);
//		$data = json_decode($data, true);
		$ret['summary'] = $summary;

		$ret['url'] = $this->jump_url . urlencode($data->QueryTranslation);

		return $ret;

	}

	function summary($ids){
		//
		$header = [
				"Accept:application/xml"
		];
		$options = [
				CURLOPT_RETURNTRANSFER=>true,
				CURLOPT_TIMEOUT=>5,
				CURLOPT_SSL_VERIFYPEER=>false,
				CURLOPT_SSL_VERIFYHOST=>false
				];


		$ch = curl_init($this->base_url . $this->summary_param . $ids);
		curl_setopt_array($ch, $options);

		$xml = curl_exec($ch);
		$info = curl_getinfo($ch);
		$error = curl_errno($ch);
		if ($error !== CURLE_OK){
			return ['error'=>'Network Error ('.$error . ") : [".curl_error($ch)."]"];
		}

		$data = $this->xml_summary_to_json($xml);

		return $data;
	}

	function xml_summary_to_json($xml){
		$ret = [];
//		var_dump($xml);
		$xml = new SimpleXMLElement($xml);

//		var_dump($xml);

		foreach($xml->DocSum as $data){
			$datum = [];

			$datum['id'] = (string)$data->Id;

			$datum['item'] = [];
			foreach ($data->Item as $item){
				$name = (string)$item['Name'];
				$type = (string)$item['Type'];

				if ($type == 'List'){
					$datum['item'][$name] = [];
					foreach ($item->Item as $li){
						$datum['item'][$name][] = (string)$li;
					}
				} else {
					$datum['item'][$name] = (string)$item;
				}
			}

			$ret[] = $datum;
		}

		return $ret;
	}

}



?>

