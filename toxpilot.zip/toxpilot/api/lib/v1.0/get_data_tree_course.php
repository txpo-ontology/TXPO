<?php
// ツリーデータ取得用

include "http_get.php";

$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select ?pr ?prl ?s ?l {
?s rdfs:subClassOf+ <". $const['DATA_TOX_MECHA'].">;
rdfs:subClassOf ?pr;
rdfs:label ?l.
?pr rdfs:subClassOf* <". $const['DATA_TOX_MECHA'].">.
";

foreach ($except_courses as $except_course){
$query .= "
minus {
	?s rdfs:subClassOf* <" . $except_course . ">.
}";
}
$query .= "
FILTER (lang(?l) = '". $lang ."')
FILTER (isBlank(?pr) != true)
?pr rdfs:label ?prl.
FILTER (lang(?prl) = '".$lang."')
} order by ?pr";

header("Content-Type: application/sparql-results+json;charset=UTF-8");
$http = new Http();
echo json_encode($http->get($query));

?>