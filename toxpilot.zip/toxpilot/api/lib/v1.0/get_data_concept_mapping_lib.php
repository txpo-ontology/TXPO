<?php

include_once 'http_mapping.php';

function get_concept_mappings($id){
	$http = new Mapping();

	$acros = ["RXNORM","MEDDRA","SNOMEDCT","NDDF","NDFRT","NCIT","LOINC","MESH","DOID","ICD10","IOBC","HP","CHEBI","OBI","UBERON","BAO","OMIM","DRON","PATO","GO","OAE"];

	$ret = [];

	$tmp = $http->get($id);

//	var_dump($tmp);

	if (is_array($tmp)){
		foreach ($tmp as $datum){
			if (isset($datum['classes'])){
				foreach ($datum['classes'] as $mapping){
					$acro = null;
					if (isset($mapping['links']) && isset($mapping['links']['ontology'])){
						$acro = $mapping['links']['ontology'];
						$aidx = strrpos($acro, '/');
						if ($aidx !== FALSE){
							$acro = substr($acro, $aidx+1);
						} else {
							$acro = null;
						}
					}
					if ($acro == null || !in_array($acro, $acros)){
						continue;
					}

					if (isset($mapping['@id'])){
						$mid = $mapping['@id'];
						if (!isset($ret[$mid]) || !in_array($acro, $ret[$mid])){
							if (!isset($ret[$mid])){
								$ary = [];
							} else {
								$ary = $ret[$mid];
							}
							$ary[] = $acro;

							$ret[$mid] = $ary;
						}
					}
				}
			} else  if (isset($tmp['error'])){
				$ret = $tmp;
				break;
			}
		}
	}


	return $ret;
}
?>