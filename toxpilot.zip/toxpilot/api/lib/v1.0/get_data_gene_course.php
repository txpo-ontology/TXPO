<?php
// 汎用機序マップデータ取得用

include_once "get_data_gene_course_lib.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$processes = get_gene_course($id, $lang, $const);


$ret['id'] = $id;
$ret['result'] = true;
$ret['concepts'] = $processes;




header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>