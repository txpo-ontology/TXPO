<?php
// プロセスが所属する作用機序一覧取得用

include_once "http_get.php";
include_once "get_util.php";

ini_set('xdebug.var_display_max_depth', -1);


function get_course_parents($id, $lang, $const){


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);

$http = new Http();

// プロセスに紐づく作用機序の取得
$query = "
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
select ?p {
  <" . $id . "> rdfs:subClassOf+ ?p.
  ?p rdfs:subClassOf+  <" . $const['DATA_TOX_MECHA'] . ">
}
";
$data = $http->get($query);

$parents = array();

$dic = array();

foreach($data as $datum){
	$parents[] = $datum['p']['value'];
}

return $parents;
}




?>