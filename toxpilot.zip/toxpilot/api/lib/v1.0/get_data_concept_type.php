<?php
// 概念種別取得用
// 大枠の種別および基本情報を取得したうえで、各情報取得用モジュールに移譲する

include_once "http_get.php";
include_once "get_util.php";

include_once "get_data_type_lib.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = true;
$ret['id'] = $id;
$ret['type'] = get_type($id, $const); // TODO course/process/molecule/role/finding/structure
/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */





//var_dump($ret);

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>