<?php
// ツリーデータ取得用

include_once "http_get.php";


$option = '';
if (isset($args['option'])){
	$option = $args['option'];
}


$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?pr ?prl ?s ?l ?os ?pl {
 {
  {
   ?s rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.
  }";
if (strpos($option, "finding") !== FALSE){
$query .="
  union {
   ?s  rdfs:subClassOf+ <" . $const['DATA_FINDING_BASE'] . ">.
  }";
}
$query .="
?s rdfs:label ?l\n".
"FILTER (lang(?l) = '" . $lang . "')\n".
"?s rdfs:subClassOf ?pr.\n".
"{?pr rdfs:subClassOf* <" . $const['DATA_FUNC_PROCESS'] . ">.}\n";
if (strpos($option, "finding") !== FALSE){
	$query .="
  union {
   ?pr rdfs:subClassOf* <" . $const['DATA_FINDING_BASE'] . ">.
  }";
}
$query .=
" FILTER (isIri(?pr))\n".
"?pr rdfs:label ?prl.\n".
"FILTER (lang(?prl) = '" . $lang . "')\n".
"}\n";

if (strpos($option, "part") !== FALSE){
	$query .=
"optional {\n".
"?s rdfs:subClassOf ?sc.\n".
" FILTER (isBlank(?sc))\n".
" ?sc owl:onProperty <" . $const['DATA_HAS_PART'] . ">;\n".
"owl:someValuesFrom ?os.\n".
"?os rdfs:label ?pl.\n".
"FILTER (lang(?pl) = '" . $lang . "')\n".
"}\n";
}
	$query .=
"}";

//echo $query;
//exit();

header("Content-Type: application/sparql-results+json;charset=UTF-8");
$http = new Http();
echo json_encode($http->get($query));


?>