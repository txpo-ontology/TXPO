<?php
// 各種util

include_once "http_get.php";

$http = new Http();


// IDのprefixを元に戻す
function decode_prefix($id){
	$prefix_map = [
			'tox:'=>'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#',
//			'txpo:'=>'http://bioportal.bioontology.org/ontologies/txpo/',
			'txpo:'=>'http://purl.obolibrary.org/obo/',
			'go:'=>'http://purl.obolibrary.org/obo/',
			'tgp:'=>'http://www.semanticweb.org/yukiyamagata/ontologies/2017/1/tgp#'

	];


	foreach ($prefix_map as $key=>$value){
		if (strpos($id, $key) === 0){
			$id = $value . substr($id, strlen($key));
		}
	}
	return urldecode(urldecode($id));
}


function set_lang(&$map, $key, $value, $lang, $uri = '_'){

	if (!array_key_exists($key, $map)){
		$map[$key] = [];
	}
	if (array_key_exists('xml:lang', $value) && $value['xml:lang'] == $lang){
		$map[$key][$uri] = trim($value['value']);
	} else {
		if (!array_key_exists($uri, $map[$key])){
			$map[$key][$uri] = trim($value['value']);
		}
	}
	return $map;
}

function get_lang($map, $key, $glue = '，'){
	if (array_key_exists($key, $map)){
		$arry = $map[$key];
		return implode($glue, $arry);
	}
	return null;
}

function hasAt($label, $lang){
	// TODO とりあえず言語に限らず処理する
	//	if ($lang == 'ja'){
		if (strpos($label, "@") !== false || strpos($label, "＠") !== false){
			return true;
		}
//	} else {
		$hit = preg_match("/(.*)\[(.*)\]/", $label, $arry_result);
		if ($hit){
			return true;
		}
//	}
	return false;
}

function camel($label){
	if (ctype_lower(substr($label, 0, 1))){
		$label = mb_strtoupper(substr($label, 0, 1)) . substr($label, 1); // 先頭を大文字に変換
	}
	return $label;
}

function uncamel($label){
	if (ctype_upper(substr($label, 0, 1))){
		$label = mb_strtolower(substr($label, 0, 1)) . substr($label, 1); // 先頭を小文字に変換
	}
	return $label;
}


function getBeforeAt($label, $lang, $glue = ","){
	// TODO とりあえず言語に限らず処理する
	$labels = explode($glue, $label);
	$ret = [];

//	if ($lang == 'ja'){
	foreach ($labels as $label){
		$hit = false;
		$pos = strrpos($label, "@");
		if ($pos !== false){
			$tmp = substr($label, 0, $pos);
			$tmp = changeAtToWord($tmp);
			if (!in_array($tmp, $ret)){
				$ret[] = $tmp;
			}
			$hit = true;
//			return substr($label, 0, $pos);
		}
		$pos = strrpos($label, "＠");
		if ($pos !== false){
			$tmp = substr($label, 0, $pos);
			$tmp = changeAtToWord($tmp);
			if (!in_array($tmp, $ret)){
				$ret[] = $tmp;
			}
			$hit = true;
//			return substr($label, 0, $pos);
		}
//	} else {
		if (!$hit){
			$hit = preg_match("/(.*)\[(.*)\]/", $label, $arry_result);
			if ($hit){
				$tmp = trim($arry_result[1]);
				if (!in_array($tmp, $ret)){
					$ret[] = $tmp;
				}

//			return trim($arry_result[1]);
			}
		}
		if (!$hit){
			$ret[] = $label;
		}
	}
//	}
	return implode($glue, $ret);
}

function getAfterAt($label, $lang){
	$hit = false;
	$pos = strrpos($label, "@");
	$ret = $label;
	if ($pos !== false){
		$tmp = substr($label, $pos+strlen('@'), strlen($label));
		$ret = $tmp;
		$hit = true;
		//			return substr($label, 0, $pos);
	}
	$pos = strrpos($label, "＠");
	if ($pos !== false){
		$tmp = substr($label, $pos+strlen('＠'), strlen($label));
		$ret = $tmp;
		$hit = true;
	}
	//	} else {
	if (!$hit){
		$hit = preg_match("/(.*)\[(.*)\]/", $label, $arry_result);
		if ($hit){
			$tmp = trim($arry_result[2]);
			$ret = $tmp;
		}
	}
	return $ret;
}


function changeAtToWord($word){
	// aa@@bb を「bbにおけるaa」とする。
	// TODO 英語の場合は？
	$word = str_replace('＠', '@', $word);
	$ret = $word;
	$pos = strrpos($word, "@");
	if ($pos !== false){
		$tmps = explode("@", $word);
		$tmps = array_reverse($tmps);
		$tmps = array_filter($tmps, "strlen");
		$ret = implode("における",  $tmps);
	}
	return $ret;
}

function addToDic(&$dic, $key, $word){
	if ($word == null){
		return;
	}
	// dicは連想配列、keyはliteral、wordはjson要素（value/xml:lang）
	if (!isset($dic[$key])){
		$dic[$key] = $word['value'];
	} else {
		if (isset($word['xml:lang'])){
			$dic[$key] = $word['value'];
		}
	}
}

?>