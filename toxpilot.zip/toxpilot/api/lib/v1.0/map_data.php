<?php

include_once "valid.php";

// マップデータ共通
$type_map = ['s'=>['id'=>'is-a', 'l'=>'is-a'],
		'r'=>['id'=>$const['DATA_HAS_RESULT'], 'l'=>$const_label[$const['DATA_HAS_RESULT']]],
		'p'=>['id'=>$const['DATA_HAS_PART'], 'l'=>$const_label[$const['DATA_HAS_PART']]],
		'w'=>['id'=>$const['DATA_HAS_PATHWAY'], 'l'=>$const_label[$const['DATA_HAS_PATHWAY']]],
		'm'=>['id'=>$const['DATA_HAS_MOLECULAR_REACTION'], 'l'=>$const_label[$const['DATA_HAS_MOLECULAR_REACTION']]],
		'f'=>['id'=>$const['DATA_HAS_FINDINGS'], 'l'=>$const_label[$const['DATA_HAS_FINDINGS']]],
		't'=>['id'=>$const['DATA_HAS_PARTICIPANT'], 'l'=>$const_label[$const['DATA_HAS_PARTICIPANT']]],
		'a'=>['id'=>$const['DATA_HAS_AGENT'], 'l'=>$const_label[$const['DATA_HAS_AGENT']]],
		'i'=>['id'=>$const['DATA_HAS_INPUT'], 'l'=>$const_label[$const['DATA_HAS_INPUT']]],
		'o'=>['id'=>$const['DATA_HAS_OUTPUT'], 'l'=>$const_label[$const['DATA_HAS_OUTPUT']]]
];


?>