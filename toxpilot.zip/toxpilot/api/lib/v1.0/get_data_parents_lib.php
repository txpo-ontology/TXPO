<?php
// プロセスが所属する作用機序一覧取得用

include_once "http_get.php";
include_once "get_util.php";

ini_set('xdebug.var_display_max_depth', -1);

// 渡したリストの中から、リスト中最上位の自分の親を抽出して返す
function get_parents($id, $concept_parents){
//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

	$parents = [];

	$ret = [];

	if (isset($concept_parents[$id])){
		foreach ($concept_parents[$id] as $parent){
			if (isset($concept_parents[$parent]) && count($concept_parents[$parent]) == 0){
				// $idの最上位の親の一つが$parent
				$ret[] = $parent;
			}
		}

	}
	return $ret;
}

// concept一覧について、conceptに存在する中での親の一覧を取得して返す
function get_concept_parents($concepts){
	$http = new Http();

	$ret = [];

	$work_concepts = [];

	foreach ($concepts as $concept){
		$work_concepts[] = get_concept_id($concept);
	}
	foreach ($work_concepts as $concept){
		$id = get_concept_id($concept);
		// プロセスの親一覧の取得
		$query = "
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
select ?id {
  <" . $id . "> rdfs:subClassOf+ ?id.
}";
		$data = $http->get($query);

		$ret[$id] = [];
		foreach ($data as $datum){
			$cid = get_concept_id($datum);

			if (in_array($cid, $work_concepts)){
				$ret[$id][] = $cid;
			}
		}
	}


	return $ret;
}

// $parentが$idの親かどうかを返す
function is_parent($id, $parent, $concept_parents){
	$parents = get_parents($id, $concept_parents);

	return in_array($parent, $parents);
}


function get_concept_id($concept){
	$id = $concept;
	if (isset($concept['id'])){
		if (isset($concept['id']['value'])){
			$id = $concept['id']['value'];
		} else {
			$id = $concept['id'];
		}
	}
	return $id;
}


?>