<?php
// ツリーデータ取得用

include "http_get.php";

$query =
/*
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ?pr ?prl ?s ?l ?pt ?ptl\n".
"{\n".
"{\n".
"?s rdfs:label ?l\n".
"FILTER (lang(?l) = '" .$lang. "' || lang(?l) = '')\n".
"?s rdfs:subClassOf ?pr.\n".
" FILTER (isIri(?pr))\n".
"?pr rdfs:label ?prl.\n".
"FILTER (lang(?prl) = '" .$lang. "' || lang(?prl) = '')\n".
"}\n".
"optional {\n".
"?s rdfs:subClassOf ?sc.\n".
" FILTER (isBlank(?sc))\n".
" ?sc owl:onProperty <" . $const['DATA_HAS_PART'] .">;\n".
"owl:someValuesFrom ?pt.\n".
"?pt rdfs:label ?ptl.\n".
"FILTER (lang(?ptl) = '" .$lang. "' || lang(?ptl) = '')\n".
"}\n".
"}";
*/

"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?pr ?prl ?s ?l ?os ?pl ?os2 ?pl2
{
	{
		?s rdfs:subClassOf ?pr.
			?s rdfs:label ?l_.
			FILTER (lang(?l_) = '".$lang."')
			BIND(?l_ as ?l)
		minus {
			?s rdfs:subClassOf* <" . $const['DATA_TOX_PROCESS'] . ">.
		} minus {
			?s rdfs:subClassOf* <" . $const['DATA_TOX_THING'] . ">.
		} minus {
			?s rdfs:subClassOf* <" . $const['DATA_PROCESS_DEPEND'] . ">.
		}
		FILTER (isIri(?pr))
			?pr rdfs:label ?prl_.
			FILTER (lang(?prl_) = '".$lang."')
			BIND(?prl_ as ?prl)
	} union {
		?s rdfs:subClassOf* <" . $const['DATA_TOX_PROCESS'] . ">.
			?s rdfs:label ?l_.
			FILTER (lang(?l_) = '".$lang."')
			BIND(?l_ as ?l)
		?s rdfs:subClassOf ?pr.
		FILTER (isIri(?pr))
			?pr rdfs:label ?prl_.
			FILTER (lang(?prl_) = '".$lang."')
			BIND(?prl_ as ?prl)
	} union {
		?s rdfs:subClassOf* <" . $const['DATA_TOX_THING'] . ">;
		rdfs:subClassOf ?pr.
			?s rdfs:label ?l_.
			FILTER (lang(?l_) = '".$lang."')
			BIND(?l_ as ?l)
		FILTER (isIri(?pr))
			?pr rdfs:label ?prl_.
			FILTER (lang(?prl_) = '".$lang."')
			BIND(?prl_ as ?prl)
	} union {
		?s rdfs:subClassOf* <" . $const['DATA_PROCESS_DEPEND'] . ">;
		rdfs:subClassOf ?pr.
			?s rdfs:label ?l_.
			FILTER (lang(?l_) = '".$lang."')
			BIND(?l_ as ?l)
		FILTER (isIri(?pr))
			?pr rdfs:label ?prl_.
			FILTER (lang(?prl_) = '".$lang."')
			BIND(?prl_ as ?prl)
	}
	optional {
		?s rdfs:subClassOf ?sc.
		FILTER (isBlank(?sc))
		?sc owl:onProperty <" . $const['DATA_HAS_PART'] .">;
		owl:someValuesFrom ?os.
		?os rdfs:label ?pl.
		FILTER (lang(?pl) = '".$lang."')
	}
}
";


$http = new Http();


$data = $http->get($query);


// 深さ１のequivalentを連結

$query = "
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
select ?s ?os2 ?pl2 {
 {
  ?s rdfs:subClassOf+ <" . $const['DATA_PROCESS_VIEWPOINT'] .">.
  ?s owl:equivalentClass ?oo.
  ?oo ?ot1 ?o.
  FILTER (isBlank(?o))
  ?o rdf:first ?base;
   rdf:rest ?ob1.
  FILTER(isBlank(?ob1))
  ?ob1 rdf:first ?ob11.
  ?ob11 owl:onProperty ?prop2;
   ?op2 ?o2.
  FILTER (?op2 != owl:onProperty)
  FILTER (?o2 != owl:Restriction)
 } optional {
  {
   ?o ?ot1 ?bl1.
   FILTER (isBlank(?bl1))
   ?bl1 rdf:first ?base;
    rdf:rest ?ob1.
   FILTER(isBlank(?ob1))
   FILTER (?ot1 = owl:intersectionOf)
   ?ob1 rdf:first ?ob11.
   ?ob11 owl:onProperty ?prop2;
    ?op2 ?o2.
   FILTER (?op2 != owl:onProperty)
   FILTER (?o2 != owl:Restriction)
  } union {
   ?o ?ot1 ?bl1.
   FILTER (isBlank(?bl1))
   ?bl1 rdf:rest* ?bl2.
   ?bl2 rdf:first ?base.
   FILTER (?ot1 = owl:unionOf)
  }
 }
 ?s rdfs:subClassOf ?pr;
  rdfs:label ?l.
 ?pr rdfs:label ?prl.
 FILTER(lang(?l) = '" . $lang . "' || lang(?l) = '')
 FILTER(lang(?prl) = '" . $lang . "' || lang(?prl) = '')
 ?os2 rdfs:subClassOf+ ?base;
  rdfs:subClassOf ?n;
  rdfs:label ?pl2.
 FILTER(lang(?pl2) = '" . $lang . "' || lang(?pl2) = '')
 FILTER(isBlank(?n))
 ?n owl:onProperty ?prop2;
  ?op2 ?o2.
}
";


$depth1data = $http->get($query);


foreach ($depth1data as &$datum){
	foreach ($data as $base_datum){
		if ($datum['s']['value'] == $base_datum['s']['value']){
			$datum['l'] = $base_datum['l'];
			$datum['pr'] = $base_datum['pr'];
			$datum['prl'] = $base_datum['prl'];
			break;
		}
	}
}
$data = array_merge($data, $depth1data);


$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
select distinct  ?s ?os2 ?pl2 {
 ?s rdfs:subClassOf+ <http://purl.obolibrary.org/obo/TXPO_0003763>;
  owl:equivalentClass ?oo.
 ?oo owl:intersectionOf ?o.
 FILTER (isBlank(?o))
 ?o rdf:first ?oa1;
  rdf:rest ?ob1.
 FILTER(isBlank(?ob1))
 ?ob1 rdf:first ?ob11.
 ?ob11 owl:onProperty ?prop2;
  ?op2 ?o2.
 FILTER (?op2 != owl:onProperty)
 FILTER(isBlank(?o2))

 ?o2 owl:intersectionOf ?bl2.
 FILTER (isBlank(?bl2))
 ?bl2 rdf:first ?oa2;
  rdf:rest ?ob2.
 FILTER(isBlank(?ob2))
 ?ob2 rdf:first ?ob21.
 ?ob21 owl:onProperty ?prop3;
  ?op3 ?o3.
 FILTER (?op3 != owl:onProperty)
 FILTER (?o3 != owl:Restriction)

#以降target取得


  ?os2 rdfs:subClassOf* ?oa1;
rdfs:label ?pl2;
      rdfs:subClassOf ?n.
  ?n owl:onProperty ?prop2;
      owl:someValuesFrom ?process.
  ?process rdfs:subClassOf+ ?oa2;
                          rdfs:subClassOf ?n2.
  ?n2 owl:onProperty ?prop3;
        owl:someValuesFrom ?finding.
  ?finding rdfs:subClassOf* ?o3.
   FILTER (lang(?pl2) = '" . $lang . "')

}
";

$depth2data = $http->get($query);

foreach ($depth2data as &$datum){
	foreach ($data as $base_datum){
		if ($datum['s']['value'] == $base_datum['s']['value']){
			$datum['l'] = $base_datum['l'];
			$datum['pr'] = $base_datum['pr'];
			$datum['prl'] = $base_datum['prl'];
			break;
		}
	}
}
$data = array_merge($data, $depth2data);


//echo $query;

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($data);


?>