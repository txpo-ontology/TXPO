<?php
// 概念種別取得用

include_once "http_get.php";
include_once "get_util.php";

ini_set('xdebug.var_display_max_depth', -1);


function get_type($id, $const, $detail = false){


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);


$http = new Http();

// geneプロセスの取得
$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
select distinct ?course ?process_f ?process_p ?compound ?molecule ?role ?findings ?structure {
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
 rdfs:label ?course.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">;
 rdfs:label ?process_f.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">;
 rdfs:label ?process.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_MOLECULE'] . ">;
 rdfs:label ?molecule.
} union
{<" .$id ."> rdfs:subClassOf+ <" . $const['DATA_COMPOUND'] . ">;
  rdfs:label ?compound.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_FINDING_BASE'] . ">;
 rdfs:label ?findings.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_ROLE_BASE'] . ">;
 rdfs:label ?role.
} union
{<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_ANATOMICAL_ENTITY'] . ">;
 rdfs:label ?structure.
}
}";

$data = $http->get($query);

$type = "";

foreach($data as $datum){
	if (isset($datum['course'])){
		$type = 'course';
		break;
	} else if (isset($datum['process_f'])){
		if ($detail){
			$type = 'process_f';
		} else {
			$type = 'process';
		}
		break;
	} else if (isset($datum['process_p'])){
		if ($detail){
			$type = 'process_p';
		} else {
			$type = 'process';
		}
		break;
	} else if (isset($datum['compound'])){
		if ($detail){
			$type = 'compound';
		} else {
			$type = 'molecule'; // 本来はcompoundのはず
		}
		break;
	} else if (isset($datum['molecule'])){
		$type = 'molecule';
		break;
	} else if (isset($datum['role'])){
		$type = 'role';
		break;
	} else if (isset($datum['findings'])){
		$type = 'finding';
		break;
	} else if (isset($datum['structure'])){
		$type = 'structure';
		break;
	}
}

return $type;
}




?>