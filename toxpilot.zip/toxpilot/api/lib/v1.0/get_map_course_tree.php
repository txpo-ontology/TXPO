<?php
// 作用機序マップデータ取得用（階層あり）
// ファイル名"get_map_course_tree.php"は作成中の仮名

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";
include_once "get_data_gene_course_lib.php";
include_once "get_data_course_lib.php";


if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	$id  =null;
}

$type_id = null;
if (array_key_exists('type', $args)){
	$type_id = $args['type'];
}
if ($type_id == null || $type_id == ''){
	$type_id = 'rp';
}


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

if ($id != null){
	$id = decode_prefix($id);
}

$type = [];

foreach ($type_map as $key => $value){
	if (strpos($type_id, $key) !== false){
		$type[] = $value['id'];
	}
}

//$type = ['hasResult', 'has_part'];

$http = new Http();


// まずは全遺伝子を取得
$gene_map = array();

$tmp_processes = get_gene_course(null, $lang, $const);

foreach ($tmp_processes as $process){
	foreach ($process['gene'] as $gene){
		$gene_type = '';
		foreach ($gene['being'] as $being){
			if (isset($being['t']) && strpos($gene_type, $being['t']) === false){
				$gene_type .= $being['t'].' ';
			}
		}
		foreach ($gene['assay'] as $assay){
			if (isset($assay['t']) && strpos($gene_type, $assay['t']) === false){
				$gene_type .= $assay['t'].' ';
			}
		}

		$gene_type = trim($gene_type);
		if ($gene_type == ''){
			$gene_type  ="canonical";
		}
		$gene_map[$gene['id']] = $gene_type;
	}
}


//var_dump($gene_map);

// 作用機序の一覧を取得する
$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
select distinct ?parent ?series {
 <" . $id . "> rdfs:subClassOf* ?series.
 ?series rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
  rdfs:subClassOf ?parent.
 ?parent rdfs:subClassOf* <" . $const['DATA_TOX_MECHA'] . ">.
}";


$tmp = $http->get($query);
$tmp_series = array();
// parentをベースに並び替え
$tmp_p = $const['DATA_TOX_MECHA'];
$tmp_hit = true;

// 作用機序を下位から順に取得し、プロセス・関連を重ねていく
/*
while ($tmp_hit){
	$tmp_hit = false;
	foreach ($tmp as $work){
		if ($work['parent']['value'] === $tmp_p){
			$tmp_series[] = $work['series']['value'];
			$tmp_p = $work['series']['value'];
			$tmp_hit = true;
		}
	}
}*/

function explore_children(&$tmp_series, &$tmp, $tmp_p, $depth = 1){
	foreach ($tmp as $work){
		if ($work['parent']['value'] === $tmp_p){
			$exists = false;
			foreach ($tmp_series as $tmp_s){
				if ($tmp_s['s'] == $work['series']['value']){
					$exists = true;
					break;
				}
			}
			if (!$exists){
				$tmp_series[] = ['s'=> $work['series']['value'], 'depth'=>$depth];
			}
		}
	}
	foreach ($tmp as $work){
		if ($work['parent']['value'] === $tmp_p){
			explore_children($tmp_series, $tmp, $work['series']['value'], $depth+1);
		}
	}
}

explore_children($tmp_series, $tmp, $tmp_p);


// 全階層の概念一覧
$concepts = [];
$relations = [];
$overrided = [];
$parents = [];

//var_dump($tmp_series);

foreach ($tmp_series as $series){

//echo "series :".$series."<br>\n";
	$series = $series['s'];

	$work_data = get_course_data($series, $concepts, $relations);

	/*
	if (count($concepts) == 0){
		continue;
	}*/

	$parents = array_merge($parents, $work_data['parents']);

	$add_relations = [];
	// 以下マージ処理
	// まずは新conceptの中に既存conceptの親が存在した場合、overridedに親を格納する
	foreach ($work_data['concepts'] as $key => $datum){
		if (isset($parents[$key])){
			// 親が存在する
			$prs = $parents[$key];
			foreach ($prs as $pr){
				if (!in_array($pr, $overrided)){
					$overrided[] = $pr;

					// 既存のrelationに、親がf/tになっているものがあった場合、追加する
					//$tmp_rels = $relations;
					$exists = false;
					$relations = add_check($relations, $relations, $work_data, $key, $pr, $exists);
					if ($exists){
						$relations = add_check($work_data['relations'], $relations, $work_data, $key, $pr, $exists);
					}
				}

			}
		}
		if (!isset($concepts[$key])){
			$concepts[$key] = $datum;
		}
	}
	$relations = array_merge($relations, $work_data['relations']);

}

function add_check($tmp_rels, &$relations, &$work_data, $key, $pr, &$exists){

	$add_relations = [];

	foreach ($tmp_rels as $rel){

		$f = $rel['f'];
		$t = $rel['t'];
		$hit = false;
		if ($rel['f'] == $pr){
			$f = $key;
			$hit = true;
		}
		if ($rel['t'] == $pr){
			$t = $key;
			$hit = true;
		}
		if ($hit){

			foreach ($work_data['relations'] as &$rel2){
				// 今回既に追加済みの場合は対象外（courseのみ上位に更新（無意味？））
				if ($f == $rel2['f'] && $t == $rel2['t'] && $rel['l'] == $rel2['l']){
					$hit = false;
					//echo "*not add f:".$rel['f'] . ' t:'.$rel['t'] . " =>  f:".$f . ' t:'.$t . " s:".$rel['s']."<br>\n";
					$rel2['s'] = $rel['s'];
				}
			}
			if ($hit){
				// 重複分は対象外
				foreach ($relations as &$rel2){
					if ($f == $rel2['f'] && $t == $rel2['t'] && $rel['l'] == $rel2['l']){
						$hit = false;
						break;
					}
				}
			}
			if ($hit){
				//echo "add f:".$rel['f'] . ' t:'.$rel['t'] . " =>  f:".$f . ' t:'.$t . " s:".$rel['s']."<br>\n";
				$add_relations[] = ['f'=>$f, 't'=>$t, 'l'=>$rel['l'], 's'=>$rel['s']];
			}
		}
	}
	if (count($add_relations) > 0){
		$relations = array_merge($relations, $add_relations);
		$exists = true;
	} else {
		$exists = false;
	}

	return $relations;
}

//var_dump($parents);

function get_course_core($series){
	global $lang, $const, $http;
	// コアプロセスの取得

	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
	"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?os ?label {\n".
	"<" . $series . "> rdfs:subClassOf ?n;\n".
	" rdfs:label ?l. ?series rdfs:label ?l.\n".
	" ?n owl:onProperty <" . $const['DATA_HAS_PART'] . ">;\n". // has_part
	"  owl:someValuesFrom ?os.\n".
	" ?os rdfs:label ?label.\n".
	" FILTER (lang(?label) = '" . $lang . "')\n".
	"}";
/*
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
	"PREFIX owl: <http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?os ?label {\n".
	"<" . $series . "> rdfs:subClassOf ?n;\n".
	" rdfs:label ?l.
	?series rdfs:label ?l.\n".
	" ?n owl:onProperty <" . $const['DATA_HAS_CORE_PROCESS'] . ">;\n". // has_part
	"(owl:someValuesFrom | owl:allValuesFrom) ?os.\n".
	"?os rdfs:label ?label.\n".
	"FILTER (lang(?label) = '" . $lang . "')\n".
	"}";
*/
//	echo $query;

	$tmp = $http->get($query);
	$cores = array();
	foreach ($tmp as $core){
		$cores[] = $core['os']['value'];
	}

	return $cores;
}

function find_recurse($relations, &$group, $from){
	foreach ($relations as $relation){
		/*
			if (strpos($relation['l'], "participant") !== false){
			continue;
			}*/
		if ($relation['f'] == $from && !in_array($relation['t'], $group)){
			$group[] = $relation['t'];
			find_recurse($relations, $group, $relation['t']);
		}
		if ($relation['t'] == $from && !in_array($relation['f'], $group)){
			$group[] = $relation['f'];
			find_recurse($relations, $group, $relation['f']);
		}
	}
}

function assemble_relation($relations, $cores){
	$tops = [];
	$rel_groups = [];

	// リンクの先頭ノードIDを収集する
	// TODO 循環している関連はうまく取得できない

	foreach ($relations as $relation){
		$hit = false;
		foreach ($relations as $rel2){
			if ($relation['f'] == $rel2['t']){
				$hit = true;
				break;
			}
		}
		if (!$hit){
			$tops[] = $relation['f'];
		}
	}

	// TODO 親をたどって自分に戻ってくる場合は循環なので、その巡回内の一つを代表としてtopsに追加する





	foreach ($tops as $top){
		$rel_groups[$top] = [$top];
		find_recurse($relations, $rel_groups[$top], $top, []);
	}
/*
	var_dump($cores);
	var_dump($rel_groups);
*/


	// 有効なrelationに含まれる概念を収集する
	$invalid_concepts = [];
	foreach ($rel_groups as $key => $rel_group){
		$tmp_group = array_merge($cores, $rel_group);
		if ($tmp_group === array_unique($tmp_group)){
			// 存在しない
			$invalid_concepts = array_unique(array_merge($invalid_concepts, $rel_group));
		}
	}

	$new_relation = [];
	// 有効な概念のみを持つrelationを収集する
	foreach ($relations as $relation){
		if (!(in_array($relation['f'], $invalid_concepts) && in_array($relation['t'], $invalid_concepts))){
			$new_relation[] = $relation;
		}
	}



	return $new_relation;
}

function get_course_data($series, $pconcepts, $prelations){
	global $lang, $type, $const, $const_label, $gene_map, $http, $type_map;

	$types = [];

	foreach ($type_map as $tp){
		if (strpos($tp['id'], 'http') !== false){
			$types[] = $tp['id'];
		}
	}


	// 全プロセスの取得
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?parent ?plabel ?process ?label ?rtype ?relation ?rlabel\n".
	"{\n".
	"{\n".
	/*
	"{<" . $series . "> (rdfs:subClassOf/owl:someValuesFrom)+ ?process;\n".
	" rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">}\n".
	*/
	"<" . $series . "> rdfs:subClassOf ?n1.
	?n1 (owl:someValuesFrom/rdfs:subClassOf)* ?n2.
	?n2 owl:someValuesFrom ?process.
	{?n2 owl:onProperty <" . implode(">} union \n {?n2 owl:onProperty <", $types) . ">}
	FILTER(isBlank(?n1))
	FILTER(isBlank(?n2))
	FILTER(!isBlank(?process))".


	"?process rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] .">;\n".
	" rdfs:label ?label.\n".
	"optional {\n".
	" ?process rdfs:subClassOf+ ?parent.\n".
	" ?parent rdfs:label ?plabel;\n".
	"  rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">;\n".
	"  rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
	" FILTER (lang(?plabel) = '" . $lang . "')\n".
	" FILTER (isIri(?parent))\n".
	"}\n".
	" FILTER (lang(?label) = '" . $lang . "')\n".
	"} optional {\n".
	"{\n".
	"?process rdfs:subClassOf ?n.\n".
	" ?n owl:onProperty ?rtype;\n".
	" owl:someValuesFrom ?relation.
	{?n owl:onProperty <" . implode(">} union \n {?n owl:onProperty <", $types) . ">}
	?relation rdfs:label ?rlabel.\n".
	" FILTER (lang(?rlabel) = '" . $lang . "')\n".
	" FILTER (isBlank(?n))\n".
	"}\n".
	"}\n".
	"} order by ?process";


//	echo $query;


	$data = $http->get($query);


	$ret = [];

	// concepts / relations
	// conceptsにはid,parent,label情報
	// relationsにはfrom-to, label, series情報

	$concepts = [];
	$relations = [];
	$parents = [];
	//$series_list = array();

	//concept/ relationを抽出
	foreach ($data as $datum){
		$pid = $datum['process']['value'];
		$parent = null;
		if (isset($datum['parent'])){
			$parent = $datum['parent']['value'];
		}

		$tmp_type = null;
		if (isset($gene_map[$pid])){
			$tmp_type = $gene_map[$pid];
		}

		if (!isset($concepts[$pid])){
			$concepts[$pid] = ['id'=>$pid, 'l'=>$datum['label']['value'], 's'=>$series, 't'=>$tmp_type, 'pr'=>$parent];
		}

		if (array_key_exists('rtype', $datum) && in_array($datum['rtype']['value'], $type)){

			$rid = $datum['relation']['value'];
			$dup = false;

			$tmp_rels = array_merge($prelations, $relations);

			foreach ($tmp_rels as $rel){
				if ($rel['f'] == $pid && $rel['t'] == $rid && $rel['l'] == $const_label[$datum['rtype']['value']]){
					$dup = true;
					break;
				}
			}

			if (!$dup){
				$relations[] = ['f'=>$pid, 't'=>$rid, 'l'=>$const_label[$datum['rtype']['value']], 's'=>$series];

				$tmp_type = null;
				if (!isset($concepts[$rid])){
					if (isset($gene_map[$rid])){
						$tmp_type = $gene_map[$rid];
					}
					$concepts[$rid] = ['id'=>$rid, 'l'=>$datum['rlabel']['value'], 's'=>$series, 't'=>$tmp_type];
				}
			}
		}

		if ($parent == null){
			continue;
		}
		$tmp_parents = null;
		if (isset($parents[$pid])){
			$tmp_parents = $parents[$pid];
		} else {
			$tmp_parents = [];
		}
		if (!in_array($parent, $tmp_parents)){
	//echo 'append $tmp_parents to ['.$pid."]<br>\n";
			$tmp_parents[] = $parent;
		}
		$parents[$pid] = $tmp_parents;
	}

	$ret['concepts'] = $concepts;
	$ret['relations'] = $relations;
	$ret['parents'] = $parents;

	$cores = get_course_core($series);

	// TODO
	// 作用機序が直接has_partで保持しているプロセスを始点として、
	// 特定の関連種別で関連している概念のみを抽出する
	// 該当しないものは削除する

	$ret['relations'] = assemble_relation_type($ret['relations'], $cores);

	// coreノードから独立しているノード・関連は削除する
	$ret['relations'] = assemble_relation($ret['relations'], $cores);

	return $ret;
}

$ret['concepts'] = [];

foreach ($concepts as $key => $con){
	if (in_array($key, $overrided)){
		continue;
	}
	$ret['concepts'][] = $con;
}

$ret['relations'] = [];
foreach ($relations as $rel){
	if (in_array($rel['f'], $overrided) || in_array($rel['t'], $overrided)){
		continue;
	}
	$ret['relations'][] = $rel;
}
/*

$cores = get_course_core($series);

// TODO
// 作用機序が直接has_partで保持しているプロセスを始点として、
// 特定の関連種別で関連している概念のみを抽出する
// 該当しないものは削除する

$ret['relations'] = assemble_relation_type($ret['relations'], $cores);

// coreノードから独立しているノード・関連は削除する
$ret['relations'] = assemble_relation($ret['relations'], $cores);
*/

$new_concepts = $ret['concepts'];


function assemble_relation_type($relations, $cores){
	global $lang, $type_id, $type_map;

	$types = [];
	$new_relations = [];
/*
	foreach ($type as $tp){
		$types[] = $type_map[$tp]['l'];
	}
	*/
	foreach ($type_map as $key => $value){
		if (strpos($type_id, $key) !== false){
			$type[] = $value['l'];
		}
	}


	foreach ($cores as $core){
		assemble_relation_type_recurse($relations, $core, $new_relations, $type);
	}

	return $new_relations;
}

function assemble_relation_type_recurse(&$relations, $core, &$new_relations, &$type){
	foreach($relations as $relation){
		if (in_array($relation, $new_relations)){
			// 既に追加済みの場合はスルー
			continue;
		}
		if ($relation['f'] == $core && in_array($relation['l'], $type)){
			$new_relations[] = $relation;
			assemble_relation_type_recurse($relations, $relation['t'], $new_relations, $type);
		} else
		if ($relation['t'] == $core && in_array($relation['l'], $type)){
			$new_relations[] = $relation;
			assemble_relation_type_recurse($relations, $relation['f'], $new_relations, $type);
		}
	}
}

//var_dump($new_concepts);

// 関連がどこにもつながっていないノードを削除する
$tmp_concepts = $new_concepts;
$new_concepts = array();
foreach ($tmp_concepts as $datum){
	$s = $datum['id'];
	$hit = false;
	if (isset($datum['c'])){
		// combineであればtrue
		$hit = true;
	} else {
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}
	}
	if ($hit){
		$new_concepts[] = $datum;
	}
}

function concept_depth($key, $tmp_series){
	foreach ($tmp_series as $tmp_s){
		if ($tmp_s['s'] == $key){
			return $tmp_s['depth'];
		}
	}
	return 1;
}

foreach ($new_concepts as &$datum){
//	$datum['depth'] = (count($tmp_series) - array_search($datum['s'], $tmp_series)) - 1;
//	$datum['depth'] = array_search($datum['s'], $tmp_series);
	$datum['depth'] = concept_depth($datum['s'], $tmp_series);

//	echo $datum['l']."\n";
}
foreach ($ret['relations'] as &$relation){
//	$relation['depth'] = (count($tmp_series) - array_search($relation['s'], $tmp_series)) - 1;
//	$relation['depth'] = array_search($relation['s'], $tmp_series);
	$relation['depth'] = concept_depth($relation['s'], $tmp_series);
}


 $ret['concepts'] = $new_concepts;


header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>