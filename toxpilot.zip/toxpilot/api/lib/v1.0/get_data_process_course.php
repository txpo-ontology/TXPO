<?php
// 汎用機序マップデータ取得用

include_once "get_data_process_course_lib.php";



if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}

$ret = array();
$ret['id'] = $id;
$ret['result'] = true;

$courses = get_process_course($id, $lang, $const);

$ret['courses'] = $courses;


header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>