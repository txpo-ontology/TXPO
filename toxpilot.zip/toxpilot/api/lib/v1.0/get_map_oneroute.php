<?php
// 経路マップデータ取得用

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";
include_once "get_data_type_lib.php";
include_once "get_data_parents_lib.php";

/*
 $lang = 'ja';
 $args = ['id'=>'txpo:TXPO_0001698', 'find_type'=>'generic'];
*/

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}

$find_type = null;
$pid = null;
if (array_key_exists('find_type', $args)){
	$find_type = $args['find_type'];
}
if ($find_type == null || $find_type == ''){
	$find_type = 'single';
} else {
	if ($find_type != 'single' && $find_type != 'general'){
		$pid = $find_type;
		$pid = decode_prefix($pid);
		$find_type = 'general';
	}
}

$direction = null;
if (array_key_exists('direction', $args)){
	$direction = $args['direction'];
}
if ($direction == null || $direction == ''){
	$direction = 'result';
}

$depth = null;
if (array_key_exists('depth', $args)){
	$depth = intval($args['depth']);
}
if ($depth == null || $depth == ''){
	$depth = 5;
}


$id = decode_prefix($id);

$finding = true;
/*
if (strpos($find_type,'finding') !== false) {
	// finding
	$finding = true;
}
*/

$http = new Http();

// 一点中心探索

function findResultFromOnePoint($id, $maxDepth, $finding){

	$work_nodes = array();
	$relations = array();
	$dic = array();

//	$work_nodes[$id]['type'] = 'route root';
/*
	if ($finding){
		base_finding($id, $work_nodes, $relations, $dic);
	}
	*/
	findMyselfFromOnePoint($id, $work_nodes, $relations, $dic, $finding);


	findResultFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding);

	$data = array();
	//
	foreach (array_keys($work_nodes) as $key){
		$node = $work_nodes[$key];
		$dup = false;
		foreach ($data as $datum){
			if ($datum['id'] == $key){
				$dup = true;
				break;
			}
		}
		if (!$dup){
			if (isset($node['type'])){
				$data[] = ['id'=>$key, 'l'=>$dic[$key], 't'=>$node['type']];
			} else {
				$data[] = ['id'=>$key, 'l'=>$dic[$key]];
			}
		}
	}

	return ['concepts'=>$data, 'relations'=>$relations];

}

function findCauseFromOnePoint($id, $maxDepth, $finding){

	$work_nodes = array();
	$tmp_nodes = array();
	$relations = array();
	$dic = array();
/*
	$work_nodes[$id]['type'] = 'route root';

	if ($finding){
		base_finding($id, $work_nodes, $relations, $dic);
	}
	*/
	findMyselfFromOnePoint($id, $work_nodes, $relations, $dic, $finding);


	findCauseFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding);

	$data = array();
	//
	foreach (array_keys($work_nodes) as $key){
		$node = $work_nodes[$key];
	/*
		 var node = work_nodes[key];
		 self.data.push({'id':key, 'label':self.dic[key], 'type':node.type});
		 */
		$dup = false;
		foreach ($data as $datum){
			if ($datum['id'] == $key){
				$dup = true;
				break;
			}
		}
		if (!$dup){
			if (isset($node['type'])){
				$data[] = ['id'=>$key, 'l'=>$dic[$key], 't'=>$node['type']];
			} else {
				$data[] = ['id'=>$key, 'l'=>$dic[$key]];
			}
		}
	}

	return ['concepts'=>$data, 'relations'=>$relations];

}

function findCauseResultFromOnePoint($id, $maxDepth, $finding){

	$work_nodes = array();
	$tmp_nodes = array();
	$relations = array();
	$dic = array();

//	$work_nodes[$id]['type'] = 'route root';


	/*
	if ($finding){
		base_finding($id, $work_nodes, $relations, $dic);
	}*/
	findMyselfFromOnePoint($id, $work_nodes, $relations, $dic, $finding);

	findCauseFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding);
	findResultFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding);

	$data = array();
	//
	foreach (array_keys($work_nodes) as $key){
		$node = $work_nodes[$key];
		/*
		 var node = work_nodes[key];
		 self.data.push({'id':key, 'label':self.dic[key], 'type':node.type});
		 */
		$dup = false;
		foreach ($data as $datum){
			if ($datum['id'] == $key){
				$dup = true;
				break;
			}
		}
		if (!$dup){
			if (isset($node['type'])){
				if (isset($dic[$key])){
					$data[] = ['id'=>$key, 'l'=>$dic[$key], 't'=>$node['type']];
				} else {
					$data[] = ['id'=>$key, 'l'=>$key, 't'=>$node['type']];
				}
			} else {
				$data[] = ['id'=>$key, 'l'=>$dic[$key]];
			}
		}

	}

	return ['concepts'=>$data, 'relations'=>$relations];

}


function findMyselfFromOnePoint($id, &$work_nodes, &$relations, &$dic, $finding){
	global $const, $http, $lang;
	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?l ?finding ?fl {
	 <" . $id . "> rdfs:label ?l.
	 FILTER (lang(?l) = '" . $lang . "')
		optional {
	 		<" . $id . "> rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}
	}";

	if ($work_nodes == null){
		$work_nodes = array();
	}

	$data = $http->get($query);

	foreach ($data as $datum){
		$label = $datum['l'];

		addToDic($dic, $id, $label);

		if (!isset($work_nodes[$id])){
			$work_nodes[$id] = ['id'=>$id, 'type'=>'route root']; // labelは仮
		}

		if ($finding){
			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];

				addToDic($dic, $finding, $datum['fl']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';

				$relation = ['f'=>$id, 't'=>$finding, 'l'=>'has finding'];
				$relations[] = $relation;

			}
		}
	}

}


function findResultFromOnePointRecurse($id, $maxDepth, $currentDepth, &$work_nodes, &$tmp_nodes, &$relations, &$dic, $finding){
	global $const, $http, $lang;

	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct  (<" . $id . "> as ?cause) ?cl ?result ?rl ?finding ?fl {
	 <" . $id . "> rdfs:subClassOf ?n;
	  rdfs:label ?cl.
	 ?n owl:someValuesFrom ?result;
	  owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
	 ?result rdfs:label ?rl.
	 FILTER(isBlank(?n))
	 FILTER (lang(?cl) = '" . $lang . "')
	 FILTER (lang(?rl) = '" . $lang . "')
		optional {
	 		?result rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}
	}";
	/*
	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct  (<" . $id . "> as ?cause) ?cl ?result ?rl ?finding ?fl {
	 <" . $id . "> rdfs:subClassOf* ?parent;
	  rdfs:label ?cl.
	 ?parent rdfs:subClassOf ?n.
	 ?n owl:someValuesFrom ?result;
	  owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
	 ?result rdfs:label ?rl.
	 FILTER(isBlank(?n))
	 FILTER (lang(?cl) = '" . $lang . "' || lang(?cl) = '')
	 FILTER (lang(?rl) = '" . $lang . "' || lang(?rl) = '')
		optional {
	 		?result rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "' || lang(?fl) = '')
		}
	}";
	*/


	if ($currentDepth == null){
		$currentDepth = 1;
//		this.current.id = s;
	}
	if ($work_nodes == null){
		$work_nodes = array();
	}

	$data = $http->get($query);

	foreach ($data as $datum){
		$cause = $datum['cause']['value'];
		$clabel = $datum['cl'];
		$result = $datum['result']['value'];
		$rlabel = $datum['rl'];

		addToDic($dic, $cause, $clabel);
		addToDic($dic, $result, $rlabel);

		$exists = false;
		if (isset($tmp_nodes[$result])){
			$exists = true;
		} else {
			$tmp_nodes[$result] = ['id'=> $result];
		}

		if (!isset($work_nodes[$cause])){
			$work_nodes[$cause] = ['id'=>$cause]; // labelは仮
		}
		if (!isset($work_nodes[$result])){
			$work_nodes[$result] = ['id'=>$result, 'type'=>'route result']; // labelは仮
		} else {
			$work_nodes[$result]['type'] =  'route result';
		}
		//			self.relations.push({'from':cause, 'to' : result, 'label':currentDepth});
		$rel_label = $currentDepth;

		// depthに-1が指定されている場合、該当ノードの下にぶら下がる深さを算出する
		if ($currentDepth < 0){
			$d = 0;
			foreach ($relations as $rel){
				if ($rel.from == $result){
					if ($d <= $rel.label){
						$d = ($rel.label+1);
					}
				}
			}
			$rel_label = $d;
		}

		$relation = ['f'=>$cause, 't'=>$result, 'l'=>$rel_label];

		$dup = false;
		foreach ($relations as $rel){
			if (json_encode($rel) == json_encode($relation)){
				$dup = true;
				break;
			}
		}
		if (!$dup){
			$relations[] = $relation;
		}

//		if (!$dup && $finding){
		if ($finding){

			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];
				$relation = ['f'=>$result, 't'=>$finding, 'l'=>'has finding'];

				$dup = false;
				foreach ($relations as $rel){
					if (json_encode($rel) == json_encode($relation)){
						$dup = true;
						break;
					}
				}
				if (!$dup){
					addToDic($dic, $finding, $datum['fl']);
					$work_nodes[$finding] = ['id'=>$finding];
					$work_nodes[$finding]['type'] =  'route finding';

					$relations[] = $relation;
				}

			}
		}


		if ($maxDepth > $currentDepth && !$exists){
			findResultFromOnePointRecurse($result, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding);
		}
	}

}



function findCauseFromOnePointRecurse($id, $maxDepth, $currentDepth, &$work_nodes, &$tmp_nodes, &$relations, &$dic, $finding){
	global $const, $http, $lang;

	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?cause ?cl (<" . $id . "> as ?result) ?rl ?finding ?fl {
	 ?cause rdfs:subClassOf ?n.
	 ?n owl:someValuesFrom <" . $id . ">;
	  owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
	 ?cause rdfs:label ?cl.
	 <" . $id . "> rdfs:label ?rl.
	  FILTER(isBlank(?n))
	  FILTER (lang(?cl) = '" . $lang . "')
	  FILTER (lang(?rl) = '" . $lang . "')
		optional {
	 		?cause rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}
	}";
	/*
	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?cause ?cl (<" . $id . "> as ?result) ?rl ?finding ?fl {
	 ?cause rdfs:subClassOf ?n.
	 ?n owl:someValuesFrom ?parent;
	  owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
	 <" . $id . "> rdfs:subClassOf* ?parent.
	 ?cause rdfs:label ?cl.
	 <" . $id . "> rdfs:label ?rl.
	  FILTER(isBlank(?n))
	  FILTER (lang(?cl) = '" . $lang . "' || lang(?cl) = '')
	  FILTER (lang(?rl) = '" . $lang . "' || lang(?rl) = '')
		optional {
	 		?cause rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "' || lang(?fl) = '')
		}
	}";
	*/
//echo $query;

	if ($currentDepth == null){
		$currentDepth = 1;
		//		this.current.id = s;
	}
	if ($work_nodes == null){
		$work_nodes = array();
	}

	$data = $http->get($query);

	foreach ($data as $datum){
		$cause = $datum['cause']['value'];
		$clabel = $datum['cl'];
		$result = $datum['result']['value'];
		$rlabel = $datum['rl'];

		addToDic($dic, $cause, $clabel);
		addToDic($dic, $result, $rlabel);

		$exists = false;
		if (isset($tmp_nodes[$cause])){
			$exists = true;
		} else {
			$tmp_nodes[$cause] = ['id'=> $cause];
		}

		if (!isset($work_nodes[$cause])){
			$work_nodes[$cause] = ['id'=>$cause, 'type'=>'route cause']; // labelは仮
		} else {
			$work_nodes[$cause]['type'] =  'route cause';
		}
		if (!isset($work_nodes[$result])){
			$work_nodes[$result] = ['id'=>$result]; // labelは仮
		}
		//			self.relations.push({'from':cause, 'to' : result, 'label':currentDepth});
		$rel_label = $currentDepth;

		// depthに-1が指定されている場合、該当ノードの下にぶら下がる深さを算出する
		if ($currentDepth < 0){
			$d = 0;
			foreach ($relations as $rel){
				if ($rel.from == $result){
					if ($d <= $rel.label){
						$d = ($rel.label+1);
					}
				}
			}
			$rel_label = $d;
		}

		$relation = ['f'=>$cause, 't'=>$result, 'l'=>$rel_label];

		$dup = false;
		foreach ($relations as $rel){
			if (json_encode($rel) == json_encode($relation)){
				$dup = true;
				break;
			}
		}
		if (!$dup){
			$relations[] = $relation;
		}

//		if (!$dup && $finding){
		if ($finding){
			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];
				$relation = ['f'=>$cause, 't'=>$finding, 'l'=>'has finding'];


				$dup = false;
				foreach ($relations as $rel){
					if (json_encode($rel) == json_encode($relation)){
						$dup = true;
						break;
					}
				}

				if (!$dup){
					addToDic($dic, $finding, $datum['fl']);
					$work_nodes[$finding] = ['id'=>$finding];
					$work_nodes[$finding]['type'] =  'route finding';
					$relations[] = $relation;
				}
			}
		}

		if ($maxDepth > $currentDepth && !$exists){
			findCauseFromOnePointRecurse($cause, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding);
		}
	}

}

function findGenericCauseResultFromOnePoint($id, $maxDepth, $finding, $pid){
	$work_nodes = array();
	$tmp_nodes = array();
	$relations = array();
	$dic = array();

	$islv3 = isLv3Node($id);

//	findGenericMyselfFromOnePoint($id, $work_nodes, $relations, $dic, $finding, $pid);
	findGenericResultFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);
	findGenericCauseFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);

	return makeGenericResult($id, $maxDepth, $work_nodes, $relations, $dic);

}

function findGenericResultFromOnePoint($id, $maxDepth, $finding, $pid){
	$work_nodes = array();
	$tmp_nodes = array();
	$relations = array();
	$dic = array();

	$islv3 = isLv3Node($id);

	findGenericResultFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);

	return makeGenericResult($id, $maxDepth, $work_nodes, $relations, $dic);

}

function findGenericCauseFromOnePoint($id, $maxDepth, $finding, $pid){
	$work_nodes = array();
	$tmp_nodes = array();
	$relations = array();
	$dic = array();

	$islv3 = isLv3Node($id);

	findGenericCauseFromOnePointRecurse($id, $maxDepth, 1, $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);

	return makeGenericResult($id, $maxDepth, $work_nodes, $relations, $dic);
}

function isLv3Node($id){
	global $const, $http;
	$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
select distinct ?l {
 <" . $id . "> rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">;
  rdfs:label ?l.
}";

	$data = $http->get($query);

	return (count($data) > 0);
}

function makeGenericResult($id, $maxDepth, $work_nodes, $relations, $dic){
	global $const;
	reset($work_nodes);

	$data = array();
	//

//	$tmp_nodes = array_values($work_nodes);
//	$work_parents = get_concept_parents($tmp_nodes);


	foreach (array_keys($work_nodes) as $key){

		$node = $work_nodes[$key];
		$dup = false;
		foreach ($data as $datum){
			if ($datum['id'] == $key){
				$dup = true;
				break;
			}
			if (isset($datum['c'])){
				foreach($datum['c'] as $tmp){
					if ($tmp['id'] == $key){
						$dup = true;
						break;
					}
				}
			}
		}
		if (!$dup){
			if ($node != null){
				$onedata = ['id'=>$key, 'l'=>$dic[$key]];
				if (isset($node['type'])){
					$onedata['t'] = $node['type'];
				} else {
					$onedata['t'] = 'route root';
				}
				$onedata['c'] = array();
				if (isset($node['siblings'])){
					foreach ($node['siblings'] as $s){
						$onedata['c'][] = ['id'=>$s, 'l'=>$dic[$s]];

						foreach ($relations as &$relation){
//							is_parent($key, )
							if ($relation['f'] == $s){
								$relation['f'] = $key; // 親に繋ぎかえる
							}
						}
						foreach ($relations as &$relation){
							if ($relation['t'] == $s){
								$relation['t'] = $key; // 親に繋ぎかえる
							}
						}

					}
				}
				$data[] = $onedata;
			}
		}
	}

	$temp_relations = array();
	foreach ($relations as $rel){

		if ($rel['l'] == 'has finding'){
			$temp_relations[] = ['f'=>$rel['f'], 't'=>$rel['t'], 'l'=>$rel['l']];
		} else {
			$depth = 100;
			foreach ($temp_relations as $tmp){
				// TODO $rel['f'] がfindingsの場合はskip

				if ($rel['f'] == $tmp['f'] && $rel['t'] == $tmp['t']){
					if ($depth > $rel['l']){
						$depth = $rel['l'];
					}
					if ($depth > $tmp['l']){
						$depth = $tmp['l'];
					}
					$tmp['l'] = $depth;
				}
			}
			if ($depth == 100){ //
				if (!is_int($rel['l']) || (0< $rel['l'] && $rel['l'] <= $maxDepth)){
					$temp_relations[] = ['f'=>$rel['f'], 't'=>$rel['t'], 'l'=>$rel['l']];
				}
			}
		}
	}
	$relations = $temp_relations;

	// has_findingsのfromノードが孤立しているか（toノードに存在するか）をチェック
	$temp_relations = array();
	foreach ($relations as $rel){

		if ($rel['l'] != 'has finding'){
			$temp_relations[] = $rel;
		} else {
			$process = $rel['f'];
			$hit = false;
			foreach ($relations as $rel2){
				if ($rel2['t'] == $process){
					$hit = true;
					break;
				}
			}
			if ($hit){
				$temp_relations[] = $rel;
			}
		}
	}
	$relations = $temp_relations;


	// 最後に孤立ノードを削除
	$new_data = [];
	foreach ($data as $datum){
		$hit = false;
		if ($datum['id'] == $id || (isset($work_nodes[$datum['id']]) && isset($work_nodes[$datum['id']]['siblings']) && in_array($id, $work_nodes[$datum['id']]['siblings']))){
			$hit = true;
		}
		if (!$hit){
			foreach ($relations as $rel){
				if ($datum['id'] == $id || $datum['id'] == $rel['f'] || $datum['id'] == $rel['t']){
					$hit = true;
					break;
				}
			}
		}
		if ($hit){
			$new_data[] = $datum;
		}
	}

	return ['concepts'=>$new_data, 'relations'=>$relations];

}

function findGenericMyselfFromOnePoint($id, &$work_nodes, &$relations, &$dic, $finding, $pid){
	global $const, $http, $lang;
	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?sibling ?slabel ?finding ?fl {
		?sibling rdfs:subClassOf+ <" . $pid .">;
		 rdfs:label ?slabel.
		FILTER (lang(?slabel) = '" . $lang . "')
		optional {
	 		?sibling rdfs:subClassOf ?n2.
	 		?n2 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}
	}";

	if ($work_nodes == null){
		$work_nodes = array();
	}

//	echo $query;

	$data = $http->get($query);
	$siblings = array();
	foreach ($data as $datum){
		$sibling = $datum['sibling']['value'];
		if (!in_array($sibling, $siblings)){
			$siblings[] = $sibling;
		}
	}

	$from = $id;
	if (count($siblings) > 1){
		$generic = true;
		$from = $pid;
	$work_nodes[$from] = ['id'=>$from, 'siblings'=>$siblings, 'parent'=>null, 'type'=>'route root'];
	$tmp_nodes[$from] = ['id'=>$from];
	}


	foreach ($data as $datum){
		$sibling = $datum['sibling']['value'];
		$slabel = $datum['slabel'];

		addToDic($dic, $sibling, $slabel);


		if ($finding){
			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];

				addToDic($dic, $finding, $datum['fl']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';

				$relation = ['f'=>$sibling, 't'=>$finding, 'l'=>'has finding'];
				$relations[] = $relation;

			}
		}
	}

}


function findGenericResultFromOnePointRecurse($id, $maxDepth, $currentDepth, &$work_nodes, &$tmp_nodes, &$relations, &$dic, $finding, $islv3){
	global $const, $http, $lang;

	if ($islv3){
		$lv3append = "rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">";
	} else {
		$lv3append = "";
	}
	$query = "
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?parent ?plabel (<" . $id ."> as ?cause) ?clabel ?sibling ?slabel ?result ?rlabel ?presult ?prlabel ?finding ?fl ?finding2 ?fl2 {
	{
		<" . $id ."> rdfs:subClassOf ?parent;
			" . $lv3append . ";
		 rdfs:label ?clabel.
		?parent rdfs:label ?plabel.

		{?parent rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.}

		?sibling rdfs:subClassOf ?parent;
			" . $lv3append . ";
				rdfs:label ?slabel.
	} optional {
		?parent rdfs:subClassOf ?n1.
		?n1 owl:someValuesFrom ?presult;
		 owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
		?presult rdfs:label ?prlabel;
			" . $lv3append . ".
		FILTER (lang(?prlabel) = '" . $lang . "')
	} optional {
		?sibling rdfs:subClassOf ?n2.
		?n2 owl:someValuesFrom ?result;
		 owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
		?result rdfs:label ?rlabel.
		FILTER (lang(?rlabel) = '" . $lang . "')
	}
		{optional {
	 		<" . $id ."> rdfs:subClassOf ?n3.
	 		?n3 owl:someValuesFrom ?finding2;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding2 rdfs:label ?fl2.
	 		FILTER (lang(?fl2) = '" . $lang . "')
		}}
		union {
	 		?parent rdfs:subClassOf ?n4.
	 		?n4 owl:someValuesFrom ?finding2;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding2 rdfs:label ?fl2.
	 		FILTER (lang(?fl2) = '" . $lang . "')
		}
		optional {
	 		?sibling rdfs:subClassOf ?n5.
	 		?n5 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}

				FILTER (lang(?plabel) = '" . $lang .  "')
	FILTER (lang(?clabel) = '" . $lang . "')
	FILTER (lang(?slabel) = '" . $lang . "')
	}";

//	echo $query;


//echo "cause:".$id."\n";
	$data = $http->get($query);
	$siblings = array();
	foreach ($data as $datum){
		$sibling = $datum['sibling']['value'];
		if (!in_array($sibling, $siblings)){
			$siblings[] = $sibling;
		}
	}

	$parent = null;

	foreach ($data as $datum){
		$parent = $datum['parent']['value'];
		$plabel = $datum['plabel'];
		$cause = $datum['cause']['value'];
		$clabel = $datum['clabel'];
		$sibling = $datum['sibling']['value'];
		$slabel = $datum['slabel'];
		$result = null;
		$rlabel = null;
		$presult = null;
		$prlabel = null;
		$exists = false;

		if (isset($datum['result'])){
			$result = $datum['result']['value'];
//echo " result:".$result."\n";
		}
		if (isset($datum['rlabel'])){
			$rlabel = $datum['rlabel'];
		}

		if (isset($datum['presult'])){
			$presult = $datum['presult']['value'];
		}
		if (isset($datum['prlabel'])){
			$prlabel = $datum['prlabel'];
		}


		$generic = false;
		$from = $cause;
		$fparent = $parent;
//		if (count($siblings) > 1){
		{
//echo $cause . " from = ".$parent."<br>";
			$generic = true;
			$from = $parent;
			$fparent = null;
		}
		if ($currentDepth == ($maxDepth+1)){
			$result = null;
		}

		addToDic($dic, $parent, $plabel);
		addToDic($dic, $cause, $clabel);
		addToDic($dic, $sibling, $slabel);
		if ($result != null && $rlabel != null){
			// すでに探索済みの場合は検索を止める
			if (isset($tmp_nodes[$result])){
				$exists = true;
			}

			addToDic($dic, $result, $rlabel);
		}

		if ($presult != null && $prlabel != null){
			// すでに探索済みの場合は検索を止める
			if (isset($tmp_nodes[$presult])){
				$exists = true;
			}

			addToDic($dic, $presult, $prlabel);
		}


		if (!isset($work_nodes[$from])){
			$work_nodes[$from] = ['id'=>$from, 'siblings'=>$siblings, 'parent'=>$fparent];
			$tmp_nodes[$from] = ['id'=>$from];
		}
		if ($result != null){
			if (isset($tmp_nodes[$result])){
				$result = null;
			} else {
				$tmp_nodes[$result] = ['id'=>$result];

				if (!isset($work_nodes[$result])){
					$work_nodes[$result] = ['id'=>$result, 'type'=>'route result', 'siblings'=>array(), 'parent'=>null]; // labelは仮
				} else {
					$work_nodes[$result]['type'] = 'route result'; // labelは仮
				}
			}
		}

		if ($presult != null){
			if (isset($tmp_nodes[$presult])){
				$presult = null;
			} else {
				$tmp_nodes[$presult] = ['id'=>$presult];

				if (!isset($work_nodes[$presult])){
					$work_nodes[$presult] = ['id'=>$presult, 'type'=>'route result', 'siblings'=>array(), 'parent'=>null]; // labelは仮
				} else {
					$work_nodes[$presult]['type'] = 'route result'; // labelは仮
				}
			}
		}


		$rel_label = $currentDepth;

		if ($generic){
			foreach ($relations as &$relation){
				if ($relation['t'] == $cause){
					$relation['t'] = $parent; // 親に繋ぎかえる
				}
			}
			foreach (array_keys($work_nodes) as $key){
				if ($key == $cause){
					$work_nodes[$key] = null;
					$work_nodes[$parent]['type'] = 'route result';
					if (!in_array($key, $work_nodes[$parent]['siblings'])){
						$work_nodes[$parent]['siblings'][] = $key;
					}
				}
			}
		}

		if ($finding){

			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];

				addToDic($dic, $finding, $datum['fl']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';
				$tmp_nodes[$finding] = ['id'=>$finding];

				$rel = ['f'=>$parent, 't'=>$finding, 'l'=>'has finding'];

				$relations[] = $rel;

			}

			if (isset($datum['finding2']) && isset($datum['fl2'])){
				$finding = $datum['finding2']['value'];

				addToDic($dic, $finding, $datum['fl2']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';
				$tmp_nodes[$finding] = ['id'=>$finding];

				if ($generic){
					$rel = ['f'=>$parent, 't'=>$finding, 'l'=>'has finding'];
				} else {
					$rel = ['f'=>$id, 't'=>$finding, 'l'=>'has finding'];
				}
				$relations[] = $rel;
			}

		}

		if ($result == null && $presult == null){
			continue;
		}


		// depthに-1が指定されている場合、該当ノードの下にぶら下がる深さを算出する
		if ($currentDepth < 0){
			$d = 0;
			foreach ($relations as $relation){
				if ($relation['t'] == $from){
					if ($d <= $relations['l']){
						$d = ($relation['l']+1);
					}
				}
			}
			$rel_label = $d;
		}

		if ($result != null){
			$rel = ['f'=>$from, 't'=>$result, 'l'=>$rel_label];

			$relations[] = $rel;

			if (($maxDepth+1) > $currentDepth && !$exists){
				findGenericResultFromOnePointRecurse($result, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);
			}
		}
		if ($presult != null){
			$rel = ['f'=>$from, 't'=>$presult, 'l'=>$rel_label];

			$relations[] = $rel;

			if (($maxDepth+1) > $currentDepth && !$exists){
				findResultFromOnePointRecurse($presult, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding);
			}
		}
	}

}

function findGenericCauseFromOnePointRecurse($id, $maxDepth, $currentDepth, &$work_nodes, &$tmp_nodes, &$relations, &$dic, $finding, $islv3){
	global $const, $http, $lang;

	if ($islv3){
		$lv3append = "rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">";
	} else {
		$lv3append = "";
	}

	$query = "
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?parent ?plabel ?cause ?clabel ?pcause ?pclabel ?sibling ?slabel (<" . $id . "> as ?result) ?rlabel ?finding ?fl ?finding2 ?fl2 {
	{
		<" . $id . "> rdfs:subClassOf ?parent;
			" . $lv3append . ";
		 rdfs:label ?rlabel.
		?parent rdfs:label ?plabel.

		{?parent rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">.}

		?sibling rdfs:subClassOf ?parent;
			" . $lv3append . ";
				rdfs:label ?slabel.
	} optional {
		?cause rdfs:subClassOf ?n2.

		?n2 owl:someValuesFrom ?sibling;
		 owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
		?cause rdfs:label ?clabel.
		FILTER (lang(?clabel) = '" . $lang . "')
	}
		{
			optional {
		 		<" . $id ."> rdfs:subClassOf ?n3.
		 		?n3 owl:someValuesFrom ?finding2;
		 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
		 		?finding2 rdfs:label ?fl2.
		 		FILTER (lang(?fl2) = '" . $lang . "')
			}
		} union {
	 		?parent rdfs:subClassOf ?n4.
	 		?n4 owl:someValuesFrom ?finding2;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding2 rdfs:label ?fl2.
	 		FILTER (lang(?fl2) = '" . $lang . "')
		} union {
			?pcause rdfs:subClassOf ?n1.
			?n1 owl:someValuesFrom ?parent;
			 owl:onProperty <" . $const['DATA_HAS_RESULT'] . ">.
			?pcause rdfs:label ?pclabel;
			" . $lv3append . ".
			FILTER (lang(?pclabel) = '" . $lang . "')
		} union {
	 		?sibling rdfs:subClassOf ?n5.
	 		?n5 owl:someValuesFrom ?finding;
	 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
	 		?finding rdfs:label ?fl.
	 		FILTER (lang(?fl) = '" . $lang . "')
		}
	 	FILTER (lang(?plabel) = '" . $lang . "')
	FILTER (lang(?rlabel) = '" . $lang . "')
	FILTER (lang(?slabel) = '" . $lang . "')
	}";

//	echo $query;

	$data = $http->get($query);
	$siblings = array();
	foreach ($data as $datum){
		$sibling = $datum['sibling']['value'];
		if (!in_array($sibling, $siblings)){
			$siblings[] = $sibling;
		}
	}

	foreach ($data as $datum){
		$parent = $datum['parent']['value'];
		$plabel = $datum['plabel'];
		$result = $datum['result']['value'];
		$rlabel = $datum['rlabel'];
		$sibling = $datum['sibling']['value'];
		$slabel = $datum['slabel'];
		$cause = null;
		$clabel = null;
		$pcause = null;
		$pclabel = null;
		$exists = false;

		if (isset($datum['cause'])){
			$cause = $datum['cause']['value'];
		}
		if (isset($datum['clabel'])){
			$clabel = $datum['clabel'];
		}

		if (isset($datum['pcause'])){
			$pcause = $datum['pcause']['value'];
		}
		if (isset($datum['pclabel'])){
			$pclabel = $datum['pclabel'];
		}


		$generic = false;
		$to = $result;
		$tparent = $parent;
		if (count($siblings) > 1){
			$generic = true;
			$to = $parent;
			$tparent = null;
		}
		if ($currentDepth == ($maxDepth+1)){
			$cause = null;
		}

		addToDic($dic, $parent, $plabel);
		addToDic($dic, $result, $rlabel);
		addToDic($dic, $sibling, $slabel);
		if ($cause != null && $clabel != null){
			// すでに探索済みの場合は検索を止める
			if (isset($tmp_nodes[$cause])){
				$exists = true;
			}

			addToDic($dic, $cause, $clabel);
		}

		if ($pcause != null && $pclabel != null){
			// すでに探索済みの場合は検索を止める
			if (isset($tmp_nodes[$pcause])){
				$exists = true;
			}

			addToDic($dic, $pcause, $pclabel);
		}


		if (!isset($work_nodes[$to])){
			$work_nodes[$to] = ['id'=>$to, 'siblings'=>$siblings, 'parent'=>$tparent];
			$tmp_nodes[$to] = ['id'=>$to];
		}
		if ($cause != null){
			if (isset($tmp_nodes[$cause])){
				$cause = null;
			} else {
				$tmp_nodes[$cause] = ['id'=>$cause];
				if (!isset($work_nodes[$cause])){
					$work_nodes[$cause] = ['id'=>$cause, 'type'=>'route cause', 'siblings'=>array(), 'parent'=>null]; // labelは仮
				} else {
					$work_nodes[$cause]['type'] = 'route cause'; // labelは仮
				}
			}
		}

		if ($pcause != null){
			if (isset($tmp_nodes[$pcause])){
				$pcause = null;
			} else {
				$tmp_nodes[$pcause] = ['id'=>$pcause];
				if (!isset($work_nodes[$pcause])){
					$work_nodes[$pcause] = ['id'=>$pcause, 'type'=>'route cause', 'siblings'=>array(), 'parent'=>null]; // labelは仮
				} else {
					$work_nodes[$pcause]['type'] = 'route cause'; // labelは仮
				}
			}
		}


		$rel_label = $currentDepth;


		if ($generic){
			foreach ($relations as &$relation){
				if ($relation['f'] == $result){

					$relation['f'] = $parent; // 親に繋ぎかえる
				}
			}
			foreach (array_keys($work_nodes) as $key){
				if ($key == $result){
					$work_nodes[$key] = null;
					$work_nodes[$parent]['type'] = 'route cause';

				}
			}
		}


		if ($finding){
			if (isset($datum['finding']) && isset($datum['fl'])){
				$finding = $datum['finding']['value'];

				addToDic($dic, $finding, $datum['fl']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';
				$tmp_nodes[$finding] = ['id'=>$finding];

				$rel = ['f'=>$parent, 't'=>$finding, 'l'=>'has finding'];

				$relations[] = $rel;

			}

			if (isset($datum['finding2']) && isset($datum['fl2'])){
				$finding = $datum['finding2']['value'];

				addToDic($dic, $finding, $datum['fl2']);
				$work_nodes[$finding] = ['id'=>$finding];
				$work_nodes[$finding]['type'] =  'route finding';
				$tmp_nodes[$finding] = ['id'=>$finding];

				if ($generic){
					$rel = ['f'=>$parent, 't'=>$finding, 'l'=>'has finding'];
				} else {
					$rel = ['f'=>$id, 't'=>$finding, 'l'=>'has finding'];
				}
				$relations[] = $rel;
			}

		}

		if ($cause == null && $pcause == null){
			continue;
		}

		// depthに-1が指定されている場合、該当ノードの下にぶら下がる深さを算出する
		if ($currentDepth < 0){
			$d = 0;
			foreach ($relations as $relation){
				if ($relation['f'] == $to){
					if ($d <= $relations['l']){
						$d = ($relation['l']+1);
					}
				}
			}
			$rel_label = $d;
		}

		if ($cause != null){
			$rel = ['f'=>$cause, 't'=>$to, 'l'=>$rel_label];

			$relations[] = $rel;


			if (($maxDepth+1) > $currentDepth && !$exists){
				findGenericCauseFromOnePointRecurse($cause, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding, $islv3);
			}
		}
		if ($pcause != null){
			$rel = ['f'=>$pcause, 't'=>$to, 'l'=>$rel_label];

			$relations[] = $rel;


			if (($maxDepth+1) > $currentDepth && !$exists){
				findCauseFromOnePointRecurse($pcause, $maxDepth, ($currentDepth+1), $work_nodes, $tmp_nodes, $relations, $dic, $finding);
			}
		}
	}

}

/*
function base_finding($id, &$work_nodes, &$relations, &$dic){
	global $const, $http, $lang;
	// 自分に紐づくプロセスを取得してrelationで関連付ける
	$query ="
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?bl ?finding ?fl {
 		<". $id ."> rdfs:subClassOf ?n2;
		 rdfs:label ?bl.
 		?n2 owl:someValuesFrom ?finding;
 		 owl:onProperty <" . $const['DATA_HAS_FINDINGS'] . ">.
 		?finding rdfs:label ?fl.
 		FILTER (lang(?bl) = '" . $lang . "' || lang(?bl) = '')
 		 FILTER (lang(?fl) = '" . $lang . "' || lang(?fl) = '')
	}";

	$data = $http->get($query);
	foreach ($data as $datum){
		$finding = $datum['finding']['value'];

		addToDic($dic, $id, $datum['bl']);
		addToDic($dic, $finding, $datum['fl']);
		$work_nodes[$id] = ['id'=>$id];
		$work_nodes[$id]['type'] = 'route root';
		$work_nodes[$finding] = ['id'=>$finding];
		$work_nodes[$finding]['type'] =  'route finding';

		$relation = ['f'=>$id, 't'=>$finding, 'l'=>'has finding'];
		$relations[] = $relation;
	}
}
*/

if (strpos($find_type,'single') !== false) {
	if ($direction == 'cause'){
		$ret = findCauseFromOnePoint($id, $depth, $finding);
	} else if ($direction == 'result'){
		$ret = findResultFromOnePoint($id, $depth, $finding);
	} else if ($direction == 'both'){
		$ret = findCauseResultFromOnePoint($id, $depth, $finding);
	} else {
		$ret = findCauseFromOnePoint($id, $depth, $finding);
	}
} else {
	if ($direction == 'cause'){
		$ret = findGenericCauseFromOnePoint($id, $depth, $finding, $pid);
	} else if ($direction == 'result'){
		$ret = findGenericResultFromOnePoint($id, $depth, $finding, $pid);
	} else if ($direction == 'both'){
		$ret = findGenericCauseResultFromOnePoint($id, $depth, $finding, $pid);
	} else {
		$ret = findGenericCauseFromOnePoint($id, $depth, $finding, $pid);
	}
}


$ret['result'] = true;
$ret['id'] = $id;

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>