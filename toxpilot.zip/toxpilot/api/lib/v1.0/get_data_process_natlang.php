<?php
// プロセス自然言語取得用

include_once "http_get.php";
include_once "get_util.php";

include_once "get_data_type_lib.php";
include_once "get_data_gene_process_lib.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = false;
//$ret['type'] = "process"; // default
$ret['type'] = get_type($id, $const); // TODO course/process/molecule/role/finding/structure

/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */


// 分子
function get_morecule(&$ret){
	global $const, $http, $id, $lang;

	if ($lang == 'ja'){
		$elm_glue = '，';
	} else {
		$elm_glue = ', ';
	}

	$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?course ?clabel ?cp ?cplabel ?label ?f ?flabel ?ctxlabel ?r ?rlabel {
 {
<" .$id . "> rdfs:subClassOf+ <" . $const['DATA_MOLECULE'] . ">;
 rdfs:label ?label.
 } optional {
?s (rdfs:subClassOf/owl:someValuesFrom)+ <" . $id .">.
?course rdfs:subClassOf ?n.
?n <http://www.w3.org/2002/07/owl#someValuesFrom> ?s.
?course rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
 rdfs:label ?clabel.
?course rdfs:subClassOf ?cp.
?cp rdfs:label ?cplabel.
 } optional {
<" .$id . "> rdfs:subClassOf ?n1.
?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;
 (owl:allValuesFrom | owl:someValuesFrom)/rdfs:label ?ctxlabel.
 } optional {
<" .$id . "> rdfs:subClassOf ?n2.
?n2 owl:onProperty <" . $const['DATA_HAS_ROLE'] .">;
 owl:someValuesFrom ?r.
 ?r rdfs:label ?rlabel.
 } optional {
 {
<" .$id . "> rdfs:subClassOf ?pn.
?pn owl:onProperty <" . $const['DATA_HAS_FAMILY'] . ">;
 owl:someValuesFrom ?f.
 ?f rdfs:label ?flabel.
 } union {
<" .$id . "> rdfs:subClassOf ?parent.
?parent rdfs:subClassOf ?pn.
?pn owl:onProperty <" . $const['DATA_HAS_FAMILY'] . ">;
 owl:someValuesFrom ?f.
 ?f rdfs:label ?flabel.
 }
 }
}";
//echo $query;
	$tmp_molecule = $http->get($query);

	$gene_processes = get_gene_molecule($id, $lang, $const);

//var_dump($gene_processes);

	$detail_type = get_type($id, $const, true);

	$word = null;
	$map = [];
	$cparents = [];
	foreach ($tmp_molecule as $result){
		// データが存在すれば分子
		set_lang($map, 'label', $result['label'], $lang);
		if (array_key_exists('clabel', $result)){
			set_lang($map, 'clabel', $result['clabel'], $lang, $result['course']['value']);
		}
		if (array_key_exists('cplabel', $result)){
			set_lang($map, 'cplabel', $result['cplabel'], $lang, $result['cp']['value']);
			$cparents[$result['course']['value']] = $result['cp']['value'];
		}
		if (array_key_exists('flabel', $result)){
			set_lang($map, 'flabel', $result['flabel'], $lang, $result['f']['value']);
		}
		if (array_key_exists('ctxlabel', $result)){
			set_lang($map, 'ctxlabel', $result['ctxlabel'], $lang);
		}
		/* ロールは現時点では利用しない
		if (array_key_exists('rlabel', $result)){
			set_lang($map, 'rlabel', $result['rlabel'], $lang, $result['r']['value']);
		}*/
		// f,c,rはない場合がある
	}

	/**
	 * {'process': 'parent'}
	 * {'parent': ['course_parent']}
	 */
	foreach ($gene_processes as &$result){
		$result['course_parent'] = [];
		foreach ($result['course'] as $crs){
			if (array_key_exists($crs['id'], $cparents)){
				$pcrs = $cparents[$crs['id']];
				if (!in_array($pcrs, $result['course_parent'])){
					$result['course_parent'][] = $pcrs;
				}
			}
		}
	}
//	var_dump($gene_processes);


	$parents = [];
	$dups = [];
	// TODOプロセスの親が同一のものが存在したとき、かつ、そのプロセスの作用機序の親も一致しているとき、その親同士の関連とする
	foreach ($gene_processes as &$result){
		if (array_key_exists('p', $result)){
			if (!in_array($result['p'], $parents)){
				$parents[] = $result['p'];
			} else {
				// 重複アリデータ
				if (!in_array($result['p'], $dups)){
					$dups[] = $result['p'];
					set_lang($map, 'pplabel', ['xml:lang'=>$lang, 'value'=>$result['pl']], $lang, $result['p']);
				}
			}
		}
	}
//	var_dump($gene_processes);

	// 親の重複を取得して格納する

	foreach ($gene_processes as &$result){
		$cdups = null;
		foreach($gene_processes as $result2){
			if ($result['id'] != $result2['id']){
				if ($result['p'] == $result2['p']){
					if ($cdups == null){
						$cdups = $result['course_parent'];
					}
					$cdups = array_intersect($cdups, $result2['course_parent']);
				}
			}
		}
		$result['dup_parents'] = $cdups;
	}
//	var_dump($dups);


	foreach ($gene_processes as &$result){
		if (array_key_exists('l', $result)){
			set_lang($map, 'plabel', ['xml:lang'=>$lang, 'value'=>$result['l']], $lang, $result['id']);
		}
	}


	if (array_key_exists('label', $map)){
		$label = get_lang($map, 'label');
					$plabel =  get_lang($map, 'plabel', $elm_glue);
					$clabel =  get_lang($map, 'clabel', $elm_glue);
		$flabel =  get_lang($map, 'flabel', $elm_glue);
		$ctxlabel = get_lang($map, 'ctxlabel');
		$rlabel = get_lang($map, 'rlabel', $elm_glue);

		if ($lang == 'ja'){
			$type = '分子';
			if ($detail_type == 'compound'){
				$type = '化合物';
			}
			$glue = '';
			$cap = null;
			if ($flabel != null || $ctxlabel != null || $rlabel != null || $plabel != null){
				$word = "";
				if ($flabel != null){
					$word .= "本エンティティは，" . getBeforeAt($flabel, $lang, $elm_glue)."ファミリーに属する" . $type . "である．";
				}

				if ($clabel != null){
					$word .= "本" . $type . "は";

					// TODO ここからループ
					foreach ($dups as $dup){
						$pcons = null;
						$pcons_label = [];
						foreach ($gene_processes as &$result){
							if ($result['p'] == $dup){
								$pcons = $result['dup_parents'];
//								$pcons_label = [];
								foreach ($pcons as $pcon){
									if (array_key_exists($pcon, $map['cplabel'])){
										$pcons_label[] = $map['cplabel'][$pcon];
									}
								}
								$clabel = implode($elm_glue, $pcons_label);
								break;
							}
						}
						$word .= "作用機序「".getBeforeAt($clabel, $lang, $elm_glue)."」に";
						$word .= "おいて，";
						$word .= "".getBeforeAt($map['pplabel'][$dup], $lang, $elm_glue)."に";
						$word .= "関与しうる．";
					}
						$pmap = [];
					foreach ($gene_processes as &$result){
						if (!in_array($result['p'], $dups)){
							$cons_label = [];
							if ($result['course'] != null && count($result['course']) > 0){
								foreach ($result['course'] as $crs){
									if (array_key_exists($crs['id'], $map['clabel'])){
										$cons_label[] = $map['clabel'][$crs['id']];
									}
								}
								$clabel = implode($elm_glue, $cons_label);
							} else {
								$clabel = getAfterAt($result['l'], $lang);
							}
							if (!array_key_exists($clabel, $pmap)){
								$pmap[$clabel] = [];
							}
							$pmap[$clabel][] = $result['l'];
						}
					}
					foreach ($pmap as $key=> $value){
							$word .= "作用機序「".getBeforeAt($key, $lang, $elm_glue)."」に";
							$word .= "おいて，";
							$word .= "".getBeforeAt(implode($elm_glue, $value), $lang, $elm_glue)."に";
							$word .= "関与しうる．";
					}
//echo $word;

				}

			}
		}else if ($lang == 'en'){
			$type = 'molecule';
			if ($detail_type == 'compound'){
				$type = 'compound';
			}
			$glue = "";
			// 仮
	//		$word = getBeforeDot($label, $lang). "is a family of ". getBeforeAt($flabel, $lang).". It has ". getBeforeAt($clabel, $lang)." as context. It has a role of ".getBeforeAt($rlabel, $lang).".";
/*
			$word = camel(getBeforeDot(getBeforeAt($label, $lang), $lang));
			if ($flabel != null){
				$word .= " is a member of " . getBeforeAt($flabel, $lang) . " family. ";
				$glue = "It";
			}
			if ($rlabel != null){
				$word .= $glue . " has a role of a ".getBeforeAt($rlabel, $lang);
				if ($ctxlabel != null){
					$word .= " in ".getBeforeAt($ctxlabel, $lang). " as a context.";
				} else {
					$word .= ".";
				}
			} else {
				if ($ctxlabel != null){
					$word .= $glue . " is in ".getBeforeAt($ctxlabel, $lang) . " as a context.";
				} else {
					if ($flabel == null){
						$word = null;
					}
				}
			}
*/
			if ($flabel != null || $ctxlabel != null || $rlabel != null){
				$word = "";
				if ($flabel != null){
					$word .= "This entity is a member of " . getBeforeAt($flabel, $lang)." family. ";
				}
				if ($clabel != null){
					$word .= "This " . $type . " can be participated in ";
					if ($plabel != null){
						$word .= getBeforeAt($plabel, $lang, $elm_glue)." ";
						$word .= "in the course of ".getBeforeAt($clabel, $lang, $elm_glue);
						/* ロールは現時点では利用しない
						/*
						if ($rlabel != null){
							$word .= " and can play ".getBeforeAt($rlabel, $lang, $elm_glue).".";
						} else {
							$word .= ".";
						}
						*/
						$word .= ".";
					} else {
						$word .= "a process in the course of ".getBeforeAt($clabel, $lang, $elm_glue).".";
					}
				}
			}


		}
	}

//	echo $word;

	if ($word != null){
		$ret['result'] = true;
//		$ret['type'] = "molecule"; // 分子
		$res = [];
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

		return true;
	}
	return false;
}

// 現状未使用
function get_compound(&$ret){
	global $const, $http, $id, $lang;

	// 化合物
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?parent ?label ?ctxlabel ?rlabel ?def {\n".
	" {\n".
	"<" .$id."> rdfs:subClassOf ?parent;\n".
	" rdfs:subClassOf+ <" . $const['DATA_COMPOUND'] . ">;\n".
	" rdfs:label ?label.\n".
	" } optional {\n".
	" {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:allValuesFrom/rdfs:label ?ctxlabel.\n".
	" } union {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:someValuesFrom/rdfs:label ?ctxlabel.\n".
	" }\n".
	" } optional {\n".
	"<" .$id . "> rdfs:subClassOf ?n2.\n".
	"?n2 owl:onProperty <" . $const['DATA_HAS_ROLE'] .">;\n".
	" owl:someValuesFrom/rdfs:label ?rlabel.\n".
	" } optional {\n".
	" ?parent <". $const['DATA_DEFINITION'] . "> ?def.\n".
	" }\n".
	"}\n";

//	echo $query;

	$tmp_compound = $http->get($query);

	$word = null;
	$map = [];
	$p = null;
	foreach ($tmp_compound as $result){
		// データが存在すれば化合物
		$parent = $result['parent']['value'];

		if (strpos($parent, 'http://purl.obolibrary.org/obo/') !== false){
			$p = $parent;
			// gene
			if (array_key_exists('def', $result)){
				set_lang($map, 'def', $result['def'], $lang);
			}
		}

		set_lang($map, 'label', $result['label'], $lang);
		if (array_key_exists('ctxlabel', $result)){
			set_lang($map, 'clabel', $result['ctxlabel'], $lang);
		}
		if (array_key_exists('rlabel', $result)){
			set_lang($map, 'rlabel', $result['rlabel'], $lang);
		}


		// c,rはない場合がある
	}

	if (array_key_exists('def', $map)){
		// gene
		$label = $map['label'];
		$label = getBeforeAt($label, $lang);
		$label = camel($label);
		$def = $map['def'];
		$def = uncamel($def);
		if ($lang == 'ja'){
			$word = $label."は，".$def;
		}else if ($lang == 'en'){
			$word = $label." is ". $def;
		}


		$ret['result'] = true;
//		$ret['type'] = "compound";

		$res = [];

		//	echo $word;


		//	$res['result'] = true;
		$res['type'] = "description";
		$res['base'] = str_replace("_", ":", str_replace('http://purl.obolibrary.org/obo/', '', $p));
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

	}


	if (array_key_exists('label', $map)){
		$label = $map['label'];
		$clabel = null;
		if (array_key_exists('clabel', $map)){
			$clabel = $map['clabel'];
		}
		$rlabel = null;
		if (array_key_exists('rlabel', $map)){
			$rlabel = $map['rlabel'];
		}
		if ($lang == 'ja'){
			if ( $clabel != null || $rlabel != null){
				$word = getBeforeDot(getBeforeAt($label, $lang), $lang). "は，";
				if ($clabel != null){
					$word .= getBeforeAt($clabel, $lang)."において，";
				}
				if ($rlabel != null){
					$word .= getBeforeAt($rlabel, $lang)."の役割を持つ．";
				}
			}
		}else if ($lang == 'en'){
			$glue = "";
			$word = camel(getBeforeDot(getBeforeAt($label, $lang), $lang));
			if ($rlabel != null){
				$word .= $glue . " has a role of a ".getBeforeAt($rlabel, $lang);
				if ($clabel != null){
					$word .= " in ".getBeforeAt($clabel, $lang). " as a context.";
				} else {
					$word .= ".";
				}
			} else {
				if ($clabel != null){
					$word .= $glue . " is in ".getBeforeAt($clabel, $lang) . " as a context.";
				} else {
					$word = null;
				}
			}
		}
	}

	if ($word != null){
		$ret['result'] = true;
//		$ret['type'] = "compound"; // 化合物
		$res = [];
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

		return true;
	}
	return false;

}



function get_process(&$ret){
	global $const, $http, $id, $lang;
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?course ?clabel ?label ?gparent ?glabel ?parent ?plabel ?def ?dys ?dlabel{\n".
	"<" . $id ."> rdfs:subClassOf ?parent;\n".
	" rdfs:label ?label.\n".
	"?parent rdfs:label ?plabel;\n".
	" rdfs:subClassOf ?gparent.\n".
	"?gparent rdfs:label ?glabel.\n".
	" optional {\n".
	" {\n".
	"?s (rdfs:subClassOf/owl:someValuesFrom)+ <" . $id .">.\n".
	"?course rdfs:subClassOf ?n.\n".
	"?n <http://www.w3.org/2002/07/owl#someValuesFrom> ?s.\n".
	"?course rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;\n".
	" rdfs:label ?clabel.\n".
	" } union {\n".
	"{\n".
	"<" . $id . "> ?p ?o.\n".
	"?o owl:onProperty <" . $const['DATA_HAS_CONTEXT'] . ">;\n".
	"owl:someValuesFrom ?course.\n".
	"} union {\n".
	"<" . $id . "> ?p ?o.\n".
	"?o owl:onProperty <" . $const['DATA_HAS_CONTEXT'] . ">;\n".
	"owl:allValuesFrom ?course.\n".
	"<" . $id . "> ?p2 ?o2.\n".
	"?o2 owl:onProperty <" . $const['DATA_DYSFUNC'] . ">;\n".
	"owl:someValuesFrom ?dys.\n".
	"?dys rdfs:label ?dlabel.\n".
	"FILTER (isBlank(?o2))\n".
	"}\n".
	"?course rdfs:label ?clabel.\n".
	"FILTER (isBlank(?o))\n".
	" }\n".
	" }\n".
	"minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
	"} minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_COMPOUND'] . ">.\n".
	"} minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_MOLECULE'] . ">.\n".
	"}\n".
	"optional {\n".
	" ?parent <". $const['DATA_DEFINITION'] . "> ?def.\n".
	//"FILTER (lang(?def) = '" . $lang . "')\n".
	"}\n".
	"}";

	//echo($query);

	$tmp_process = $http->get($query);
	$word = null;
	$map = [];

	$p = null;
	foreach ($tmp_process as $result){
		$parent = $result['parent']['value'];

		if (strpos($parent, 'http://purl.obolibrary.org/obo/') !== false){
			$p = $parent;
			// gene
			if (array_key_exists('def', $result)){
				set_lang($map, 'def', $result['def'], $lang);
			}
		}

		set_lang($map, 'label', $result['label'], $lang);
		set_lang($map, 'plabel', $result['plabel'], $lang);
		set_lang($map, 'glabel', $result['glabel'], $lang);

		$clabel = null;
		if (array_key_exists('clabel', $result)){
			set_lang($map, 'clabel', $result['clabel'], $lang);
		}

		$dlabel = null;
		if (array_key_exists('dlabel', $result)){
			set_lang($map, 'dlabel', $result['dlabel'], $lang);
		}

	}

	if (array_key_exists('def', $map)){
		// gene
		$label = get_lang($map, 'label');
		$label = getBeforeAt($label, $lang);
		$label = camel($label);
		$def = get_lang($map, 'def');
		$def = uncamel($def);
		if ($lang == 'ja'){
			$word = $label."は，".$def;
		}else if ($lang == 'en'){
			$word = $label." is ". $def;
		}


		$ret['result'] = true;

		$res = [];

//		echo $word;


	//	$res['result'] = true;
//		$ret['type'] = "gene";
		$res['type'] = "description";
		$res['base'] = str_replace("_", ":", str_replace('http://purl.obolibrary.org/obo/', '', $p));
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

	}


	if (array_key_exists('label', $map)){
		$label = get_lang($map, 'label');
		$plabel = get_lang($map, 'plabel');
		$plabel = camel($plabel);
		$glabel = get_lang($map, 'glabel');
		$clabel = get_lang($map, 'clabel');
		if ($clabel != null){
			$clabel = getBeforeAt($clabel, $lang);
		}
		$dlabel = get_lang($map, 'dlabel');
		$word = null;
	//	if (hasAt($label, $lang) && !hasAt($plabel, $lang) && !hasAt($glabel, $lang)) {
		if (hasAt($label, $lang) && !hasAt($plabel, $lang)) {
			$glabel = getBeforeAt($glabel, $lang);
			$plabel = getBeforeAt($label, $lang);
			$plabel = camel($plabel);

			if ($lang == 'ja'){
				$word = $plabel."は，".$glabel."プロセスの一種である．";
			}else if ($lang == 'en'){
				$word = $plabel." is a subtype of ".$glabel.".";
			}
			if ($clabel != null){
				if ($dlabel != null){
					$dlabel = getBeforeAt($dlabel, $lang);
					if ($lang == 'ja'){
						$word .= $clabel."で「".$dlabel."」機能障害が起こる．";
					}else if ($lang == 'en'){
						$word .= " It has ".$clabel." as a context. and is dysfunction of ".$dlabel.".";
					}

				} else {
					if ($lang == 'ja'){
						$word .= $clabel."に関わる．";
					}else if ($lang == 'en'){
						$word .= " It has ".$clabel." as a context.";
					}
				}
			}
		}
	}
	if ($word != null){
		$ret['result'] = true;

	//	echo $word;

		$res = [];

	//	$res['result'] = true;
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;
	//	echo $word;

	}
}
/*
$hit = false;

if (!get_compound($ret)){
	$hit = get_morecule($ret);
} else {
	$hit = true;
}
if (!$hit){
	get_process($ret);
}
*/
if (!get_morecule($ret)){
	get_process($ret);
}


function getBeforeDot($label, $lang){
	$pos = strpos($label, "・");
	if ($pos !== false){
		return substr($label,0, $pos);
	}
	return $label;
}


//var_dump($ret);

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>