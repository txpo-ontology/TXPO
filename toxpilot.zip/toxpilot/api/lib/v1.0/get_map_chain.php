<?php
// 汎用機序マップデータ取得用

ini_set('xdebug.var_display_max_children', -1);
ini_set('xdebug.var_display_max_data', -1);
ini_set('xdebug.var_display_max_depth', -1);

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";
include_once "get_data_gene_course_lib.php";
include_once "get_data_course_lib.php";

//
/*
$lang = 'ja';
$args = ['id'=>'TXPO:TXPO_0000164'];
*/

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	$id  =null;
}

$type_id = null;
if (array_key_exists('type', $args)){
	$type_id = $args['type'];
}
if ($type_id == null || $type_id == ''){
	$type_id = 'rp';
}


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

if ($id != null){
	$id = decode_prefix($id);
}

$target_types = [];

foreach ($type_map as $key => $value){
	if (strpos($type_id, $key) !== false){
		$target_types[] = $value['id'];
	}
}

//$target_types = ['hasResult', 'has_part'];

$http = new Http();


$gene_map = array();
/*
$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
select distinct ?series ?slabel{
?series rdfs:label ?slabel;
 rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.
 FILTER (lang(?slabel) = '" . $lang . "' || lang(?slabel) = '')
} ORDER BY (?series)";



$tmp = $http->get($query);
$tmp_series = array();
foreach($tmp as $series){
	$tmp_series[] = $series['series']['value'];
	// TODO 紐づくlabelは不要？
}

foreach ($tmp_series as $sibling){
	$tmp_processes = get_gene_course($sibling, $lang, $const);

	foreach ($tmp_processes as $process){
		foreach ($process['gene'] as $gene){
			$gene_type = '';
			foreach ($gene['assay'] as $assay){
				if (isset($assay['t'])){
					$gene_type .= $assay['t'].' ';
				}
			}
			$gene_type = trim($gene_type);
			if ($gene_type == ''){
				$gene_type  ="canonical";
			}
			$gene_map[$gene['id']] = $gene_type;
		}
	}
}*/
$tmp_processes = get_gene_course(null, $lang, $const);

foreach ($tmp_processes as $process){
	foreach ($process['gene'] as $gene){
		$gene_type = '';
		foreach ($gene['assay'] as $assay){
			if (isset($assay['t'])){
				$gene_type .= $assay['t'].' ';
			}
		}
		$gene_type = trim($gene_type);
		if ($gene_type == ''){
			$gene_type  ="canonical";
		}
		$gene_map[$gene['id']] = $gene_type;
	}
}



// ノードの重複を削除する
$work_concepts = array();

// まずはid/parent/seriesを抽出

$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?series ?parent ?plabel ?process ?label {
 ?process rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] .">;
  rdfs:label ?label;
  rdfs:subClassOf ?parent.
 ?parent rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">;
  rdfs:label ?plabel.
 FILTER (lang(?label) = '" . $lang . "')
 FILTER (lang(?plabel) = '" . $lang . "')
 FILTER (isIri(?parent))
 optional {
  ?series (rdfs:subClassOf/owl:someValuesFrom)+ ?process;
   rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.

 }
} order by ?process";

$data = $http->get($query);

$tmp_series_map = array(); // id -> series のマップ

foreach ($data as $datum){

	if (isset($datum['series']['value'])){
		$sr = $datum['series']['value'];
	}
	$pid = $datum['process']['value'];
	$parent = $datum['parent']['value'];

	if (!isset($work_concepts[$pid]) || $work_concepts[$pid]['p'] == null){
		$work_concepts[$pid] = ['p'=>$datum['parent']['value'], 'pl'=>$datum['plabel']['value'], 'id'=>$datum['process']['value'], 'l'=>$datum['label']['value']];
	}
	if (!isset($work_concepts[$parent])){
		$work_concepts[$parent] = ['p'=>null, 'pl'=>null, 'id'=>$datum['parent']['value'], 'l'=>$datum['plabel']['value']];
	}

	$tmp_parents = null;
	if (isset($work_parents_map[$parent])){
		$tmp_parents = $work_parents_map[$parent];
	} else {
		$tmp_parents = array();
	}
	if (!in_array($pid, $tmp_parents)){
		$tmp_parents[] = $pid;
	}
	$work_parents_map[$parent] = $tmp_parents;

	if (isset($tmp_series_map[$pid])){
		$tmp_series = $tmp_series_map[$pid];
	} else {
		$tmp_series = array();
	}
	if (isset($sr)){
		if (!in_array($sr, $tmp_series)){
			$tmp_series[] = $sr;
		}

		$tmp_series_map[$pid] = $tmp_series;
	}
}
//var_dump($work_parents_map);

/*
$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?parent ?plabel ?process ?label {
 ?process rdfs:subClassOf+ <" . $const['DATA_PRIMITIVE_PROCESS'] .">;
 rdfs:label ?label;
 rdfs:subClassOf ?parent.
?parent rdfs:label ?plabel.
 {?parent rdfs:subClassOf+ <" . $const['DATA_FUNC_PROCESS'] . ">}
 union {?parent rdfs:subClassOf+ <" . $const['DATA_PHEM_PROCESS'] . ">}
 FILTER (lang(?label) = '" . $lang . "')
 FILTER (lang(?plabel) = '" . $lang . "')
 FILTER (isIri(?parent))
 {
  ?series rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
   (rdfs:subClassOf/owl:someValuesFrom)+ ?tmpp.
  ?tmpp rdfs:subClassOf* ?process.
 }
} order by ?process
";

//echo $query;

$data = $http->get($query);

// 次にid/parentを抽出(seriesに登場しないもの)
foreach ($data as $datum){

	$pid = $datum['process']['value'];
	$parent = $datum['parent']['value'];

	if (!isset($work_concepts[$pid])){
		$work_concepts[$pid] = ['p'=>$datum['parent']['value'], 'pl'=>$datum['plabel']['value'], 'id'=>$datum['process']['value'], 'l'=>$datum['label']['value']];
	}


	$tmp_parents = null;
	if (isset($work_parents_map[$parent])){
		$tmp_parents = $work_parents_map[$parent];
	} else {
		$tmp_parents = array();
	}
	if (!in_array($pid, $tmp_parents)){
		$tmp_parents[] = $pid;
	}
	$work_parents_map[$parent] = $tmp_parents;
}
*/
$loop = true;
while ($loop){
	$loop = false;
	$work_parents_map_new = array();

	$children = array();

	foreach ($work_parents_map as $key => $tmp_parents_map){
		foreach ($tmp_parents_map as $child){
			if (array_key_exists($child, $work_parents_map)){
//				var_dump($child);
				$children[$child] = $key;
			}
		}
	}
	foreach ($work_parents_map as $key => $tmp_parents_map){
		if (array_key_exists($key, $children)){
			continue;
		}
		$work_parents_map_new[$key] = array();
		foreach ($tmp_parents_map as $child){
			if (array_key_exists($child, $children)){
				foreach ($work_parents_map[$child] as $tmp_child){
					$work_parents_map_new[$key][] = $child;
					$work_parents_map_new[$key][] = $tmp_child;
					$loop = true;
				}
			} else {
				$work_parents_map_new[$key][] = $child;
			}
		}
	}

	$work_parents_map = $work_parents_map_new;
}

//var_dump($work_parents_map);


//exit();
// 次にrelationを取得

$types = [];
foreach ($type_map as $tp){
	if (strpos($tp['id'], 'http') !== false){
		$types[] = $tp['id'];
	}
}

$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?process ?rtype ?relation ?rlabel {
?process rdfs:subClassOf+ <" . $const['DATA_PRIMITIVE_PROCESS'] .">;
 rdfs:subClassOf ?n.
 ?n owl:onProperty ?rtype;
  (owl:someValuesFrom | owl:someValuesFrom) ?relation.
 ?n2 owl:someValuesFrom ?process.
 {?n2 owl:onProperty <" . implode(">} union \n {?n2 owl:onProperty <", $types) . ">}
 ?relation rdfs:label ?rlabel.
 FILTER (lang(?rlabel) = '" . $lang . "')
 FILTER (isBlank(?n))
 FILTER (isBlank(?n2))
} order by ?process
";

$data = $http->get($query);



$ret = array();
$ret['concepts'] = array();
$ret['relations'] = array();


// concepts / relations
// conceptsにはid,parent,label情報
// relationsにはfrom-to, label, series情報


$relation_map = array();

//$work_parents_map = array();
//$series_list = array();

// まずはrelationを抽出
foreach ($data as $datum){
	$pid = $datum['process']['value'];

	if (in_array($datum['rtype']['value'], $target_types) && array_key_exists($pid, $tmp_series_map)){

		if (!isset($work_concepts[$datum['relation']['value']])){
			$work_concepts[$datum['relation']['value']] = ['p'=>null, 'pl'=>null, 'id'=>$datum['relation']['value'], 'l'=>$datum['rlabel']['value']];
		}


		foreach ($tmp_series_map[$pid] as $sr){
			$course_parents = get_course_parents($sr, $lang, $const);

			if (array_key_exists($pid, $relation_map)){
				$tmp_relations = $relation_map[$pid];
			} else {
				$tmp_relations = array();
			}
			$tmp_relations[] = ['f'=>$pid, 't'=>$datum['relation']['value'], 'l'=>$const_label[$datum['rtype']['value']], 's'=>$sr, 'ps'=>$course_parents];

			$relation_map[$pid] = $tmp_relations;
		}
	}

}

// コアノードに関連しないrelationsは結果に含めない?
foreach ($relation_map as $key => $relations){
	foreach ($relations as $relation){
		$ret['relations'][] = $relation;
	}
}


foreach ($data as $datum){

	if (!isset($work_concepts[$datum['relation']['value']])){
		$concept = ['p'=>null, 'pl'=>null, 'id'=>$datum['relation']['value'], 'l'=>$datum['rlabel']['value']];
		if (isset($gene_map[$datum['relation']['value']])){
			$concept['t'] = $gene_map[$datum['relation']['value']];
		}
		$work_concepts[$datum['relation']['value']] = $concept;
	}
}

foreach ($work_concepts as $key => $tmp_concept){
	if (isset($gene_map[$key])){
		$tmp_concept['t'] = $gene_map[$key];
		$work_concepts[$key] = $tmp_concept;
	}
}



$ret['concepts'] = array_values($work_concepts);

// 親が存在するノードはまとめてcombineノードとする
$work_nodes = array();

$concepts = $ret['concepts'];
foreach ($concepts as $concept){
	$work_nodes[$concept['id']] = $concept;
}

// relationノードを束ねる
$relations = $ret['relations'];
$new_relations = array();
/*
foreach ($relations as $relation){
	if (isset($work_nodes[$relation['f']])){
		$pr = $work_nodes[$relation['f']]['p'];
		if (isset($work_parents_map[$pr])){
			if (count($work_parents_map[$pr]) > 1){
				$relation['f'] = $pr;
//				$relation['s'] = 'chain'; // TODO 作用機序の配列にしたい
			}
		}
	}
	if (isset($work_nodes[$relation['t']])){
		$pr = $work_nodes[$relation['t']]['p'];
		if (isset($work_parents_map[$pr])){
			if (count($work_parents_map[$pr]) > 1){
				$relation['t'] = $pr;
//				$relation['s'] = 'chain'; // TODO 作用機序の配列にしたい
			}
		}
	}

	$new_relations[] = $relation;
}*/
foreach ($relations as $relation){
	if (isset($work_nodes[$relation['f']])){

		foreach ($work_parents_map as $key=> $work_children){
			if (count($work_children) > 1 && in_array($relation['f'], $work_children)){
				$relation['f'] = $key;
			}
		}
	}
	if (isset($work_nodes[$relation['t']])){
			foreach ($work_parents_map as $key=> $work_children){
			if (count($work_children) > 1 && in_array($relation['t'], $work_children)){
				$relation['t'] = $key;
			}
		}
	}

	$new_relations[] = $relation;
}



// new_relationsをs(作用機序)の昇順にソート
$ids = [];
foreach ($new_relations as $key=>$value){
	$ids[$key] = $value['s'];
}
array_multisort($ids, SORT_ASC, $new_relations);



$ret['relations'] = $new_relations;


//var_dump($work_parents_map);
// conceptを束ねる


$new_concepts = array();
foreach ($concepts as $concept){
	$tmp_concept = $concept;

	if (isset($new_concepts[$tmp_concept['id']])){
		$tmp_concept = $new_concepts[$tmp_concept['id']];
	}

	foreach ($work_parents_map as $key=> $work_children){
		if (count($work_children) > 1 && in_array($concept['id'], $work_children)){
			if (isset($new_concepts[$key])){
				$tmp_concept = $new_concepts[$key];
				$tmp_concept['t'] = 'combine'; // type -> combine
				if (!isset($tmp_concept['c'])){
					$tmp_concept['c'] = array();
				}
			} else {
				$tmp_concept['p'] = null;
				$tmp_concept['id'] = $key;
				if (isset($work_concepts[$key])){
					$tmp_concept['l'] = $work_nodes[$key]['l'];
					if (isset($work_concepts[$work_nodes[$key]['p']])){
						$tmp_concept['p'] = $work_concepts[$work_nodes[$key]]['p']; // parentのさらにparentもあれば格納
						$tmp_concept['pl'] = $work_concepts[$work_nodes[$key]]['pl'];
					}
				}
				$tmp_concept['t'] = 'combine'; // type -> combine
				$tmp_concept['c'] = array();
			}
			$tmp_concept['c'][] = $concept;
		}
	}

	$new_concepts[$tmp_concept['id']] = $tmp_concept;
}

$new_concepts = array_values($new_concepts);

// 関連がどこにもつながっていないノードを削除する
$tmp_concepts = $new_concepts;
$new_concepts = array();
foreach ($tmp_concepts as $datum){
	$s = $datum['id'];
	$hit = false;
	if (isset($datum['c'])){
		// combineであればtrue
		$hit = true;
	} else {
		foreach ($ret['relations'] as $relation){
			if ($relation['f'] == $s || $relation['t'] == $s){
				$hit = true;
				break;
			}
		}
	}
	if ($hit){
		$new_concepts[] = $datum;
	}
}


 $ret['concepts'] = $new_concepts;




header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);

?>