<?php
// ツリーデータ取得用

include "http_get.php";

$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select ?pr ?prl ?s ?l {\n".
"?s rdfs:subClassOf+ <". $const['DATA_FINDING_BASE'].">;\n". // 所見
"rdfs:subClassOf ?pr;\n".
"rdfs:label ?l.\n".
"FILTER (lang(?l) = '". $lang ."')\n".
"FILTER (isBlank(?pr) != true)\n".
"?pr rdfs:label ?prl.\n".
"FILTER (lang(?prl) = '".$lang."')\n".
"} order by ?pr";



header("Content-Type: application/sparql-results+json;charset=UTF-8");
$http = new Http();
echo json_encode($http->get($query));

?>