<?php
// 兄弟概念取得用
// 指定された概念の親概念一覧を取得する

include_once "http_get.php";
include_once "get_util.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = true;
$ret['id'] = $id;
$ret['type'] = ""; // TODO course/process/molecule/finding/structure
/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */

$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"select distinct ?p ?l\n".
"{\n".
" <" . $id . ">  rdfs:subClassOf+ ?p.\n" .
" ?p rdfs:label ?l.\n" .
" minus {?p rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">}\n" .
" FILTER(lang(?l) = '". $lang ."')\n" .
" FILTER(isUri(?p))\n" .
"}";


$parents = $http->get($query);

$ret = array();
$ret['result'] = true;
$ret['type'] = '';
$ret['parents'] = array();

foreach ($parents as $datum){
	$ret['parents'][] = ['id'=>$datum['p']['value'], 'l'=>$datum['l']['value']];
}

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>