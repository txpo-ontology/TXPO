<?php
// プロセスの遺伝子情報取得用

include_once "http_get.php";
include_once "get_util.php";
include_once "get_data_process_course_lib.php";

ini_set('xdebug.var_display_max_depth', -1);



function get_gene_molecule($id, $lang, $const){
	return get_gene_process_relation($id, [$const['DATA_HAS_PARTICIPANT'],$const['DATA_HAS_INPUT'],$const['DATA_HAS_OUTPUT'],$const['DATA_HAS_AGENT']], $lang, $const);
}

function get_gene_role($id, $lang, $const){
	// TODO roleは別途query
	return get_role_process_relation($id, $lang, $const);
}

function get_gene_finding($id, $lang, $const){
	return get_gene_process_relation($id, [$const['DATA_HAS_FINDINGS']], $lang, $const);
}

function get_gene_structure($id, $lang, $const){
	return get_gene_process_relation($id, [$const['DATA_OCCURS_IN']], $lang, $const);
}


function get_gene_process_relation($id, $reltypes, $lang, $const){


	//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

	$id = decode_prefix($id);


	$http = new Http();

	// geneプロセスの取得
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
//	"PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?p ?pl ?id ?l ?gene ?gl ?role ?rl ?assay ?al ?atype ?being ?mtype {\n".


	"?id rdfs:subClassOf+ <" . $const['DATA_PRIMITIVE_PROCESS'] . ">;\n".
	" rdfs:label ?l;\n".
	" rdfs:subClassOf ?p.\n".
	" FILTER (lang(?l) = '" . $lang . "')\n".
	" FILTER (isIri(?p))\n".
	" ?id rdfs:subClassOf ?pn.\n".
//	" ?pn owl:onProperty <" . $reltype . ">;\n".
	" optional {?p rdfs:label ?pl. FILTER(lang(?pl) = '" .$lang . "')}".

	"{ ?pn owl:onProperty <" .
	implode(">.\n} union { ?pn owl:onProperty <" , $reltypes).
	">.}\n".

	" ?pn (owl:someValuesFrom|owl:allValuesFrom) <" .$id .">.\n".
	"?id rdfs:subClassOf ?n.\n".
//	" ?n owl:onProperty <" . $const['DATA_HAS_PARTICIPANT'] . ">;\n".
	"{ ?n owl:onProperty <" .
	implode(">.\n} union { ?n owl:onProperty <" , $reltypes).
	">.}\n".
/*
	" ?n owl:someValuesFrom ?gene.\n".
	"?gene rdfs:label ?gl.\n".
	" FILTER (lang(?gl) = '" . $lang . "' || lang(?gl) = '')\n".
	" FILTER (isBlank(?n))\n".
	"optional {\n".
	"?gene rdfs:subClassOf ?rn.\n".
	"?rn owl:onProperty <" . $const['DATA_HAS_RELATED_ASSAY'] . ">;\n".
	" owl:someValuesFrom ?assay.\n".
	" ?assay rdfs:label ?al.\n".
	" FILTER(lang(?al) = '" . $lang . "' || lang(?al) = '')\n".
	"} optional {\n".
	"?gene rdfs:subClassOf ?rn2.\n".
	"?rn2 owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;\n".
	" owl:someValuesFrom ?role.\n".
	" ?role rdfs:label ?rl.\n".
	" FILTER(lang(?rl) = '" . $lang . "' || lang(?rl) = '')\n".
	"}\n".
	*/
	"?n owl:someValuesFrom ?gene.
	?gene rdfs:subClassOf* <". $const['DATA_COMPOUND'] . ">;
	 rdfs:label ?gl.
	FILTER (lang(?gl) = '" . $lang . "')
	FILTER (isBlank(?n))
	optional {
		?gene rdfs:subClassOf* ?gprnt1.
		?gprnt1 rdfs:subClassOf ?rn1.
		?rn1 owl:onProperty <" . $const['DATA_HAS_RELATED_ASSAY'] . ">;
		(owl:someValuesFrom|owl:allValuesFrom) ?assay.
		?assay rdfs:label ?al.
		FILTER(regex(?al, '^in '))
		FILTER(lang(?al) = '" . $lang . "')
		optional{
			?assay rdfs:subClassOf* <" . $const['DATA_IN_VIVO'] . ">.
			bind('vivo' as ?atype)
		}
		optional{
			?assay rdfs:subClassOf* <" . $const['DATA_IN_VITRO'] . ">.
			bind('vitro' as ?atype)
		}
	}
	optional{
		?gene rdfs:subClassOf* ?gprnt2.
		?gprnt2 rdfs:subClassOf ?rn2.
		?rn2 owl:onProperty <" . $const['DATA_INHERES_IN'] . ">;
			owl:someValuesFrom ?being.
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_MOUSE'] . ">.
			bind('mouse' as ?mtype)
		}
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_RAT'] . ">.
			bind('rat' as ?mtype)
		}
		optional{
			?being rdfs:subClassOf* <" . $const['DATA_ANIMAL_HUMAN'] . ">.
			bind('human' as ?mtype)
		}
	} optional {
		?gene rdfs:subClassOf ?rn4.
		?rn4 owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;
			owl:someValuesFrom ?role.
		?role rdfs:label ?rl.
		FILTER(lang(?rl) = '" . $lang . "')
	}".

	"} order by ?id";

//	echo $query;

	$data = $http->get($query);

	$processes = array();

	$dic = array();

	foreach($data as $datum){
		if (isset($processes[$datum['id']['value']])){
			$process = $processes[$datum['id']['value']];
		} else {
			addToDic($dic, $datum['id']['value'], $datum['l']);
			$process = ['p'=>$datum['p']['value'], 'id'=>$datum['id']['value'], 'gene'=>array()];
			if (isset($datum['pl'])){
				addToDic($dic, $datum['p']['value'], $datum['pl']);
			}
		}
		if (isset($process['gene'][$datum['gene']['value']])){
			$gene = $process['gene'][$datum['gene']['value']];
		} else {
			$gene = ['id'=>$datum['gene']['value'], 'role'=>array(), 'assay'=>array(), 'being'=>array()];
			addToDic($dic, $datum['gene']['value'], $datum['gl']);
		}
		if (isset($datum['role'])){
			if (!in_array(['id'=>$datum['role']['value']], $gene['role'])){
				$gene['role'][] = ['id'=>$datum['role']['value']]; // この時点ではarrayに直で格納？
				addToDic($dic, $datum['role']['value'], $datum['rl']);
			}
		}
		if (isset($datum['assay'])){
			if (!in_array(['id'=>$datum['assay']['value']], $gene['assay'])){
				$gene['assay'][] = ['id'=>$datum['assay']['value']]; // この時点ではarrayに直で格納？
				addToDic($dic, $datum['assay']['value'], $datum['al']);
			}
		}
		if (isset($datum['being'])){
			if (!in_array(['id'=>$datum['being']['value']], $gene['being'])){
				$mt = null;
				if (isset($datum['mtype'])){
					$mt = $datum['mtype'];
				}
				$gene['being'][] = ['id'=>$datum['being']['value'], 't'=>$mt['value']]; // この時点ではarrayに直で格納？
			}
		}

		$process['gene'][$datum['gene']['value']] = $gene;
		$processes[$datum['id']['value']] = $process;


	}


	foreach ($processes as &$process){
		$process['pl'] = $dic[$process['p']];
		$process['l'] = $dic[$process['id']];
		foreach ($process['gene'] as &$gene){
			$gene['l'] = $dic[$gene['id']];

			foreach ($gene['role'] as &$role){
				$role['l'] = $dic[$role['id']];
			}
			foreach ($gene['assay'] as &$assay){
				$assay['l'] = $dic[$assay['id']];
			}
		}
		$courses = get_process_course($process['id'], $lang, $const);
		$process['course'] = $courses;
	}

	return $processes;
}

function get_role_process_relation($id, $lang, $const){


	//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

	$id = decode_prefix($id);

	$reltypes = [$const['DATA_HAS_PARTICIPANT'],$const['DATA_HAS_INPUT'],$const['DATA_HAS_OUTPUT'],$const['DATA_HAS_AGENT']];


	$http = new Http();

	// role関連プロセスの取得
	$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl: <http://www.w3.org/2002/07/owl#>
select distinct ?id ?l ?gene ?gl ?assay ?al {
  {
	?gene rdfs:subClassOf ?rn2;
     rdfs:label ?gl.
	?rn2 owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;
	 owl:someValuesFrom <" . $id . ">.
	 FILTER (lang(?gl) = '" . $lang . "')
	?id rdfs:subClassOf ?n.".
//	?n owl:onProperty <" . $const['DATA_HAS_PARTICIPANT'] . ">;
	"{ ?n owl:onProperty <" .
	implode(">.\n} union { ?n owl:onProperty <" , $reltypes).
	">.}\n".

	"?n owl:someValuesFrom ?gene.
	?id rdfs:label ?l;
	 FILTER (lang(?l) = '" . $lang . "')
	}optional {
	?gene rdfs:subClassOf ?rn.
	?rn owl:onProperty <" . $const['DATA_HAS_RELATED_ASSAY'] . ">;
	 owl:someValuesFrom ?assay.
	 ?assay rdfs:label ?al.
	 FILTER(lang(?al) = '" . $lang . "')
  }
} order by ?id
";
	$data = $http->get($query);

	$processes = array();

	$dic = array();

	foreach($data as $datum){
		if (isset($processes[$datum['id']['value']])){
			$process = $processes[$datum['id']['value']];
		} else {
			addToDic($dic, $datum['id']['value'], $datum['l']);
//			$process = ['p'=>$datum['p']['value'], 'id'=>$datum['id']['value'], 'gene'=>array()];
			$process = ['id'=>$datum['id']['value'], 'gene'=>array()];
		}
		if (isset($process['gene'][$datum['gene']['value']])){
			$gene = $process['gene'][$datum['gene']['value']];
		} else {
			$gene = ['id'=>$datum['gene']['value'], 'assay'=>array()];
			addToDic($dic, $datum['gene']['value'], $datum['gl']);
		}
		if (isset($datum['assay'])){
			if (!in_array(['id'=>$datum['assay']['value']], $gene['assay'])){
				$gene['assay'][] = ['id'=>$datum['assay']['value']]; // この時点ではarrayに直で格納？
				addToDic($dic, $datum['assay']['value'], $datum['al']);
			}
		}
		$process['gene'][$datum['gene']['value']] = $gene;
		$processes[$datum['id']['value']] = $process;


	}


	foreach ($processes as &$process){
		$process['l'] = $dic[$process['id']];
		foreach ($process['gene'] as &$gene){
			$gene['l'] = $dic[$gene['id']];
/*
			foreach ($gene['role'] as &$role){
				$role['l'] = $dic[$role['id']];
			}
			*/
			foreach ($gene['assay'] as &$assay){
				$assay['l'] = $dic[$assay['id']];
			}
		}
		$courses = get_process_course($process['id'], $lang, $const);
		$process['course'] = $courses;
	}
	return $processes;
}


function get_gene_process($id, $lang, $const){


//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);


$http = new Http();

// geneプロセスの取得
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>\n".
//"PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ?gene ?gl ?role ?rl ?assay ?al {\n".
"<" . $id . "> rdfs:subClassOf ?n.\n".
" ?n owl:onProperty <" . $const['DATA_HAS_PARTICIPANT'] . ">;\n".
" owl:someValuesFrom ?gene.\n".
"?gene rdfs:label ?gl.\n".
" FILTER (lang(?gl) = '" . $lang . "')\n".
" FILTER (isBlank(?n))\n".
"optional {\n".
"?gene rdfs:subClassOf ?rn.\n".
"?rn owl:onProperty <" . $const['DATA_HAS_RELATED_ASSAY'] . ">;\n".
" owl:someValuesFrom ?assay.\n".
" ?assay rdfs:label ?al.\n".
" FILTER(lang(?al) = '" . $lang . "')\n".
"} optional {\n".
"?gene rdfs:subClassOf ?rn2.\n".
"?rn2 owl:onProperty <" . $const['DATA_HAS_ROLE'] . ">;\n".
" owl:someValuesFrom ?role.\n".
" ?role rdfs:label ?rl.\n".
" FILTER(lang(?rl) = '" . $lang . "')\n".
"}\n".
"} ";


$data = $http->get($query);

$processes = array();

$dic = array();

foreach($data as $datum){
	if (isset($processes[$id])){
		$process = $processes[$id];
	} else {
		$process = ['gene'=>array()];
	}
	if (isset($process['gene'][$datum['gene']['value']])){
		$gene = $process['gene'][$datum['gene']['value']];
	} else {
		$gene = ['id'=>$datum['gene']['value'], 'role'=>array(), 'assay'=>array()];
		addToDic($dic, $datum['gene']['value'], $datum['gl']);
	}
	if (isset($datum['role'])){
		if (!in_array(['id'=>$datum['role']['value']], $gene['role'])){
			$gene['role'][] = ['id'=>$datum['role']['value']]; // この時点ではarrayに直で格納？
			addToDic($dic, $datum['role']['value'], $datum['rl']);
		}
	}
	if (isset($datum['assay'])){
		if (!in_array(['id'=>$datum['assay']['value']], $gene['assay'])){
			$gene['assay'][] = ['id'=>$datum['assay']['value']]; // この時点ではarrayに直で格納？
			addToDic($dic, $datum['assay']['value'], $datum['al']);
		}
	}
	$process['gene'][$datum['gene']['value']] = $gene;
	$processes[$id] = $process;
}




foreach ($processes as &$process){
	foreach ($process['gene'] as &$gene){
		$gene['l'] = $dic[$gene['id']];

		foreach ($gene['role'] as &$role){
			$role['l'] = $dic[$role['id']];
		}
		foreach ($gene['assay'] as &$assay){
			$assay['l'] = $dic[$assay['id']];
		}
	}
}

return $processes;
}




?>