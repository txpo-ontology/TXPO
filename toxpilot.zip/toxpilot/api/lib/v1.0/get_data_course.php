<?php
// 概念取得用
// 大枠の種別および基本情報を取得したうえで、各情報取得用モジュールに移譲する

include_once "http_get.php";
include_once "get_util.php";

if (array_key_exists('id', $args)){
	$id = $args['id'];
} else {
	// 該当なし
	// TODO エラーを返す
}
$id = decode_prefix($id);

$http = new Http();
$ret = [];
$ret['result'] = false;
$ret['type'] = "";
/*
 * Gene_ontologyの判断基準
 * http://purl.obolibrary.org/obo/
 */


// 分子
function get_morecule(&$ret){
	global $const, $http, $id, $lang;

	if ($lang == 'ja'){
		$elm_glue = '，';
	} else {
		$elm_glue = ', ';
	}

	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?label ?f ?flabel ?ctxlabel ?r ?rlabel {\n".
	" {\n".
	"<" .$id . "> rdfs:subClassOf+ <" . $const['DATA_MOLECULE'] . ">;\n".
	" rdfs:label ?label.\n".
	" } optional {\n".
	" {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:allValuesFrom/rdfs:label ?ctxlabel.\n".
	" } union {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:someValuesFrom/rdfs:label ?ctxlabel.\n".
	" }\n".
	" } optional {\n".
	"<" .$id . "> rdfs:subClassOf ?n2.\n".
	"?n2 owl:onProperty <" . $const['DATA_HAS_ROLE'] .">;\n".
	" owl:someValuesFrom ?r.\n".
	" ?r rdfs:label ?rlabel.\n".
	" } optional {\n".
	" {\n".
	"<" .$id . "> rdfs:subClassOf ?pn.\n".
	"?pn owl:onProperty <" . $const['DATA_HAS_FAMILY'] . ">;\n".
	" owl:someValuesFrom ?f.\n".
	" ?f rdfs:label ?flabel.\n".
	" } union {\n".
	"<" .$id . "> rdfs:subClassOf ?parent.\n".
	"?parent rdfs:subClassOf ?pn.\n".
	"?pn owl:onProperty <" . $const['DATA_HAS_FAMILY'] . ">;\n".
	" owl:someValuesFrom ?f.\n".
	" ?f rdfs:label ?flabel.\n".
	" }\n".
	" }\n".
	"}\n";
//echo $query;
	$tmp_molecule = $http->get($query);

	$word = null;
	$map = [];
	foreach ($tmp_molecule as $result){
		// データが存在すれば分子
		set_lang($map, 'label', $result['label'], $lang);
		if (array_key_exists('flabel', $result)){
			set_lang($map, 'flabel', $result['flabel'], $lang, $result['f']['value']);
		}
		if (array_key_exists('ctxlabel', $result)){
			set_lang($map, 'clabel', $result['ctxlabel'], $lang);
		}
		if (array_key_exists('rlabel', $result)){
			set_lang($map, 'rlabel', $result['rlabel'], $lang, $result['r']['value']);
		}


		// f,c,rはない場合がある
	}

	if (array_key_exists('label', $map)){
		$label = get_lang($map, 'label');
		$flabel =  get_lang($map, 'flabel', $elm_glue);
		$clabel = get_lang($map, 'clabel');
		$rlabel = get_lang($map, 'rlabel', $elm_glue);
		if ($lang == 'ja'){
			$glue = '';
			$cap = null;
			if ($flabel != null || $clabel != null || $rlabel != null){
				$word = getBeforeDot(getBeforeAt($label, $lang), $lang). "は，";
				if ($flabel != null){
					$word .= getBeforeAt($flabel, $lang)."ファミリーに属";
					$glue = "し，";
					$cap = "する．";
				}
				if ($clabel != null){
					$word .= $glue;
					$word .= getBeforeAt($clabel, $lang)."に関わ";
					$glue = "り，";
					$cap = "る．";
				}
				if ($rlabel != null){
					$word .= $glue;
					$word .= getBeforeAt($rlabel, $lang)."の役割を持つ．";
				} else {
					if ($cap == null){
						$word = null;
					} else {
						$word .= $cap;
					}
				}
			}
		}else if ($lang == 'en'){
			$glue = "";
			// 仮
	//		$word = getBeforeDot($label, $lang). "is a family of ". getBeforeAt($flabel, $lang).". It has ". getBeforeAt($clabel, $lang)." as context. It has a role of ".getBeforeAt($rlabel, $lang).".";
			$word = camel(getBeforeDot(getBeforeAt($label, $lang), $lang));
			if ($flabel != null){
				$word .= " is a member of " . getBeforeAt($flabel, $lang) . " family. ";
				$glue = "It";
			}
			if ($rlabel != null){
				$word .= $glue . " has a role of a ".getBeforeAt($rlabel, $lang);
				if ($clabel != null){
					$word .= " in ".getBeforeAt($clabel, $lang). " as a context.";
				} else {
					$word .= ".";
				}
			} else {
				if ($clabel != null){
					$word .= $glue . " is in ".getBeforeAt($clabel, $lang) . " as a context.";
				} else {
					if ($flabel == null){
						$word = null;
					}
				}
			}
		}
	}

//	echo $word;

	if ($word != null){
		$ret['result'] = true;
		$ret['type'] = "molecule"; // 分子
		$res = [];
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

		return true;
	}
	return false;
}

// 現状未使用
function get_compound(&$ret){
	global $const, $http, $id, $lang;

	// 化合物
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?parent ?label ?ctxlabel ?rlabel ?def {\n".
	" {\n".
	"<" .$id."> rdfs:subClassOf ?parent;\n".
	" rdfs:subClassOf+ <" . $const['DATA_COMPOUND'] . ">;\n".
	" rdfs:label ?label.\n".
	" } optional {\n".
	" {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:allValuesFrom/rdfs:label ?ctxlabel.\n".
	" } union {\n".
	"<" .$id . "> rdfs:subClassOf ?n1.\n".
	"?n1 owl:onProperty <" . $const['DATA_HAS_CONTEXT'] .">;\n".
	" owl:someValuesFrom/rdfs:label ?ctxlabel.\n".
	" }\n".
	" } optional {\n".
	"<" .$id . "> rdfs:subClassOf ?n2.\n".
	"?n2 owl:onProperty <" . $const['DATA_HAS_ROLE'] .">;\n".
	" owl:someValuesFrom/rdfs:label ?rlabel.\n".
	" } optional {\n".
	" ?parent <". $const['DATA_DEFINITION'] . "> ?def.\n".
	" }\n".
	"}\n";

//	echo $query;

	$tmp_compound = $http->get($query);

	$word = null;
	$map = [];
	$p = null;
	foreach ($tmp_compound as $result){
		// データが存在すれば化合物
		$parent = $result['parent']['value'];

		if (strpos($parent, 'http://purl.obolibrary.org/obo/') !== false){
			$p = $parent;
			// gene
			if (array_key_exists('def', $result)){
				set_lang($map, 'def', $result['def'], $lang);
			}
		}

		set_lang($map, 'label', $result['label'], $lang);
		if (array_key_exists('ctxlabel', $result)){
			set_lang($map, 'clabel', $result['ctxlabel'], $lang);
		}
		if (array_key_exists('rlabel', $result)){
			set_lang($map, 'rlabel', $result['rlabel'], $lang);
		}


		// c,rはない場合がある
	}

	if (array_key_exists('def', $map)){
		// gene
		$label = $map['label'];
		$label = getBeforeAt($label, $lang);
		$label = camel($label);
		$def = $map['def'];
		$def = uncamel($def);
		if ($lang == 'ja'){
			$word = $label."は，".$def;
		}else if ($lang == 'en'){
			$word = $label." is ". $def;
		}


		$ret['result'] = true;
		$ret['type'] = "compound";

		$res = [];

		//	echo $word;


		//	$res['result'] = true;
		$res['type'] = "description";
		$res['base'] = str_replace("_", ":", str_replace('http://purl.obolibrary.org/obo/', '', $p));
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

	}


	if (array_key_exists('label', $map)){
		$label = $map['label'];
		$clabel = null;
		if (array_key_exists('clabel', $map)){
			$clabel = $map['clabel'];
		}
		$rlabel = null;
		if (array_key_exists('rlabel', $map)){
			$rlabel = $map['rlabel'];
		}
		if ($lang == 'ja'){
			if ( $clabel != null || $rlabel != null){
				$word = getBeforeDot(getBeforeAt($label, $lang), $lang). "は，";
				if ($clabel != null){
					$word .= getBeforeAt($clabel, $lang)."において，";
				}
				if ($rlabel != null){
					$word .= getBeforeAt($rlabel, $lang)."の役割を持つ．";
				}
			}
		}else if ($lang == 'en'){
			$glue = "";
			$word = camel(getBeforeDot(getBeforeAt($label, $lang), $lang));
			if ($rlabel != null){
				$word .= $glue . " has a role of a ".getBeforeAt($rlabel, $lang);
				if ($clabel != null){
					$word .= " in ".getBeforeAt($clabel, $lang). " as a context.";
				} else {
					$word .= ".";
				}
			} else {
				if ($clabel != null){
					$word .= $glue . " is in ".getBeforeAt($clabel, $lang) . " as a context.";
				} else {
					$word = null;
				}
			}
		}
	}

	if ($word != null){
		$ret['result'] = true;
		$ret['type'] = "compound"; // 化合物
		$res = [];
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

		return true;
	}
	return false;

}



function get_process(&$ret){
	global $const, $http, $id, $lang;
	$query =
	"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
	"PREFIX tox:<http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#>\n".
	"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
	"select distinct ?course ?clabel ?label ?gparent ?glabel ?parent ?plabel ?def ?dys ?dlabel{\n".
	"<" . $id ."> rdfs:subClassOf ?parent;\n".
	" rdfs:label ?label.\n".
	"?parent rdfs:label ?plabel;\n".
	" rdfs:subClassOf ?gparent.\n".
	"?gparent rdfs:label ?glabel.\n".
	" optional {\n".
	" {\n".
	"?s (rdfs:subClassOf/owl:someValuesFrom)+ <" . $id .">.\n".
	"?course rdfs:subClassOf ?n.\n".
	"?n <http://www.w3.org/2002/07/owl#someValuesFrom> ?s.\n".
	"?course rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;\n".
	" rdfs:label ?clabel.\n".
	" } union {\n".
	"{\n".
	"<" . $id . "> ?p ?o.\n".
	"?o owl:onProperty <" . $const['DATA_HAS_CONTEXT'] . ">;\n".
	"owl:someValuesFrom ?course.\n".
	"} union {\n".
	"<" . $id . "> ?p ?o.\n".
	"?o owl:onProperty <" . $const['DATA_HAS_CONTEXT'] . ">;\n".
	"owl:allValuesFrom ?course.\n".
	"<" . $id . "> ?p2 ?o2.\n".
	"?o2 owl:onProperty <" . $const['DATA_DYSFUNC'] . ">;\n".
	"owl:someValuesFrom ?dys.\n".
	"?dys rdfs:label ?dlabel.\n".
	"FILTER (isBlank(?o2))\n".
	"}\n".
	"?course rdfs:label ?clabel.\n".
	"FILTER (isBlank(?o))\n".
	" }\n".
	" }\n".
	"minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
	"} minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_COMPOUND'] . ">.\n".
	"} minus {\n".
	" ?parent rdfs:subClassOf+ <" . $const['DATA_MOLECULE'] . ">.\n".
	"}\n".
	"optional {\n".
	" ?parent <". $const['DATA_DEFINITION'] . "> ?def.\n".
	//"FILTER (lang(?def) = '" . $lang . "')\n".
	"}\n".
	"}";

	//echo($query);

	$tmp_process = $http->get($query);
	$word = null;
	$map = [];

	$p = null;
	foreach ($tmp_process as $result){
		$parent = $result['parent']['value'];

		if (strpos($parent, 'http://purl.obolibrary.org/obo/') !== false){
			$p = $parent;
			// gene
			if (array_key_exists('def', $result)){
				set_lang($map, 'def', $result['def'], $lang);
			}
		}

		set_lang($map, 'label', $result['label'], $lang);
		set_lang($map, 'plabel', $result['plabel'], $lang);
		set_lang($map, 'glabel', $result['glabel'], $lang);

		$clabel = null;
		if (array_key_exists('clabel', $result)){
			set_lang($map, 'clabel', $result['clabel'], $lang);
		}

		$dlabel = null;
		if (array_key_exists('dlabel', $result)){
			set_lang($map, 'dlabel', $result['dlabel'], $lang);
		}

	}

	if (array_key_exists('def', $map)){
		// gene
		$label = get_lang($map, 'label');
		$label = getBeforeAt($label, $lang);
		$label = camel($label);
		$def = get_lang($map, 'def');
		$def = uncamel($def);
		if ($lang == 'ja'){
			$word = $label."は，".$def;
		}else if ($lang == 'en'){
			$word = $label." is ". $def;
		}


		$ret['result'] = true;

		$res = [];

//		echo $word;


	//	$res['result'] = true;
		$ret['type'] = "gene";
		$res['type'] = "description";
		$res['base'] = str_replace("_", ":", str_replace('http://purl.obolibrary.org/obo/', '', $p));
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;

	}


	if (array_key_exists('label', $map)){
		$label = get_lang($map, 'label');
		$plabel = get_lang($map, 'plabel');
		$plabel = camel($plabel);
		$glabel = get_lang($map, 'glabel');
		$clabel = get_lang($map, 'clabel');
		if ($clabel != null){
			$clabel = getBeforeAt($clabel, $lang);
		}
		$dlabel = get_lang($map, 'dlabel');
		$word = null;
	//	if (hasAt($label, $lang) && !hasAt($plabel, $lang) && !hasAt($glabel, $lang)) {
		if (hasAt($label, $lang) && !hasAt($plabel, $lang)) {
			$glabel = getBeforeAt($glabel, $lang);
			$plabel = getBeforeAt($label, $lang);
			$plabel = camel($plabel);

			if ($lang == 'ja'){
				$word = $plabel."は，".$glabel."プロセスの一種である．";
			}else if ($lang == 'en'){
				$word = $plabel." is a subtype of ".$glabel.".";
			}
			if ($clabel != null){
				if ($dlabel != null){
					$dlabel = getBeforeAt($dlabel, $lang);
					if ($lang == 'ja'){
						$word .= $clabel."で「".$dlabel."」機能障害が起こる．";
					}else if ($lang == 'en'){
						$word .= " It has ".$clabel." as a context. and is dysfunction of ".$dlabel.".";
					}

				} else {
					if ($lang == 'ja'){
						$word .= $clabel."に関わる．";
					}else if ($lang == 'en'){
						$word .= " It has ".$clabel." as a context.";
					}
				}
			}
		}
	}
	if ($word != null){
		$ret['result'] = true;

	//	echo $word;

		$res = [];

	//	$res['result'] = true;
		$res['type'] = "definition";
		$res['word'] = $word;

		$val = null;
		if (array_key_exists('values', $ret)){
			$val = $ret['values'];
		} else {
			$val = [];
		}
		$val[] = $res;
		$ret['values'] = $val;
	//	echo $word;

	}
}
/*
$hit = false;

if (!get_compound($ret)){
	$hit = get_morecule($ret);
} else {
	$hit = true;
}
if (!$hit){
	get_process($ret);
}
*/
if (!get_morecule($ret)){
	get_process($ret);
}


function getBeforeDot($label, $lang){
	$pos = strpos($label, "・");
	if ($pos !== false){
		return substr($label,0, $pos);
	}
	return $label;
}


//var_dump($ret);

header("Content-Type: application/sparql-results+json;charset=UTF-8");
echo json_encode($ret);


?>