<?php
// PubMed取得用

include_once "http_pubmed.php";
include_once "get_util.php";
include_once "http_get.php";


$ids = [
	$const['BASE_URI'].'/TXPO_0002528', // ERストレス
	$const['BASE_URI'].'/TXPO_0000501', // グルタチオン枯渇
	$const['BASE_URI'].'/TXPO_0001432', // 曇り硝子変性
	$const['BASE_URI'].'/TXPO_0000028', // 好酸性顆粒変性
	$const['BASE_URI'].'/TXPO_0003382', // リン脂質症作用機序
	$const['BASE_URI'].'/TXPO_0001155', // 脂肪化作用機序
	$const['BASE_URI'].'/TXPO_0004280', // 肝発癌（作用機序）
	$const['BASE_URI'].'/TXPO_0003233', // 肝重量増加
	$const['BASE_URI'].'/TXPO_0002329', // 肝線維化（作用機序）
	$const['BASE_URI'].'/TXPO_0000678', // ネクローシス
	$const['BASE_URI'].'/TXPO_0000324', // アポトーシス
	$const['BASE_URI'].'/TXPO_0001986', // ミトコンドリア障害

];
/*
$terms = [
	$const['BASE_URI'].'/TXPO_0002528' => '("endoplasmic reticulum stress"[MeSH Terms] OR "unfolded protein response"[MeSH Terms]) AND "liver"[MeSH Terms] ', // ERストレス
	$const['BASE_URI'].'/TXPO_0000501' => '"glutathione"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms]', // グルタチオン枯渇
	$const['BASE_URI'].'/TXPO_0001432' => ' (ground[All Fields] AND ("glass"[All Fields])) AND "liver"[MeSH Terms] ', // 曇り硝子変性
	$const['BASE_URI'].'/TXPO_0000028' => ' ((peroxisomes[MeSH Terms] AND liver[MeSH Terms])) AND proliferation ', // 好酸性顆粒変性
	$const['BASE_URI'].'/TXPO_0003382' => ' "phospholipidosis"[All Fields] AND "liver"[MeSH Terms] ' , // リン脂質症作用機序
	$const['BASE_URI'].'/TXPO_0001155' => ' "fatty liver"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms] ', // 脂肪化作用機序
	$const['BASE_URI'].'/TXPO_0004280' => '"Carcinogenesis"[MeSH Terms] AND "liver"[MeSH Terms]', // 肝発癌（作用機序）
	$const['BASE_URI'].'/TXPO_0003233' => '"hypertrophy"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms] ', // 肝重量増加
	$const['BASE_URI'].'/TXPO_0002329' => ' "fibrosis"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms]', // 肝線維化（作用機序）
	$const['BASE_URI'].'/TXPO_0000678' => '"necrosis"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms] ', // ネクローシス
	$const['BASE_URI'].'/TXPO_0000324' => ' "apoptosis"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms]', // アポトーシス
	$const['BASE_URI'].'/TXPO_0001986' => '"mitochondria, liver"[MeSH Terms] AND "chemical and drug induced liver injury"[MeSH Terms] ', // ミトコンドリア障害

];
*/
$terms = [
		$const['BASE_URI'].'/TXPO_0002528' => '("er"[All Fields] AND (("stress"[All Fields] OR "stressed"[All Fields]) OR "stresses"[All Fields])) OR ("endoplasmic reticulum stress"[MeSH Terms] OR "unfolded protein response"[MeSH Terms])', // ERストレス
		$const['BASE_URI'].'/TXPO_0000501' => '((((("glutathion"[All Fields] OR "glutathionation"[All Fields]) OR "glutathione"[MeSH Terms]) OR "glutathione"[All Fields]) OR "glutathiones"[All Fields]) OR "glutathions"[All Fields]) AND ((((("deplete"[All Fields] OR "depleted"[All Fields]) OR "depletes"[All Fields]) OR "depleting"[All Fields]) OR "depletion"[All Fields]) OR "depletions"[All Fields])', // グルタチオン枯渇
		$const['BASE_URI'].'/TXPO_0001432' => '(("sER"[All Fields] OR "Endoplasmic Reticulum, Smooth"[MeSH Terms]) AND (((((("proliferate"[All Fields] OR "proliferated"[All Fields]) OR "proliferates"[All Fields]) OR "proliferating"[All Fields]) OR "proliferation"[All Fields]) OR "proliferations"[All Fields]) OR "proliferous"[All Fields])) OR ("phenobarbital"[MeSH Terms] OR "phenobarbital"[All Fields] OR "phenobarbitone"[All Fields]) OR "constitutive androstane receptor"[nm]', // 曇り硝子変性
		$const['BASE_URI'].'/TXPO_0000028' => '(((("peroxisomal"[All Fields] OR "peroxisomally"[All Fields]) OR "peroxisomes"[MeSH Terms]) OR "peroxisomes"[All Fields]) OR "peroxisome"[All Fields]) AND (((((("proliferate"[All Fields] OR "proliferated"[All Fields]) OR "proliferates"[All Fields]) OR "proliferating"[All Fields]) OR "proliferation"[All Fields]) OR "proliferations"[All Fields]) OR "proliferous"[All Fields])', // 好酸性顆粒変性
		$const['BASE_URI'].'/TXPO_0003382' => '("lysosomal storage diseases"[MeSH Terms] OR ("lysosomal"[All Fields] AND "storage"[All Fields])) OR "lysosomal storage diseases"[All Fields]) OR "phospholipidosis"[All Fields]' , // リン脂質症作用機序
		$const['BASE_URI'].'/TXPO_0001155' => '((("fatty liver"[MeSH Terms] OR ("fatty"[All Fields] AND "liver"[All Fields])) OR "fatty liver"[All Fields]) OR "steatosis"[All Fields]) OR (("lipidoses"[MeSH Terms] OR "lipidoses"[All Fields]) OR "lipidosis"[All Fields])', // 脂肪化作用機序
		$const['BASE_URI'].'/TXPO_0004280' => '("carcinogenesis"[MeSH Terms] OR "carcinogenesis"[All Fields] OR "tumorigenesis"[All Fields])', // 肝発癌（作用機序）
		$const['BASE_URI'].'/TXPO_0003233' => '"hypertrophy"[MeSH Terms] OR "hypertrophy"[All Fields] OR "hypertrophied"[All Fields] OR "hypertrophies"[All Fields] OR "hypertrophying"[All Fields]', // 肝重量増加
		$const['BASE_URI'].'/TXPO_0002329' => '"fibrosis"[MeSH Terms] OR "fibrosis"[All Fields]', // 肝線維化（作用機序）
		$const['BASE_URI'].'/TXPO_0000678' => '"necrosis"[MeSH Terms] OR "necrosis"[All Fields', // ネクローシス
		$const['BASE_URI'].'/TXPO_0000324' => '"apoptosis"[MeSH Terms] OR "apoptosis"[All Fields]', // アポトーシス
		$const['BASE_URI'].'/TXPO_0001986' => '((("mitochondrial diseases"[MeSH Terms] OR ("mitochondrial"[All Fields] AND "diseases"[All Fields])) OR "mitochondrial diseases"[All Fields]) OR ("mitochondrial"[All Fields] AND "disorder"[All Fields])) OR "mitochondrial disorder"[All Fields]', // ミトコンドリア障害
];


//$molecule_term = ' AND "chemical and drug induced liver injury"[MeSH Terms] ';


$count_course_query = [
	'narrow_tox' => '({course}) AND "chemical and drug induced liver injury"[MeSH Terms]',
	'narrow_liver' => '({course}) AND "liver"[MeSH Terms]',
];


$count_compound_query = [
	'narrow' => '"{compound}"[Mesh Terms]',
	'narrow_tox' => '"{compound}"[Mesh Terms] AND "chemical and drug induced liver injury"[MeSH Terms]',
	'narrow_liver' => '"{compound}"[Mesh Terms] AND "liver"[MeSH Terms]',
	'broad' => '("{compound}" [MeSH Terms] OR "{compound}"[Supplementary Concept] OR "{compound}" [All Fields]) "{compound}"[All Fields] OR "{compound}"[Supplementary Concept] OR "{compound}"[All Fields]',
	'broad_tox' => '("{compound}" [MeSH Terms] OR "{compound}"[Supplementary Concept] OR "{compound}" [All Fields]) AND ("chemical and drug induced liver injury"[MeSH Terms])',
	'broad_liver' => '("{compound}" [MeSH Terms] OR "{compound}"[Supplementary Concept] OR "{compound}" [All Fields]) AND ("liver"[MeSH Terms])'
];



if (array_key_exists('id', $args)){
	$id = $args['id'];

	if ($id == 'course'){
		// 該当なし
		// course　の一覧を返す
		// courseに紐づくパラメータはAPIだけが知っていれば良い

		header("Content-Type: application/sparql-results+json;charset=UTF-8");

		echo json_encode(get_course_list($ids, $lang));
		exit();
	} else if ($id == 'compound'){
		header("Content-Type: application/sparql-results+json;charset=UTF-8");

		echo json_encode(get_molecules($lang));
		exit();
	}
}

if (array_key_exists('opt', $args)){
	$opt = $args['opt'];
} else {
	// 該当なし
	$opt = "";
}
$opt = urldecode($opt);
$tmps = explode(';', $opt);


//echo($opt);


$opts = [];
foreach ($tmps as $o){
	$tmp = explode('=', $o);
	if (count($tmp) == 2){
		$opts[$tmp[0]] = explode(',', $tmp[1]);
	}
}

$ext = make_option($opts);

if (array_key_exists('term', $opts)){
	$term_type = $opts['term'][0];
} else {
	$term_type = 'narrow_tox';
}
if (!array_key_exists($term_type, $count_compound_query)){
	$term_type = 'narrow_tox';
}


/*
var_dump($opts);
exit();
*/
$id = decode_prefix($id);

$pubmed = new PubMed();

$word = [];
$counts = [];
if (isset($terms[$id])){
	// course
	$type = 'course';
	foreach ($count_course_query as $key => $value){
		$query = str_replace('{course}', $terms[$id], $value); // countのみ
		if (!empty($ext)){
			$query = '(' . $query . ') AND '.$ext;
		}
		$count = $pubmed->get(urlencode($query), 0);
//var_dump($count);
		if (array_key_exists('count', $count)){
			$counts[$key] = $count['count'];
		}
	}

	$query = $count_course_query[$term_type];

	$query = str_replace('{course}', $terms[$id], $query);

} else {
	// compound
	$type = 'compound';
	$compound = get_course($id, '')['value'];

	foreach ($count_compound_query as $key => $value){
		$query = str_replace('{compound}', $compound, $value); // countのみ
		if (!empty($ext)){
			$query = '(' . $query . ') AND '.$ext;
		}

		$count = $pubmed->get(urlencode($query), 0);
		if (array_key_exists('count', $count)){
			$counts[$key] = $count['count'];
		}
	}

//	$query = '"' . $compound . '" [MeSH Terms]'. $molecule_term;
	$query = str_replace('{compound}', $compound, $count_compound_query[$term_type]);

}



if (!empty($ext)){
	$query = '(' . $query . ') AND '.$ext;
}

$data = $pubmed->get(urlencode($query));

$data['opt'] = $opts;
$data['type'] = $type;
$data['id'] = $id;
$data['label'] = get_course($id, $lang);
if (isset($data['label'])){
	$data['label'] = $data['label']['value'];
}

$data['term'] = [];

$data['term']['type'] = $term_type;
if (count($counts) > 0){
	$data['term']['counts'] = $counts;
}

header("Content-Type: application/json;charset=UTF-8");
echo json_encode($data);


function get_course($id, $lang){
	$http = new Http();

	$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select ?l {
<" . $id ."> rdfs:label ?l.
FILTER (lang(?l) = '" . $lang . "')
}
";
	$data = $http->get($query);
	foreach ($data as $datum){
		return $datum['l'];
	}
}


function get_course_list($ids, $lang){
	$http = new Http();
	$ret = [];

	foreach ($ids as $id){
		$ret[$id] = ['s' => ['value'=>$id], 'l'=>get_course($id, $lang)];
	}
	return $ret;
}

function get_molecules($lang){
	global $const;

	$http = new Http();

	$query = "
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select ?s ?l {
 ?s rdfs:subClassOf+ <" . $const['DATA_ORGANIC_MOLECULAR'] .">;
  rdfs:label ?l;
  rdfs:label ?el;
  rdfs:subClassOf ?pr;
  rdfs:subClassOf/owl:someValuesFrom/owl:intersectionOf/rdf:rest/rdf:first/owl:someValuesFrom <" . $const['DATA_MOST_DILI'] .">.
 ?pr rdfs:subClassOf* <" . $const['DATA_ORGANIC_MOLECULAR'] .">;
  rdfs:label ?prl.
 FILTER (isUri(?pr)).
  FILTER  NOT EXISTS {?s rdfs:subClassOf+ <" . $const['DATA_TOX_THING'] .">}
 FILTER (lang(?el) = ''). # 順序取得用
 FILTER (lang(?l) = '" . $lang . "').
 FILTER (lang(?prl) = '" . $lang . "').
} order by LCASE(?el)
";

	return $http->get($query);
}



function make_option($opts){
	$tmps = [];
	if (isset($opts['type'])){
		$tmps_ = [];
		foreach ($opts['type'] as $opt){
			if ($opt == 'clinical'){
				$tmps_[] = 'Clinical Trial[ptyp]';
			}
			if ($opt == 'case'){
				$tmps_[] = 'Case Reports[ptyp]';
			}
		}
		$tmp = implode(" OR ", $tmps_);
		$tmp = '(' . $tmp . ')';
		$tmps[] = $tmp;
	}

	if (isset($opts['species'])){
		$tmps_ = [];
		foreach ($opts['species'] as $opt){
			if ($opt == 'human'){
				$tmps_[] = '"humans" [MeSH Terms]';
			}
		}
		$tmp = implode(" OR ", $tmps_);
		$tmp = '(' . $tmp . ')';
		$tmps[] = $tmp;
	}

	if (count($tmps) > 0){
		$tmps = '(' . implode(" AND ", $tmps) . ')';
	} else {
		$tmps = '';
	}

	return $tmps;
}

?>