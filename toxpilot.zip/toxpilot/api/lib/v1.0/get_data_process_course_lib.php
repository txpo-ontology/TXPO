<?php
// プロセスが所属する作用機序一覧取得用

include_once "http_get.php";
include_once "get_util.php";
include_once "map_data.php";

ini_set('xdebug.var_display_max_depth', -1);


function get_process_course($id, $lang, $const, $addition = null){

	global $except_courses, $type_map;

	$types = [];

	foreach ($type_map as $tp){
		if (strpos($tp['id'], 'http') !== false){
			$types[] = $tp['id'];
		}
	}
	if ($addition != null){
		$types[] = $addition; // TODO これでいいのか？
	}

//$id = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001652'; // for test

$id = decode_prefix($id);


$http = new Http();

// プロセスに紐づく作用機序の取得
/*
$query =
"PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>\n".
"PREFIX owl:<http://www.w3.org/2002/07/owl#>\n".
"select distinct ?cs ?cl{\n".
//"<" . $id . "> rdfs:subClassOf+ <" . $const['DATA_TOX_PROCESS'] . ">.\n".
"?cs rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;\n".
" rdfs:label ?cl;\n".
" (rdfs:subClassOf/owl:someValuesFrom)+ <" . $id . ">.\n".
"FILTER (lang(?cl) = '" .$lang . "' || lang(?cl) = '')\n".
"}";
*/
$query ="
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
PREFIX owl:<http://www.w3.org/2002/07/owl#>
select distinct ?cs ?cl {
 ?cs rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">;
  rdfs:label ?cl;
  rdfs:subClassOf ?n.
 ?n (owl:someValuesFrom/rdfs:subClassOf)* ?n2.
 ?n2 owl:someValuesFrom <" . $id . ">.
 {?n2 owl:onProperty <" . implode(">} union \n {?n2 owl:onProperty <", $types) . ">}
 FILTER (isBlank(?n))
 FILTER (isBlank(?n2))
 FILTER (lang(?cl) = '" . $lang . "')
}";

//echo $query;

$data = $http->get($query);

$courses = array();

$dic = array();

foreach($data as $datum){
	addToDic($dic, $datum['cs']['value'], $datum['cl']);
	$course = ['id'=>$datum['cs']['value']];


	// 関連をたどっていって、作用機序がゴールではない（途中に継承元以外の別の作用機序が存在する）ものは
	// 対象としない
	$query = "
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl:<http://www.w3.org/2002/07/owl#>
	select (count(?stop) as ?count) {
		<" . $course['id']. "> (rdfs:subClassOf/owl:someValuesFrom)* ?p.
		?p (rdfs:subClassOf/owl:someValuesFrom)* <" . $id . ">.
		optional {
			?p rdfs:subClassOf+ <" . $const['DATA_TOX_MECHA'] . ">.
    		FILTER NOT EXISTS {<" . $course['id']. "> rdfs:subClassOf+ ?p.}
			bind ('stop' as ?stop)
		}
	}";
	$tmp = $http->get($query);

	// TODO $except_coursesだけではなく、下位にも存在しないこと
	if (!in_array($course['id'], $except_courses) && $tmp != null && count($tmp) > 0){
		if ($tmp[0]['count']['value'] == '1'){
			$courses[] = $course;
		}
	}
}


foreach ($courses as &$course){

	$course['l'] = $dic[$course['id']];
}

return $courses;
}

/**
 * 概念に関連するプロセスを返す
 * TODO 概念がプロセスの場合、関連する分子・遺伝子を返す
 * @param unknown $id		概念ID
 * @param unknown $lang		言語
 * @param unknown $const	定数
 */
function get_process_relation($id, $lang, $const){
	$id = decode_prefix($id);

	$query = "
	PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#>
	PREFIX owl: <http://www.w3.org/2002/07/owl#>
	select distinct ?process ?l{
		?process rdfs:subClassOf ?n;
		 rdfs:subClassOf+ <". $const['DATA_TOX_PROCESS'] .">;
			rdfs:label ?l.
		?n owl:onProperty ?prop;
		(owl:someValuesFrom|owl:allValuesFrom) <" . $id . ">.
		FILTER (lang(?l) = '" .$lang . "')
	}";

	$http = new Http();
	$data = $http->get($query);

	$processes = array();

	$dic = array();

	foreach($data as $datum){
		addToDic($dic, $datum['process']['value'], $datum['l']);
		$process = ['id'=>$datum['process']['value']];
		$processes[] = $process;
	}

	foreach ($processes as &$process){
		$process['l'] = $dic[$process['id']];
	}

	return $processes;
}


?>