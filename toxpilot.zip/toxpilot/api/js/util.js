/**
 *
 */


function label_get_course(label){
	return label_get_before_at(label)
}


function label_get_before_at(label){
		var pos = label.indexOf("@");
		if (pos >= 0){
			return label.substring(0, pos);
		}
		pos = label.indexOf("＠");
		if (pos >= 0){
			return label.substring(0, pos);
		}
//	} else {
		var arry_result = label.match(/(.*)\[(.*)\]/);
		if (arry_result != null){
			return arry_result[1].trim();
		}
//	}
	return label;
}