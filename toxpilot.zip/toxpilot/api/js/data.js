

/**
 * 作用機序データ処理用API
 */

function Data(endpoint, lang){
	// Create a new directed graph

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

//	// 探索対象とするtypeの一覧 これは外から渡してやる
//	this.targetTypes = [];

	// part表示を逆転させるか
	this.isInverse = false;

//	this.targetTypes = ['hasResult', 'has_part', 'hasParticipant'];
//	this.targetTypes = ['hasParticipant'];
//	this.targetTypes = ['hasResult', 'has_part'];

	// リンク種別ごとの、リンク先が何者かの情報（仮処理）
	this.nodeTypes = {'hasResult':'unknown','has_part': 'part_process', 'hasFindings':'finding', 'hasParticipant':'participant', 'hasAgent':'participant','hasInput':'participant', 'hasOutput':'participant', 'has Pathway':'part_process', 'has_Molecular_reaction':'part_process'};


	this.clear();


}


Data.prototype.clear = function(){
	// 本来このメソッドやこのクリアも不要のはず
	this.data = [];
	this.relations = [];
	this.current = {};
}

Data.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}


Data.prototype.getValidRelationType = function(cb){
	this.api.find("/data/tree/type", function(data){
		cb(data);
	});
}


Data.prototype.findSeries = function(cb){
	this.api.find("/data/tree/course", function(data){
		cb(data);
	});
}

Data.prototype.findWhole = function(cb){
	this.api.find("/data/tree", function(data){
		cb(data);
	});
}

//概念種別を取得する
Data.prototype.findType = function(s, cb){
	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	if (cb != null){
		this.api.find("/data/concept/" + s + "/type", function(data){
			cb(data);
		});
	}
	return this.api.findSync("/data/concept/" + s + "/type");

}



// 指定作用機序が持つ全ノード一覧を取得する
Data.prototype.findNodes = function(s, label, cb, type){
	var self = this;

	if (type == null){
		type = '';
	} else {
		type = '/' + type;
	}

	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	this.api.find("/data/map/course/"+s+type, function(data){
		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});
}


// 概念のアノテーション情報を取得する
Data.prototype.findAnnotation = function(s, cb){
	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	this.api.find("/data/concept/"+s, function(data){

		cb(data);

	});
}



Data.prototype.makeLabel = function(label){
/*
	var tmp = label.split('＠');
	if (tmp.length == 2){
		label = tmp[0];
	}
	tmp = label.split('@');
	if (tmp.length == 2){
		label = tmp[0];
	}
*/
// 一つ目の「＠」で改行
	var index = label.indexOf('＠');
	if (index < 0){
		index = label.indexOf('@');
	}
	if (index >= 0){
		label = label.substring(0, index) + "\n" + label.substring(index);
	}

	return label;
}
