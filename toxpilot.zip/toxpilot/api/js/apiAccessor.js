

function APIAccessor(endpoint, ver, lang){
	this.endpoint = endpoint;
	this.version = ver;
	this.lang = lang;
}

APIAccessor.prototype.getBaseURI = function(){
	return this.endpoint, "/api/v"+this.version+"/"+this.lang;
}

APIAccessor.prototype.find = function(query, cbFunc, args, errFunc, errArgs){

	var qr = sendQuery(this.getBaseURI() + query);

	qr.fail(
		function (xhr, textStatus, thrownError) {
			if (errFunc != null){
				errFunc(errArgs);
			}
			console.log(xhr.responseText);
//			alert("Error: A '" + textStatus+ "' occurred.");
		}
			);
	qr.done(
		function (d) {
			var data = d;

			if (cbFunc != null){
				cbFunc(data, args);
			}
		}
	);


	function sendQuery(e,q,f,t) {
		if (typeof f==="undefined") f="json";
		if (typeof t==="undefined") t=f;
	    var promise;

	    if (window.XDomainRequest) {
	        // special query function for IE. Hiding variables in inner function.
	        // TODO See: https://gist.github.com/1114981 for inspiration.
	        promise = (
				function () {
	    			/*global XDomainRequest */
	    			var qx = $.Deferred(),
	        		xdr = new XDomainRequest(),
	        		url = e +
					"?query=" + q +
					"&output=" + t;
	    			xdr.open("GET", url);
					xdr.onload = function () {
						var data;
	        			if (myEndpointOutput === qfXML) {
							data = $.parseXML(xdr.responseText);
	        			} else {
							data = $.parseJSON(xdr.responseText);
	        			}
	        			qx.resolve(data);
					};
	    			xdr.send();
	    			return qx.promise();
				}()
	        );
	    } else {
	        promise = $.ajax({
//				url: e + "/"+q,
				url: e,
				headers: {
					"Accept": "application/sparql-results+json"
				},
				data: {
//					query: q,
					output: f
				},
				crossDomain: true,
				dataType: t
	        });
	    }
	    return promise;
	}
};

APIAccessor.prototype.findSync = function(query){
	var xmlHttp;

	xmlHttp = new XMLHttpRequest();
	xmlHttp.open("GET", this.getBaseURI() + query, false);
	xmlHttp.send(null);

	return $.parseJSON(xmlHttp.responseText);
};
