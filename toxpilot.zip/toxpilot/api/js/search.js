/**
 *
 */

/**
 * 検索API
 */

function Search(endpoint, lang){
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;
}

/**
 * 所見一覧を取得する
 * @param cb
 */
Search.prototype.findRemarkList = function(cb){
	this.api.find("/search?q[]=tp=remark", function(data){
		cb(data);
	});
}

Search.prototype.find = function(queries, cb, args){
	var query = "q[]=" + queries.join("&q[]=");

	this.api.find("/search?"+query, function(data){
		cb(data, args);
	});
}



Search.prototype.getSuggestFunc = function(type){
	var self = this;
	return function(req, res){
		var query = "/search?q[]=tp=" + type + ",w=" + encodeURIComponent(req.term);
		if ((type == 's' || type == 'r') && req.term == ''){
			query = "/search?q[]=tp=" + type + ",w=&q[]=tp=p,w=";
		}

		$.ajax({
			// ここをどうにかしないと（accessorにする）
	        url: self.api.getBaseURI() + query,
	        dataType: "json",
	        success: function( data ) {
	        	// TODO @以降はヒット対象にしないなどの処理が必要
	        	var list = [];
	        	for (var i in data){
	        		var datum = data[i];
	        		var val = datum[type + 'l'].value;
	        		if (list.indexOf(val) < 0){
	        			list.push(val);
	        		}
	        	}
	            res(list);
	        },
			error: function(xhr, ts, err){
			    res(['']);
			}
		});
	}
}

Search.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}