

/**
 * Aboutデータ処理用API
 */

function About(endpoint, lang){

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

}


About.prototype.getData = function(cb){
	this.api.find("/about", function(data){
		cb(data);
	});
}
