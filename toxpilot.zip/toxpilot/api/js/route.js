

/**
 * 経路データ処理用API
 */

function RouteData(endpoint, lang){
	// Create a new directed graph

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

//	// 探索対象とするtypeの一覧 これは外から渡してやる
//	this.targetTypes = [];


	// part表示を逆転させるか
	this.isInverse = false;

//	this.targetTypes = ['hasResult', 'has_part', 'hasParticipant'];
//	this.targetTypes = ['hasParticipant'];
//	this.targetTypes = ['hasResult', 'has_part'];

	// リンク種別ごとの、リンク先が何者かの情報（仮処理）
	this.nodeTypes = {'hasResult':'unknown','has_part': 'part_process', 'hasFindings':'finding', 'hasParticipant':'participant', 'hasAgent':'participant','hasInput':'participant', 'hasOutput':'participant', 'has Pathway':'part_process', 'has_Molecular_reaction':'part_process'};


	this.clear();


}


RouteData.prototype.clear = function(){
	this.data = [];
	this.relations = [];
	this.current = {};
}

RouteData.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}




RouteData.prototype.findAllProcesses = function(cb){
	this.api.find("/data/tree/process", function(data){
		cb(data);
	});
}

//概念のアノテーション情報を取得する
RouteData.prototype.findAnnotation = function(s, cb){
	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	this.api.find("/data/concept/"+s, function(data){

		cb(data);

	});
}

//概念種別を取得する
RouteData.prototype.findType = function(s, cb){
	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	if (cb != null){
		this.api.find("/data/concept/" + s + "/type", function(data){
			cb(data);
		});
	}
	return this.api.findSync("/data/concept/" + s + "/type");
}

// 指定プロセスから関連する全ノードおよび関連一覧を取得する
RouteData.prototype.findRoute = function(s, cb, find_type, way, depth){
	var self = this;

	if (find_type == null){
		find_type = '';
	} else {
		find_type = '/' + find_type;
	}
	if (way == null){
		way = '';
	} else {
		way = '/' + way;
	}
	if (depth == null){
		depth = '';
	} else {
		depth = '/' + depth;
	}

	s = get_uri(s);

	this.api.find("/data/map/oneroute/"+s+find_type+way+depth, function(data){

		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});

}



//原因方面の探索
RouteData.prototype.findARoute = function(from, to, relations, results, work_route, type){
	if (work_route == null){
		work_route = [];

		this.dic = null;

		if (to == this.data.id){
			// 原因方向への探索
			type = 'cause';
		} else {
			type = 'result';
		}
	}
	if (this.dic == null){
		this.dic = {};
		for (var i in this.data.concepts){
			var concept = this.data.concepts[i];
			this.dic[concept['id']] = concept['l'];
		}
	}

	for (var i in relations){
		var relation = relations[i];
		if (relation.t == relation.f){
			continue;
		}
		if (relation.t == to){
			var tmp_route = work_route.concat();// 渡された配列のコピーを利用する
			tmp_route.push({id:to, label:this.dic[to], type:(to == this.data.id ? 'target' : type)});
			if (relation.f == from){
				tmp_route.push({id:from, label:this.dic[from], type:(from == this.data.id ? 'target' : type)});
				var dup = false;
				for (var j in results){
					// 既存の配列内に同じものがあるか
					// JSON string化したものを比較する
					var tmp = JSON.stringify(results[j]);
					if (tmp == JSON.stringify(tmp_route)){
						dup = true;
						break;
					}
				}
				if (!dup){
					results.push(tmp_route);
				}

				return tmp_route;
			}

			this.findARoute(from, relation.f, relations, results, tmp_route, type);
		}
	}
	return null;
}

RouteData.prototype.findCourses = function(s, cb){
	var self = this;

	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/process/"+s+"/course", function(data){

			cb(data);

		});
	}

	return this.api.findSync("/data/process/"+s+"/course");
}

RouteData.prototype.makeLabel = function(label){
/*
	var tmp = label.split('＠');
	if (tmp.length == 2){
		label = tmp[0];
	}
	tmp = label.split('@');
	if (tmp.length == 2){
		label = tmp[0];
	}
*/
// 一つ目の「＠」で改行
	var index = label.indexOf('＠');
	if (index < 0){
		index = label.indexOf('@');
	}
	if (index >= 0){
		label = label.substring(0, index) + "\n" + label.substring(index);
	}

	return label;
}
