/**
 * コマンドオブジェクト
 */

function Command(func, params){
	this.func = func;
	this.params = params;

}

Command.prototype.exec = function(event){
	event.originalEvent.state;
}


function CommandHandler(){

	var self = this;
	this.cmdList = [];
	this.cmdPointer = 0;
	this.seed = Date.now();

	this.funcsMap = {};
	$(window).bind('popstate', function(event){
		/*
		var cmd = event.originalEvent.state;

		if (cmd.func != null){
			var type = cmd.func.split('.');
			var func = type[1];
			type = type[0];

			var func = self.funcsMap[type][func];
			var redo = func.redo;
			var undo = func.undo;
		}
		*/
		var cmd = self.cmdList[self.cmdPointer-1];

		var dir = null;
		if (event.originalEvent.state.seed != self.seed){

			if (self.cmdPointer == 1){
				//
				self.cmdPointer --;
				dir = "undo";
			} else {
				return ;
			}
		} else

		if (event.originalEvent.state.index >= self.cmdPointer){
			// forward
			console.log("forward");
			if (self.cmdPointer < (self.cmdList.length)){
				self.cmdPointer ++;
			}
			dir = "redo";
			cmd = self.cmdList[self.cmdPointer-1];
		} else {
			// back
			console.log("back");
			if (self.cmdPointer > 1){
				self.cmdPointer --;
			}
			dir = "undo";
		}
		if (dir == null){
			return;
		}


		if (cmd.func != null){
			var type = cmd.func.split('.');
			var func = type[1];
			type = type[0];

			var func = self.funcsMap[type][func];
			var redo = func.redo;
			var undo = func.undo;

			if (dir == "redo"){
				redo(cmd.params);
			} else {
				undo(cmd.params);
			}
		}

	});
/*
	for (var i=0; i<50; i++){ // clear history
		history.pushState({},'');
	}
	*/
}

CommandHandler.prototype.push = function(cmd){
	history.pushState({index:this.cmdPointer,seed:this.seed}, null, null);

	// cmdListのサイズがcmdPointerを超えた場合はそれ以降を削除
	if (this.cmdPointer < this.cmdList.length){
		this.cmdList.splice(this.cmdPointer, this.cmdList.length-this.cmdPointer);
	}

	this.cmdList.push(cmd);
	this.cmdPointer++;

}

CommandHandler.prototype.addHandler = function(type, funcsMap){
	if (this.funcsMap[type] == null){
		this.funcsMap[type] = funcsMap;
	} else {
		this.funcsMap[type] = Object.assign(this.funcsMap[type], funcsMap);
	}
}