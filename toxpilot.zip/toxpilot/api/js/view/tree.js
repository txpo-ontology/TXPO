/**
 *
 */



function Tree(div){
	this.div= div[0];
	this.setLang('ja');

	this.init();
}

Tree.prototype.setLang = function(lang){
	this.lang = lang;
}


Tree.prototype.init = function(){
	var ts = this.div;
	var self = this;
	$(ts).addClass('dialog');

	$(ts).append(
					$('<DIV></DIV>')
					.attr({
						'id' : ts.id + "_contents",
						'class' : 'dialog_content'
					})
		);
	$('#'+ ts.id + '_contents').append(
			$('<div></DIV>')
			.attr({
				'id' : ts.id + "_find"
			}).append(
					$('<input>')
					.attr({
						'type' : 'text',
						'id' : ts.id + "_find_word",
						'class' : 'uiparts_theme textbox find_word'
					})
					)
				);
	$('#'+ ts.id + '_find_word').keypress(function(event){
		if( event.which === 13 ){
//			ts.findWord($("#" + ts.id + "_find_word").val());
			self.findWord($("#" + ts.id + "_find_word").val());
		}
	});

	$('#'+ ts.id + '_find').append(
			$('<input>')
			.attr({
				'type' : "button",
				'value' : "△",
				'class' : "uiparts_theme next_prev_button tree_find_prev",
				'id' : ts.id + "_find_prev"

			})
			);
	$('#'+ ts.id + '_find .tree_find_prev').click(function(event){
		setClassToNode(highlightedIds[selectedIndex], 'select', false);
		self.focusHighlight(--selectedIndex);
	});

	$('#'+ ts.id + '_find').append(
			$('<input>')
			.attr({
				'type' : "button",
				'value' : "▽",
				'class' : "uiparts_theme next_prev_button tree_find_next",
				'id' : ts.id + "_find_next"
			})
			);
	$('#'+ ts.id + '_find .tree_find_next').click(function(event){
		setClassToNode(highlightedIds[selectedIndex], 'select', false);

		self.focusHighlight(++selectedIndex);
	});

	$('#'+ ts.id + '_contents').append(
			$('<div></DIV>')
			.attr({
				'id' : ts.id + "_main",
				'class' :"tree"
			})
		);

	$('#'+ ts.id + '_find .tree_find_prev').attr('disabled', 'disabled');
	$('#'+ ts.id + '_find .tree_find_prev').attr('disabled', 'disabled');

}

Tree.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
}



Tree.prototype.setTreeData = function(result, clear){
	var current = null;
	var ts = this.div;
	current = this.current_id;

	this.treeData = new TreeData(ts.id);
	var tree = this.treeData;
//	var base = DATA_TOX_MECHA;//'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000009';

	for (var i in result){
		var datum = result[i];

		var id = datum.s.value;
		var label = datum.l.value;
		var updateLabel = false;
		if (datum.l['xml:lang'] != null && datum.l['xml:lang'] == this.lang){
			updateLabel = true;
		}
		var pid = datum.pr.value;
		var plabel = datum.prl.value;
		var pupdateLabel = false;
		if (datum.prl['xml:lang'] != null && datum.prl['xml:lang'] == this.lang){
			pupdateLabel = true;
		}

		tree.addSubClass(tree.getNodeID(plabel, pid, true, pupdateLabel), tree.getNodeID(label, id, true, updateLabel), pupdateLabel, updateLabel);


		if (datum.os != null && datum.pl != null){
			var ppid = datum.os.value;// + "_part";
			var pplabel = datum.pl.value;
			var ppupdateLabel = false;
			if (datum.pl['xml:lang'] != null && datum.pl['xml:lang'] == this.lang){
				ppupdateLabel = true;
			}
			tree.addSubClass(tree.getNodeID(label, id, true), tree.getNodeID(pplabel, ppid, true, ppupdateLabel, 'part'), false, ppupdateLabel, 'part');
		}

	}
	tree.setRoot();
	this.setCurrent(current);

	if (clear){
		$('#'+ ts.id + '_find_word').val('');
	}
//	this.treeData = data;
	viewTree(ts.id + "_main", tree, this.cbFunc);
	if (current != null){
		// TODO treeID->nodeIDに変換
		this.findID(current);
	}

}

Tree.prototype.findWord = function(word){
	var ts = this.div;
	selectedIndex = 0;

	// TODO selectもいったんクリア
//	clearClassNode(ts.id + "_main", "select");
	clearClassNode(ts.id + "_main", "highlight");

	if (word == ''){
		this.clearHighlight();

		// next, prevもクリア
//		viewTree(ts.id + "_main", this.treeData, cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	word = word.toLowerCase();

	highlightedIds = recurseFind(word, highlightedIds, this.treeData.rootNode, nodes);



	function recurseFind(word, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if ((node.name.toLowerCase()).indexOf(word) >= 0){
			var expects = ['@', '＠'];
			var hit = true;
			for (var i in expects){
				if ((node.name).indexOf(expects[i]) >= 0 && (node.name).indexOf(expects[i]) < (node.name).indexOf(word)){
					hit = false;
					break;
				}
			}
			if (hit){
				if (ids.indexOf(node.id) < 0){
					ids.push(node.id);
				}
			}
		} else
		// TODO name以外のSlot情報でもヒット対象とする
		if (this.metadata != null){
			if (this.metadata[node.resource] != null){
				//
				var slots = this.metadata[node.resource].slots;
				if (slots != null){
					slots = JSON.stringify(slots);
					if ((slots.toLowerCase()).indexOf(word) >= 0){
						if (ids.indexOf(node.id) < 0){
							ids.push(node.id);
						}
					}
				}
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(word, ids, node.children[i], nodes);
		}
		return ids;

	};

	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
}


Tree.prototype.findID = function(id, clear){
	var ts = this.div;
	selectedIndex = 0;
	if (clear == null){
		clear = true;
	}
	if (clear){
		this.clearHighlight();
	}
	if (id == ''){
		viewTree(ts.id + "_main", this.treeData, cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	if (this.treeData == null){
		return;
	}

	highlightedIds = recurseFind(id, highlightedIds, this.treeData.rootNode, nodes);

	clearClassNode(ts.id + "_main", "select");

	function recurseFind(id, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if (node.resource == id){
			if (ids.indexOf(node.id) < 0){
				ids.push(node.id);
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(id, ids, node.children[i], nodes);
		}
		return ids;

	};

//	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
	return highlightedIds;
}


Tree.prototype.focusHighlight = function(index){
	var ts = this.div;
	if (index == 0){
		$('#' + ts.id + ' .tree_find_prev').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .tree_find_prev').removeAttr('disabled');
	}

	if (index == (highlightedIds.length-1)){
		$('#' + ts.id + ' .tree_find_next').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .tree_find_next').removeAttr('disabled');
	}

	this.focusNode(highlightedIds[selectedIndex]);

	setClassToNode(highlightedIds[selectedIndex], 'select');

}

Tree.prototype.highlight = function(id, isHighlight){
	var ts = this.div;
	this.clearHighlight();
	var ids = [];
	if (id instanceof Array){
		ids = id;
	} else {
		ids.push(id);
	}

	if (this.treeData != null){
		for (var i=0; i<ids.length; i++){
			this.treeData.highlight(ids[i], isHighlight);
		}
	}

	// TODO
	for (var i=0; i<ids.length; i++){
		var hl = ids[i];

		setClassToNode(hl, 'highlight');

		openNode(ts.id + "_main", this.treeData, hl);

	}
//	viewTree(ts.id + "_main", this.treeData, this.cbFunc);


}

Tree.prototype.clearHighlight = function(){
	if (this.treeData != null){
		this.treeData.highlightClear();
	}
}

Tree.prototype.focusNode = function(id){
	var ts = this.div;
	$('#' + ts.id + '_main').animate({
//		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - 400)
		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - ($('#' + ts.id + '_main').position().top + 150))
	});
	if (this.highlightCb != null){ // this?
		this.highlightCb(id);
	}
}

Tree.prototype.getNodeData = function(id){
	if (this.treeData != null && this.treeData.treeData != null){
		return this.treeData.treeData[id];
	}
	return null;
}

Tree.prototype.setCurrent = function(id){
	this.current_id = id;
}

Tree.prototype.getCurrent = function(){
	return this.current_id;
}

Tree.prototype.onFocusHighlighted = function(cb){
	this.highlightCb = cb;
}

Tree.prototype.openAll = function(isOpen){
	if (this.treeData != null){
		this.treeData.openAll(isOpen);
	}

	var ts = this.div;
	// TODO これいる？
	viewTree(ts.id + "_main", this.treeData, null);


}

Tree.prototype.setMetadata = function(data){
	this.metadata = data;
}


Tree.prototype.setContextMenu = function(context){
	var ts = this.div;
	var sampleElement = $('#' + ts.id+ ' .treeview li span');
	context.element = sampleElement;
	var contextMenuObj = new ContextMenu(context);
}
