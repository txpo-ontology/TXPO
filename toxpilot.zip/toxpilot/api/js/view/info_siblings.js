/**
 * 兄弟概念情報表示API
 */

function InfoSiblings(div, lang, options){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;
	this.options = options;

	this.strings();

	this.init();

}

InfoSiblings.prototype.init = function(){
	var ts = this.div;


	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_siblings',
				'class' : "result_panel chains_list"
			}));


}



InfoSiblings.prototype.show = function(data){
	var ts = this.div;


	// head
	var contents = '';
	// head はlabelとdefinition
	for (var i in data.siblings){
		var datum = data.siblings[i];

		var courses = data.courses[datum.id];
		var cparents = data.cparents[datum.id];
		var relations = data.relations[datum.id];
		var causes = relations.cause;
		var results = relations.result;

		var course_index = -1;
		var clazz = '';
		if (this.options != null && this.options.color_map != null){
			for (var j in courses){
				var course = courses[j];
				course_index = this.options.color_map.indexOf(course.id);
				if (course_index >= 0){
					course_index = course_index % 10;
					clazz = 'under_color_f'+ course_index;
					break;
				}
			}
			if (course_index < 0){
//				for (var j in cparents){
				for (var j=cparents.length-1; j>=0; j--){
					var course = cparents[j];
					course_index = this.options.color_map.indexOf(course);
					if (course_index >= 0){
						course_index = course_index % 10;
						clazz = 'under_color_f'+ course_index;
						break;
					}
				}
			}
		}

		if (clazz == ''){
//			for (var j in courses){
			for (var j=courses.length-1; j>=0; j--){
				var course = courses[j];
				course_index = data.courses_list.indexOf(course.id);
				if (course_index >= 0){
					course_index = course_index % 10;
					clazz = 'under_color_'+ course_index;
					break;
				}
			}
		}
		if (clazz == ''){
			// 該当なしの場合表示しないようにしておく（仮処理）
			continue;
		}

		contents += '<h3 class="'+clazz+'">\n';
		contents += "<span>"+datum.l + "</span>";
		contents += '<span class="hide">' + datum.id + "</span></h3>\n";
		contents += "<ul>\n";
		contents += "<li>Causes\n";
		contents += " <ul>\n";
		if (causes.length > 0){
			for (var j in causes){
				var cause = causes[j];
				contents += "<li><span>" + cause.l + '</span><span class="hide">' + cause.id + '</span></li>\n';
			}
		} else {
			contents += '<li><span class="text_info_sibling_none"></span></li>\n';
		}
		contents += " </ul>\n";
		contents += "</li>\n";

		contents += "<li>Results\n";
		contents += " <ul>\n";
		if (results.length > 0){
			for (var j in results){
				var result = results[j];
				contents += "<li><span>" + result.l + '</span><span class="hide">' + result.id + '</span></li>\n';
			}
		} else {
			contents += '<li><span class="text_info_sibling_none"></span></li>\n';
		}
		contents += " </ul>\n";
		contents += "</li>\n";
		contents += "</ul>\n";
	}

	$('#' + ts.id + '_info_siblings').html(contents);


	this.setLang(this.lang);

}

InfoSiblings.prototype.setLang = function(lang){
	this.lang = lang;

	for(var key in this.consts[lang]){
		$('.text_info_sibling_'+key).text(this.consts[lang][key]);
	}
}

InfoSiblings.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'none': 'なし'};
	this.consts['en'] = {
			'none': 'None'};
}

