/**
 * 経路マップ表示API
 * 利用のためには別途描画ライブラリをインポートする必要がある
 */

function RouteMap(div, options, initials){

	this.div = div[0];
	this.options = {
			'props':{'c':'Upstream', 'r':'Downstream'},
			'min_depth': 1,
			'max_depth': 7,
			'direction': 'LR',
			'color_map': null
			};
	if (options != null){
		/*
		for (var key in options){
			this.options[key] = options[key];
		}
		*/
		this.options = Object.assign(this.options, options);

	}
	this.initials = {
			'props':'cr',
			'depth':5,
		};

	if (initials != null){
		this.initials = Object.assign(this.initials, initials);
	}
	this.init();

}

RouteMap.prototype.init = function(){
	var ts = this.div;
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_control_panel",
				'class' : "map_control_panel"
			}));
	$("#"+ts.id + " .map_control_panel").append(
		$('<DIV></DIV>')
		.attr({
			'class' : "map_props"
		})
	);

	var types = '<select name="type" class="uiparts_theme common_button">';
	types += '<option selected value="single">Single</option>';
	types += '<option value="generic">General</option>';
	types += '</select> | ';

	$("#"+ts.id + " .map_control_panel .map_props").append(types);


	for(var o in this.options.props){
		$("#"+ts.id + " .map_control_panel .map_props").append(
				('<INPUT type="checkbox" name="view_type" value="' + o +'">' + this.options.props[o] + ' ')
		);
	}

	var steps = ' | Steps <select name="step" class="uiparts_theme common_button">';
	for (var i=this.options.min_depth; i<=this.options.max_depth; i++){
		if (i == this.initials.depth){
			steps += '<option selected>' + i + '</option>';
		} else {
			steps += '<option>' + i + '</option>';
		}
	}
	steps += '</select>';
	$("#"+ts.id + " .map_control_panel .map_props").append(steps);

	$("#"+ts.id + " .map_control_panel").append("<input type=\"checkbox\" name=\"fullscreen\"> Full screen")


	var self = this;

	$("#"+ts.id + " .map_control_panel .map_props input[name=view_type]").each(function(index, c){
		if (self.initials.props.indexOf($(c).val()) >= 0){
			$(c).attr('checked','checked');
		}
	});



	// TODO option変更イベント
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=view_type]", 'click', function(event){
//		update_viewtype();
		if (self.updateCB != null){
			self.updateCB();
		}
	});

	$("#"+ts.id + " .map_control_panel .map_props select").change(function(event){
		if (self.updateCB != null){
			self.updateCB();
		}
	});

	$(document).delegate("#"+ts.id + " .map_control_panel input[name=fullscreen]", 'click', function(event){
//		$("#"+ts.id).toggleClass('fullscreen');
		if (self.updateCB != null){
			var div = $("#"+ts.id);
			var val = $("#"+ts.id + " .map_control_panel input[name=fullscreen]").prop('checked');

			self.updateCB('fullscreen', [val, div]); // TODO
		}
	});


	$("#"+ts.id + " .map_control_panel").append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_find_panel",
				'class' : "map_find_panel"
			})
			.append("<input type=\"text\" name=\"findtext\" class=\"uiparts_theme textbox findtext\">" +	/* mod maeda 見栄え改善 */
					"<input type=\"button\" value=\"FIND\" name=\"find\" class=\"uiparts_theme common_button find\">" +
					"<input type=\"button\" value=\"△\" name=\"prev\" class=\"uiparts_theme next_prev_button prev\">" +
					"<input type=\"button\" value=\"▽\" name=\"next\" class=\"uiparts_theme next_prev_button next\">")
					);
	// 検索処理
	var findProc = function(){
		var findText = $("#"+ts.id + " .map_control_panel input[name=findtext]").val();
		// 同じ検索語でなければ検索をする
		if( this.nowFindText != findText ){
			self.view.clearHighlight();
			self.view.find( findText );
			this.nowFindText = findText;
		}
		// 同じ検索語であれば次に進める
		else {
			self.view.find_highlight(true);
		}
	}



	// 検索処理イベント
	$("#"+ts.id + " .map_control_panel input[name=find]").click(function(event){
		findProc();
	});
	// テキストボックスでエンターキーを押した時も同様に検索処理イベントを動かす
	$("#"+ts.id + " .map_control_panel input[name=findtext]").keypress(function(event){
		if( event.which === 13 ){
			findProc();
		}
	});
	$("#"+ts.id + " .map_control_panel input[name=prev]").click(function(event){
		self.view.find_highlight(false);
	});
	$("#"+ts.id + " .map_control_panel input[name=next]").click(function(event){
		self.view.find_highlight(true);
	});


//	$("#"+ts.id + " .map_main_panel").append('<svg id="' + ts.id + '_canvas" width=1500 height=1000></svg>');
	$(ts).append('<svg id="' + ts.id + '_canvas" width=1500 height=1000></svg>');
	// safariでイベントを受け取れるようフルサイズrectを背景とする
	$("#"+ts.id + "_canvas").append(
			$('<RECT></RECT>')
			.attr({
				'width' : '100%',
				'height' : '100%',
				'fill' : '#fff',
				'pointer-events' : 'all'
			}));
	this.view = new Draw(ts.id + "_canvas", this.options.direction, this.options.color_map);

}

RouteMap.prototype.setUpdateHandler = function(func){
	this.updateCB = func;
}


RouteMap.prototype.getRelationType = function(){
	var ts = this.div;
	var dir = '';
	$("#"+ts.id + " .map_control_panel .map_props input[name=view_type]:checked").each(function(){
		dir += $(this).val();
	});
	var type = $('#'+ ts.id + ' .map_control_panel .map_props select[name=type]').val();
	var depth = $('#'+ ts.id + ' .map_control_panel .map_props select[name=step]').val();


	return {'type':type, 'depth':depth, 'direction':dir};
}

RouteMap.prototype.setType = function(type){
	var ts = this.div;
	$('#'+ ts.id + ' .map_control_panel .map_props select[name=type]').val(type);
}

RouteMap.prototype.setDepth = function(depth){
	var ts = this.div;
	$('#'+ ts.id + ' .map_control_panel .map_props select[name=step]').val(depth);
}


RouteMap.prototype.setMapData = function(data, clear){
	var ts = this.div;
	if (clear){
		$('#'+ ts.id + ' .map__find_panel input[type=text]').val('');
	}

	this.mapData = data;
	this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);
}

RouteMap.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
}


RouteMap.prototype.findWord = function(word){
	var ts = this.div;
	selectedIndex = 0;
	if (word == ''){
		this.clearHighlight();
		this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	highlightedIds = recurseFind(word, highlightedIds, this.mapData.rootNode, nodes);

	function recurseFind(word, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if ((node.name).indexOf(word) >= 0){
			var expects = ['@', '＠'];
			var hit = true;
			for (var i in expects){
				if ((node.name).indexOf(expects[i]) >= 0 && (node.name).indexOf(expects[i]) < (node.name).indexOf(word)){
					hit = false;
					break;
				}
			}
			if (hit){
				if (ids.indexOf(node.id) < 0){
					ids.push(node.id);
				}
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(word, ids, node.children[i], nodes);
		}
		return ids;

	};

	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
}

RouteMap.prototype.findID = function(id){
	this.view.find(id);
	/*
	var ts = this.div;
	selectedIndex = 0;
	this.clearHighlight();
	if (id == ''){
		this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	highlightedIds = recurseFind(id, highlightedIds, this.mapData.rootNode, nodes);

	function recurseFind(id, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if (node.resource == id){
			if (ids.indexOf(node.id) < 0){
				ids.push(node.id);
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(id, ids, node.children[i], nodes);
		}
		return ids;

	};

	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
	*/
}

RouteMap.prototype.focusHighlight = function(index){
	var ts = this.div;
	if (index == 0){
		$('#' + ts.id + ' .map_find_panel input[name=prev]').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .map_find_panel input[name=prev]').removeAttr('disabled');
	}

	if (index == (highlightedIds.length-1)){
		$('#' + ts.id + ' .map_find_panel input[name=next]').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .map_find_panel input[name=next]').removeAttr('disabled');
	}

	this.focusNode(highlightedIds[selectedIndex]);

	setClassToNode(highlightedIds[selectedIndex], 'select');

}

RouteMap.prototype.highlight = function(id, isHighlight){
	var ts = this.div;
	this.clearHighlight();
	var ids = [];
	if (id instanceof Array){
		ids = id;
	} else {
		ids.push(id);
	}

	if (this.mapData != null){
		for (var i=0; i<ids.length; i++){
			this.mapData.highlight(ids[i], isHighlight);
		}
	}

	this.viewMap(ts.id + "_main", this.mapData, cbFunc);

}

RouteMap.prototype.clearHighlight = function(){
	if (this.mapData != null){
		this.mapData.highlightClear();
	}
}

RouteMap.prototype.focusNode = function(id){
	var ts = this.div;
	$('#' + ts.id + '_main').animate({
//		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - 400)
		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - ($('#' + ts.id + '_main').position().top + 150))
	});
	if (ts.highlightCb != null){
		ts.highlightCb(id);
	}
}

RouteMap.prototype.onFocusHighlighted = function(cb){
	var ts = this.div;
	ts.highlightCb = cb;
},


RouteMap.prototype.viewMap = function(id, data, cb){
	this.view.setData(data);
}


RouteMap.prototype.onNodeClicked = function(func, right_func, parent){
	this.view.setClickHandler(func, right_func, parent);
}

RouteMap.prototype.setContextMenu = function(context){
	/*
	this.view.node_rightclick_event = function(d, obj){
		popup.bind(obj);
		popup.show();
	};
	*/
	this.view.setContextMenu(context);
}
