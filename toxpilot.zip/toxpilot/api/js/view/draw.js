

/**
 * マップ描画ライブラリ
 * マップAPIから利用されるものであり、利用者が直接利用はしない
 * @param c
 * @param dir
 * @returns
 */

function Draw(c, dir, color_map){
	this.c = c;
	if (dir == null){
		this.dir = 'UR';
	} else {
		this.dir = dir;
	}

	if (color_map != null){
		this.color_map = color_map;
	}

	// Create a new directed graph
/*
	this.g = new dagreD3.graphlib.Graph().setGraph({rankdir: this.dir, multigraph:true})
	    .setDefaultEdgeLabel(function () {
	    return {};
	});
*/
	this.g = new dagreD3.graphlib.Graph({rankdir: this.dir, multigraph:true});


	this.shapes = {'participant':'circle'};
	this.reverse = ['is-a'];

	var self = this;

	this.highlighted = [];
	this.highlighted_index = 0;

	$(window).on("resize", function(){
		self.refresh();
	}).trigger("resize");

}

Draw.prototype.refresh = function(){
		var width = $("#"+this.c).parent().width();
		var height = $("#"+this.c).parent().height();

		height -= $('#'+this.c).siblings().height();

		$("#"+this.c).attr("width", width);
		$("#"+this.c).attr("height", height);
}

Draw.prototype.clear = function(){
	d3.selectAll("#" + this.c + " > g").remove();
/*
	this.g = new dagreD3.graphlib.Graph().setGraph({rankdir: this.dir, ranksep:150, nodesep:100, multigraph:true})
	    .setDefaultEdgeLabel(function () {
	    return {};
	});
*/

	this.g = new dagreD3.graphlib.Graph({multigraph:true}).setGraph({rankdir: this.dir, ranksep:150, nodesep:100});

}

Draw.prototype.viewNode = function(types, vtypes){
	this.nodeType = {'targets':types, 'views':vtypes};

//	this.setData();
}


Draw.prototype.setData = function(data, target){
	// dataを基に
	//adding nodes and edges

	if (data != null){
		this.data = data;
	} else {
		data = this.data;
	}
	if (data == null){
		return;
	}
	if (target != null){
		this.target = target;
	} else {
		target = this.target;
	}


	// 非表示ノードがあるかチェック
	var hides = [];
	var nodes = data.data;
	if (this.nodeType != null){
		for (var i in nodes){
			var node = nodes[i];

			var ntypes = node.t;
			if (ntypes == null){
				ntypes = 'node';
			}
			ntypes = ntypes.split(' ');

			for (var j in ntypes){
				var ntype = ntypes[j];
				if (this.nodeType.targets.indexOf(ntype) >= 0 && this.nodeType.views.indexOf(ntype) < 0){
					hides.push(i);
					break;
				}
			}
		}
	}



	this.clear();

	var g = this.g;

	var series = [];

	if (data.data.length == 0){
		return;
	}


	var relations = data.relations;

	var self = this;

	for (var i in relations){
		var relation = relations[i];
		var color = '';

		var findex = contains(nodes, relation.f);
		var tindex = contains(nodes, relation.t);
		if (hides.indexOf(findex) >= 0 || hides.indexOf(tindex) >= 0){
			continue;
		}

		var reverse = null;
/*
		if (relation.series != null){
			var idx = series.indexOf(relation.series);
			if (idx < 0){
				series.push(relation.series);
				idx = series.length-1;
			}
			idx = idx % 18; // 現状色の数が18なのでループ

			color = ' universal line_color_'+idx;

		}
*/
		if (relation.s != null && this.color_map != null){
			if (data.series_index != null){
				var idx = this.color_map.indexOf(relation.s);
				if (idx < 0 && relation.ps != null){
					for (var j in relation.ps){
						var temp = relation.ps[j];
						idx = this.color_map.indexOf(temp);
						if (idx >= 0){
							break;
						}
					}

				}


				if (idx >= 0){
					color = ' universal line_color_f'+idx;
				} else {
					idx = data.series_index.indexOf(relation.s) % 10; // 現状色の数が10なのでループ
					color = ' universal line_color_'+idx;
				}
			} else {
				var idx = this.color_map.indexOf(relation.s);
				if (idx >= 0){
					color = ' line_color_f'+idx;
				}
			}
		}
		if (this.reverse.indexOf(relation.l) >= 0){
			reverse = 'reverse';
		}
//		var param = { label: relation.l, curve: d3.curveBasis, class:'edge_'+relation.l + color, arrowhead: 'small', arrowheadClass: 'arrowhead' };
		var param = { label: relation.l, curve: d3.curveBasis, class:'edge_'+relation.l + color, arrowheadClass: 'arrowhead' };
		if (reverse != null){
			param.arrowhead = reverse;
		}

		g.setEdge(index(nodes, relation.f), index(nodes, relation.t), param, relation.s);
//		g.setEdge(index(nodes, relation.f), index(nodes, relation.t), param);
	}

	for (var i in nodes){
		if (hides.indexOf(i) >= 0){
			continue;
		}
		var node = nodes[i];
		var style = "fill:#fff";
		var shape = "circle";
		var w = 20;
		var h = 20;
/*
		if (this.styles[node.type] != null){
			style = this.styles[node.type];
		}
		if (node.style != null){
			style = node.style;
		}
*/
		var ntype = node.t;
		if (ntype == null){
			ntype = 'node';
		}
		ntype = ntype.split(' ');
		if (this.shapes[ntype[0]] != null){
			// TODO participant
			shape = this.shapes[ntype[0]];
			w = h = 10;
		}
		if (node.shape != null){

			shape = node.shape;
		}
		if (node.c != null){
			if (ntype.indexOf('route') < 0 || node.c.length > 1){
				w += (node.c.length) * 5;
				h += (node.c.length) * 5;
			} else {
				w = h = 10;
			}
		}
		var id = makeid(node.id);

		var cls = '';
		for (var j in ntype){
			var t = ntype[j];
			cls += 'shape_' + t + " ";
		}
		if (node.id == target){
			cls += 'shape_notice';
		}

		var label = make_label(node.l);

//		g.setNode(index(nodes, node.id), {id:node.id, label:node.label, children:node.children, style:style, shape:shape, width:w, height:h, });
		g.setNode(index(nodes, node.id), {id:id, nid:node.id, l:label, children:node.c, shape:shape, width:w, height:h, class:cls, });

	}

	function make_label(label){
		if (label == null){
			return label;
		}
		var idx = 9999;
		var seps = ['@', '＠', '['];
		for (var i in seps){
			var sep = seps[i];
			var tmp_idx = label.indexOf(sep);
			if (tmp_idx >=0 && idx > tmp_idx){
				idx = tmp_idx;
			}
		}
		if (idx < 9999){
			label = label.substring(0, idx) + "\n" + label.substring(idx);
		}

		return label;
	}

	function makeid(id){
		if (id == null){
			return ""
		}
		return self.c + id.replace(/:/g,'').replace(/\//g,'').replace(/\[/g,'').replace(/\]/g,'').replace(/\./g,'').replace(/#/g,'');
	}

	function contains(nodes, id){
		var c = false;
		for (var i in nodes){
			if (nodes[i].id == id){
				return i;
			}
		}
//		nodes.push({'s':id, 'l':id, 'style': "fill: #f77"});
		nodes.push({'id':id, 'l':id, 'style': "fill: #f77"});
	}

	function index(nodes, id){
		for (var i in nodes){
			var node = nodes[i];
			if (node.id == id){
				return i;
			}
		}
	}

	// Round the corners of the nodes
	g.nodes().forEach(function (v) {
	    var node = g.node(v);
		if (node != undefined){
		    node.rx = node.ry = 5;
		}
	});

	//makes the lines smooth
	g.edges().forEach(function (e) {
	    var edge = g.edge(e.v, e.w);
		if (edge != undefined){
		    edge.lineInterpolate = 'basis';
		}
	});

	// Create the renderer
	var render = new dagreD3.render();
	// 逆矢印のrender
	render.arrows().reverse = function(parent, id, edge, type) {
	    var svgDef = parent.node();
	    var svgG = svgDef.parentNode;
	    var svgPath = svgG.firstChild;
	    svgPath.setAttribute('marker-start', svgPath.getAttribute('marker-end'));
	    svgPath.removeAttribute('marker-end');

	    // normal の矢印の向きを逆にします。
	    var marker = parent.append("marker")
	        .attr("id", id)
	        .attr("viewBox", "0 0 10 10")
	        .attr("refX", 9)
	        .attr("refY", 5)
	        .attr("markerUnits", "strokeWidth")
	        .attr("markerWidth", 8)
	        .attr("markerHeight", 6)
	        .attr("orient", "auto-start-reverse");

	    var path = marker.append("path")
	        .attr("d", "M 0 0 L 10 5 L 0 10 z")
	        .style("stroke-width", 1)
	        .style("stroke-dasharray", "1,0");

	    dagreD3.util.applyStyle(path, edge[type + "Style"]);
	    if (edge[type + "Class"]) {
	        path.attr("class", edge[type + "Class"]);
	    }
	};

	// Set up an SVG group so that we can translate the final graph.
//	var svg = d3.select("svg"),
	var svg = d3.select("#" + this.c),
	    inner = svg.append("g");


	// Set up zoom support
	var zoom = d3.zoom().on("zoom", function() {
	      inner.attr("transform", d3.event.transform);
			self.scale = d3.event.transform.k;
	    });
	svg.call(zoom);
	this.zoom = zoom;

	// Run the renderer. This is what draws the final graph.
	render(inner, g);

	// Center the graph
	var initialScale = 0.7;
	this.scale = initialScale;

	if (target == null){
		svg.call(zoom.transform, d3.zoomIdentity.translate((svg.attr("width") - g.graph().width * initialScale) / 2, 20).scale(initialScale));
	} else {
		var center = $('#' + makeid(target)).attr('transform');
		if (center != null){
			center = center.split('(')[1];
			center = center.split(')')[0];
			var attr = center.split(',');
			var cx = Number(attr[0]);
			var cy = Number(attr[1]);
			svg.call(zoom.transform, d3.zoomIdentity.translate((svg.attr("width")/2 - cx * initialScale), (svg.attr("height")/2 - cy * initialScale)).scale(initialScale));
		} else {
			svg.call(zoom.transform, d3.zoomIdentity.translate((svg.attr("width") - g.graph().width * initialScale) / 2, 20).scale(initialScale));
		}
	}


	// Simple function to style the tooltip for the given node.
	var styleTooltip = function(name, description, children) {
		if (children == null){
			return "<p class='name'>" + name + "</p><p class='description'>" + description + "</p>";
		} else {
			return "<p class='name'>" + name + "</p><p class='description'>" + description + "</p><p class='children'>" + children.map(function(c){return c.id + ":" + c.l;}).join('<br>') + "</p>";
		}
	};

	var gnodes = inner.selectAll("g.node");

	inner.selectAll("g.node")
//	svg.selectAll("g.node rect")
	  .attr("title", function(v) { return styleTooltip(g.node(v).l, g.node(v).nid, g.node(v).children) })
	  .each(function(v) { $(this).tipsy({ gravity: "n", opacity: 1, html: true }); });


	//code for drag

	//give IDs to each of the nodes so that they can be accessed
	svg.selectAll("g.node rect")
	    .attr("id", function (d) {
	    return self.c + "node" + d;
	})
	.attr("visibility", function (d) {
	    return (hides.indexOf(d) < 0) ? 'visible' : 'hidden';
	});

	svg.selectAll("g.node circle")
	    .attr("id", function (d) {
	    return self.c + "node" + d;
	})
	.attr("visibility", function (d) {
	    return (hides.indexOf(d) < 0) ? 'visible' : 'hidden';
	});
	svg.selectAll("g.node .label")
	    .attr("transform", function (d) {
		if (data.data[d].c != null){
			return "translate(0," + ((data.data[d].c.length * 5 + 20) / 2 + 30) +")";
		}
		if (data.data[d].type != null && data.data[d].t.indexOf('participant') >= 0){
		    return "translate(0,25)";
		}
		    return "translate(0,35)";
	})
	.attr("visibility", function (d) {
	    return (hides.indexOf(d) < 0) ? 'visible' : 'hidden';
	})
	.html(function(d){
		var node = data.data[d];
		if ((node.t != null && node.t.indexOf('route') >= 0) && (node.c != null && node.c.length <= 1)){
			return '';
		} else {
			return centerLinebreak(data.data[d].l);
		}
		});

	svg.selectAll("g.edgePath path")
	    .attr("id", function (e) {
	    	return self.c + makeIdSuffix(e);
//	    return self.c + e.v + "-" + e.w + "-" + e.name.replace(/:/g,'').replace(/\//g,'').replace(/\[/g,'').replace(/\]/g,'').replace(/\./g,'').replace(/#/g,'');
	});
	svg.selectAll("g.edgeLabel g")
	    .attr("id", function (e) {
	    	return 'label_'+self.c + makeIdSuffix(e);

//	    return 'label_'+self.c + e.v + "-" + e.w + "-" + e.name.replace(/:/g,'').replace(/\//g,'').replace(/\[/g,'').replace(/\]/g,'').replace(/\./g,'').replace(/#/g,'');
	});

	g.nodes().forEach(function (v) {
	    var node = g.node(v);
	    node.customId = self.c + "node" + v;
	})
	g.edges().forEach(function (e) {
	    var edge = g.edge(e.v, e.w, e.name);
//	    edge.customId = self.c + e.v + "-" + e.w + "-" + e.name.replace(/:/g,'').replace(/\//g,'').replace(/\[/g,'').replace(/\]/g,'').replace(/\./g,'').replace(/#/g,'');

	    edge.customId = self.c + makeIdSuffix(e);

	});

	function makeIdSuffix(e){
		if (e.name == null){
			return e.v + "-" + e.w;
		} else {
			return e.v + "-" + e.w + "-" + e.name.replace(/:/g,'').replace(/\//g,'').replace(/\[/g,'').replace(/\]/g,'').replace(/\./g,'').replace(/#/g,'');
		}
	}


	svg.selectAll("g.node").call(d3.drag()
	    .on("start", dragstart)
	    .on("drag", dragmove)
		.on("end", dragend));

	svg.selectAll("g.edgePath").call(d3.drag()
	    .on("start", dragstart)
	    .on('drag', link_drag)
	    .on('end', link_dragend));

	var self = this;


	function getLen(str){
	  var result = 0;
	  for(var i=0;i<str.length;i++){
	    var chr = str.charCodeAt(i);
	    if((chr >= 0x00 && chr < 0x81) ||
	       (chr === 0xf8f0) ||
	       (chr >= 0xff61 && chr < 0xffa0) ||
	       (chr >= 0xf8f1 && chr < 0xf8f4)){
	      //半角文字の場合は1を加算
	      result += 1;
	    }else{
	      //それ以外の文字の場合は2を加算
	      result += 2;
	    }
	  }
	  //結果を返す
	  return result/2;
	};

	function centerLinebreak(word){
		var string = "";
		var words = ['[','@', '＠'];

		for (var i in words){
			var index = word.indexOf(words[i]);
			if (index >= 0){
				word = word.substring(0,index) + "\n" + word.substring(index);
				break;
			}
		}

		var array = word.split('\n');
//		const  maxTextLength = d3.max(array, d => d.length )
		array.forEach(function(t,i){
//		var l = (maxTextLength - t.length) /2 - (maxTextLength / 2);
//		var l =  - t.length /2;
		var l =  - getLen(t) /2;
		string += '<g><text><tspan y="'+i+'em" x="' + l + 'em">' + t + '</text></g></tspan>';
		});
		return string
	}

	function nodeClick(d, me){
		if (self.clickHandler != null && typeof self.clickHandler == "function"){
			var id = self.g._nodes[d].nid;
			self.clickHandler(d, id, me);
		}
	};


	function nodeRightClick(d, me){
		if (self.rightClickHandler != null && typeof self.rightClickHandler == "function"){
			self.rightClickHandler(d, me);
		}
	};

	function addRightClickEvent(objs, func){
		for (var i=0; i<objs[0].length; i++){
			var obj = objs[0][i];
			if (obj.oncontextmenu == undefined){
				$(obj).bind('contextmenu', function(evnt){
					window.event = evnt;
					func(evnt.target.__data__, evnt.target);
					return false;
				});
			} else {
				obj.oncontextmenu = function(evnt){
					func(evnt.srcElement.__data__, evnt.srcElement);
					return false;
				};
			}
		}
	};
/*
	// 右クリックイベント
	addRightClickEvent(gnodes._groups, function(d, obj){
//		svg.selectAll("g.node")._groups[0]
		nodeRightClick(d, obj);
	});
*/

	var dragging = false;

	function dragstart(d) {
	    d3.event.sourceEvent.stopPropagation();
		dragging = false;
	}

	function dragmove(d) {
	    var node = d3.select(this),
	        selectedNode = g.node(d);
	    var prevX = selectedNode.x,
	        prevY = selectedNode.y;

	    selectedNode.x += d3.event.dx;
	    selectedNode.y += d3.event.dy;
	    node.attr('transform', 'translate(' + selectedNode.x + ',' + selectedNode.y + ')');

		if (d3.event.dx != 0 || d3.event.dy != 0){
			dragging = true;
		}

	    var dx = selectedNode.x - prevX,
	        dy = selectedNode.y - prevY;

	    g.edges().forEach(function (e) {
	        if (e.v == d || e.w == d) {
	            edge = g.edge(e.v, e.w, e.name);
	            translateEdge(g.edge(e.v, e.w, e.name), dx, dy);
	            $('#' + edge.customId).attr('d', calcPoints(e));
	            label = $('#label_' + edge.customId);
				var xforms = label.attr('transform');
	            if (xforms != "") {
	                var parts  = /translate\(\s*([^\s,)]+)[ ,]?([^\s,)]+)?/.exec(xforms);
	                var X = parseInt(parts[1])+dx, Y = parseInt(parts[2])+dy;
//	                console.log(X,Y);
	                if (isNaN(Y)) {
	                    Y = dy;
	                }
	                label.attr('transform','translate('+X+','+Y+')');
	            }
	        }
	    })
	}

	function dragend(d, obj, a, b) {
		if (!dragging){
			nodeClick(d, $(a[obj]).children()[0]);
			nodeRightClick(d, $(a[obj]).children()[0]);
			return false;
		}
	}

	function link_drag(d){
	    translateEdge(g.edge(d.v, d.w, d.name), d3.event.dx, d3.event.dy);
	    $('#' + g.edge(d.v, d.w, d.name).customId).attr('d', calcPoints(d));
		if (d3.event.dx != 0 || d3.event.dy != 0){
			dragging = true;
		}
	}

	function link_dragend(d){
	    var path = $('#' + g.edge(d.v, d.w, d.name).customId);
		if (!dragging){
			if (path.hasClass('path_selected')){
				path.removeClass('path_selected');
			} else {
				path.addClass('path_selected');
			}
		}
	}


	function translateEdge(e, dx, dy) {
	    e.points.forEach(function (p) {
	        p.x = p.x + dx;
	        p.y = p.y + dy;
	    });
	}

	//taken from dagre-d3 source code (not the exact same)
	function calcPoints(e) {
	    var edge = g.edge(e.v, e.w, e.name),
	        tail = g.node(e.v),
	        head = g.node(e.w);
	    var points = edge.points.slice(1, edge.points.length - 1);
	    var afterslice = edge.points.slice(1, edge.points.length - 1)
	    points.unshift(intersectRect(tail, points[0]));
	    points.push(intersectRect(head, points[points.length - 1]));

	  var line = d3.line()
	    .x(function(d) { return d.x; })
	    .y(function(d) { return d.y; });

	  line.curve(edge.curve);

	  return line(points);
	}

	//taken from dagre-d3 source code (not the exact same)
	function intersectRect(node, point) {
	    var x = node.x;
	    var y = node.y;
	    var dx = point.x - x;
	    var dy = point.y - y;
	    var w = $("#" + node.customId).attr('width') / 2;
	    var h = $("#" + node.customId).attr('height') / 2;


		if (isNaN(w)){
			// circle
		    var r = $("#" + node.customId).attr('r') / 1;
		    var cx = node.x;
		    var cy = node.y;

		    var px = cx - point.x;
		    var py = cy - point.y;

		    var det = Math.sqrt(r * r * py * py + r * r * px * px);

		    var dx = Math.abs(r * r * px / det);
		    if (point.x < cx) {
		      dx = -dx;
		    }
		    var dy = Math.abs(r * r * py / det);
		    if (point.y < cy) {
		      dy = -dy;
		    }

		    return {x: cx + dx, y: cy + dy};
		} else {

			// rect
		    var sx = 0,
		        sy = 0;
		    if (Math.abs(dy) * w > Math.abs(dx) * h) {
		        // Intersection is top or bottom of rect.
		        if (dy < 0) {
		            h = -h;
		        }
		        sx = dy === 0 ? 0 : h * dx / dy;
		        sy = h;
		    } else {
		        // Intersection is left or right of rect.
		        if (dx < 0) {
		            w = -w;
		        }
		        sx = w;
		        sy = dx === 0 ? 0 : w * dy / dx;
		    }
		    return {
		        x: x + sx,
		        y: y + sy
		    };
		}

	}
}


// 文字列検索
// とりあえず単にハイライトするのみ
Draw.prototype.find = function(word){
	var g = this.g;

	this.highlighted = [];
	this.highlighted_index = -1;

	if (word == ''){
		return [];
	}

	if (word != null){
		word = word.toLowerCase();
	}

	var self = this;

	g.nodes().forEach(function (v) {
	    var node = g.node(v);
//		if (node.label.indexOf(word) >= 0 || node.nid == word){
	    var hit = false;
	    if (node.l.toLowerCase().indexOf(word) >= 0 || node.nid.toLowerCase() == word){
	    	hit = true;
	    }

	    // 子が該当IDを持つ（束ねられている）
	    if (!hit && node.children != null){
	    	for (var j in node.children){
	    		var child = node.children[j].id;
	    		if (child.toLowerCase() == word){
	    			hit = true;
	    			break;
	    		}
	    	}
	    }

		if (hit){
			var expects = ['@', '＠'];
			var hit = true;
			for (var i in expects){
				var nl = node.l;
				nl = nl.toLowerCase();
				if (nl.indexOf(expects[i]) >= 0 && nl.indexOf(expects[i]) < nl.indexOf(word)){
					hit = false;
					break;
				}
			}

			// hit
			if (hit){
				$('#'+node.id).addClass('highlighted');
				self.highlighted.push(node);
			}
		}
	})
	this.find_highlight(false);

	return this.highlighted;
}

Draw.prototype.find_highlight = function(asc){
	var g = this.g;

	if (this.highlighted.length == 0){
		return;
	}

	if (asc){
		this.highlighted_index --;
		if (this.highlighted_index < 0){
			this.highlighted_index = this.highlighted.length-1;
		}
	} else {
		this.highlighted_index ++;
		if (this.highlighted_index >= this.highlighted.length){
			this.highlighted_index = 0;
		}
	}


	var hl = this.highlighted[this.highlighted_index];

	var center = $('#'+hl.id).attr('transform');

	var svg = d3.select("#" + this.c);
	var zoom = this.zoom;

//	svg.call(zoom);
	var scale = this.scale;
	if (center != null){
		center = center.split('(')[1];
		center = center.split(')')[0];
		var attr = null;
		if (center.indexOf(',') > 0){
			attr = center.split(',');
		} else {
			attr = center.split(' ');
		}
		var cx = Number(attr[0]);
		var cy = Number(attr[1]);
		if (!isNaN(cx) && !isNaN(cy)){
			svg.transition().duration(500).call(zoom.transform, d3.zoomIdentity.translate((svg.attr("width")/2 - cx * scale), (svg.attr("height")/2 - cy * scale)).scale(scale));
		}
	} else {
		svg.transition().duration(500).call(zoom.transform, d3.zoomIdentity.translate((svg.attr("width") - g.graph().width * scale) / 2, 20).scale(scale));
	}


}


Draw.prototype.clearHighlight = function(){
	var g = this.g;

	g.nodes().forEach(function (v) {
	    var node = g.node(v);
		$('#'+g.node(v).id).removeClass('highlighted');
	})

	this.highlighted = [];

}

Draw.prototype.setClickHandler = function(func, right_func){
	if (func != null){
		this.clickHandler = func;
	}
	if (right_func != null){
		this.rightClickHandler = right_func;
	}
}

Draw.prototype.setContextMenu = function(context){
	var svg = d3.select("#" + this.c);

	var elements = svg.selectAll("g.node")._groups[0];

	context.element = elements;
	this.contextMenuObj = new ContextMenu(context);
}


