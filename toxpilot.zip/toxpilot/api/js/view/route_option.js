/**
 *
 */



function RouteOption(route, options, initials){
	this.div = route[0];//.div;

	// id

	this.init();

}

RouteOption.prototype.init = function(){
	var ts = this.div;
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_path",
				"class" : "dialog_div"
			})
			);

	$('#' + ts.id + "_path").append(
			'<div class="dialog_header">CLOSE</div>'+
			'<div id="' + ts.id + '_path_contents" class="dialog_contents"></div>'
			);

	this.base = '#' + ts.id + "_path";
	this.id = this.base + '_contents';

	$('.dialog_div').draggable();
	$('.dialog_header').click(function(e){
		var target = e.target;
		$(target.parentElement).hide();
	});


	$(this.base).hide();

}

RouteOption.prototype.view_path = function(routes){
	var base = this.base;

	var id = this.id;

	$(this.base).show();


	this.clear_path();

	var pathes = [];
	for (var i in routes){
		var path = {nodes:[], links:[]};
		pathes.push(path);
		var route = routes[i];
		route = route.reverse(); // 結果順から原因順に並び替える
		path.nodes = route;
		for (var j in route){
			if (j > 0){
				path.links.push(j);
			}
		}
	}

	var w = 300;// * pathes.length;
	var h = 40;

	var width = (w + 30) * pathes.length;
	var height = 0;
	for (var i in pathes){
		var path = pathes[i];
		if (path.nodes.length > height){
			height = path.nodes.length;
		}
	}
	height *= h * 1.5;

	var svg = d3.select(id).append("svg")
	.attr("width", width)
	.attr("height", height);

	$(id).width(width + 10);
	$(id).height(height + 20);

	$(base).width(width + 10);
	$(base).height(height + 20);


	for (var i in pathes){
		var nodes = pathes[i].nodes;
		var links = pathes[i].links;

		var path_nodes = svg.selectAll(".pathrect")
		.data(nodes)
		.enter().append("rect")
		.attr("x", 10 + i * (w + 30))
		.attr("y", function(d) { return nodes.indexOf(d) * h * 1.5;})
		.attr("fill", function(d){
			if (d.type == 'cause'){return '#3f3';}
			if (d.type == 'result'){return '#99f';}
			return '#f44';
		})
		.attr("width", w)
		.attr("height", h);

		var path_tnodes = svg.selectAll("text.pathrect")
		.data(nodes)
		.enter().append("svg:text")
		.attr("x", (w / 2) + 10 + i * (w + 30))
		.attr("y", function(d) { return nodes.indexOf(d) * h * 1.5 + h / 1.5;})
//		.attr("y", function(d) { return nodes.indexOf(d) * h * 1.5;})
//		.text(function(d){return d.label;})
//		.attr("transform", function(d) {return "translate(" + ((w / 2) + 10 + i * (w + 30))+ ", " + (nodes.indexOf(d) * h * 1.5 + h / 1.5) + ")";})
		.attr("transform", function(d) {return "translate(" + ((w / 2) + 10 + i * (w + 30))+ ", " + (nodes.indexOf(d) * h * 1.5 + h / 2) + ")";})
		.html(function(d){return centerLineBreak(d.label);})
		.style("font-weight", "lighter")
		.style("stroke", function(d){return '#000';})
		.style("stroke-width", function(d) {return '0.5px';})
		.style("text-anchor", function(d) {return 'middle';})
		.style("cursor", function(d){return 'pointer';});


		var path_links = svg.selectAll(".pathlink")
		.data(links)
		.enter().append("line")
		.attr("x1", (w / 2) + 10 + i * (w + 30))
		.attr("y1", function(d, j) { return j * h * 1.5 + h;})
		.attr("x2", (w / 2) + 10 + i * (w + 30))
		.attr("y2", function(d, j) { return j * h * 1.5 + h * 1.5;})
		.style("stroke", 'black');

	}

	function centerLineBreak(word){
		var array = word.split('\n');
		let string = "";
		array.forEach((t,i) => {
			string += '<tspan y="' + i + 'em" x="0em">' + t + '</tspan>';
		});
		return string;
	}

}

RouteOption.prototype.clear_path = function(){
	var id = this.id;

	// すでにカンバスが存在する場合は削除する
	if (d3.select(id).select("svg")){
		d3.select(id).select("svg").remove();
	}
}
