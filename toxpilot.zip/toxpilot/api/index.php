<?php

// PHPライブラリ本体を格納するディレクトリ。
// htdocsではない場所が望ましい
$lib_dir = 'lib';
// 有効なバージョンのディレクトリに存在するファイル名
$valid_filename = 'valid.php';


$method = $_SERVER['REQUEST_METHOD'];


switch ($method){
	case 'GET':
		include ($lib_dir . '/get.php');
		break;

	default:
		echo 'no such method:'.$method;
		exit();
	
}


?>