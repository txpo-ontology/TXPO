/**
 *
 */

/**
 * 検索API
 */

function Search(endpoint, lang){
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;
}

/**
 * 所見一覧を取得する
 * @param cb
 */
Search.prototype.findRemarkList = function(cb){
	this.api.find("/search?q[]=tp=remark", function(data){
		cb(data);
	});
}

Search.prototype.find = function(queries, cb, args, errcb){
	var query = "q[]=" + queries.join("&q[]=");

	this.api.find("/search?"+query, function(data){
		cb(data, args);
	}, null, function(data, args){
		errcb(data, args);
	});
}



Search.prototype.getSuggestFunc = function(type){
	var self = this;
	return function(req, res){
		var query = "/search?q[]=tp=" + type + ",w=" + encodeURIComponent(req.term);
		if ((type == 's' || type == 'r') && req.term == ''){
			query = "/search?q[]=tp=" + type + ",w=&q[]=tp=p,w=";
		}

		$.ajax({
			// ここをどうにかしないと（accessorにする）
	        url: self.api.getBaseURI() + query,
	        dataType: "json",
	        success: function( data ) {
	        	// TODO @以降はヒット対象にしないなどの処理が必要
	        	var list = [];
	        	var tmp_list = [];
	        	var dic = {};
	        	for (var i in data){
	        		var datum = data[i];
	        		/*
	        		var val = datum[type + 'l'].value;
	        		if (list.indexOf(val) < 0){
	        			list.push(val);
	        		}*/
	        		addDic(dic, datum[type+'s'].value, datum[type + 'l']);
	        		if (tmp_list.indexOf(datum[type+'s'].value) < 0){
		        		tmp_list.push(datum[type+'s'].value);
	        		}
	        	}
	        	for (var i in tmp_list){
	        		var datum = tmp_list[i];
	        		list.push(getDic(dic, datum, self.lang));
	        	}
	            res(list);
	        },
			error: function(xhr, ts, err){
			    res(['']);
			}
		});
	}

	function addDic(dic, key, value){
		var k = '_';

		if (value['xml:lang'] != null && value['xml:lang'] != ''){
			k = value['xml:lang'];
		}
		if (dic[key] == null){
			dic[key] = {};
		}
		dic[key][k] = value.value;
	}

	function getDic(dic, key, lang){
		var k = '_';

		var words = dic[key];
		if (words == null){
			return "";
		}
		if (words[lang] != null){
			return words[lang];
		}
		return words['_'];
	}
}

Search.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}