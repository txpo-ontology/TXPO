

/**
 * 作用機序データ処理用API
 */

function Data(endpoint, lang){
	// Create a new directed graph

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

//	// 探索対象とするtypeの一覧 これは外から渡してやる
//	this.targetTypes = [];

	// part表示を逆転させるか
	this.isInverse = false;

//	this.targetTypes = ['hasResult', 'has_part', 'hasParticipant'];
//	this.targetTypes = ['hasParticipant'];
//	this.targetTypes = ['hasResult', 'has_part'];

	// リンク種別ごとの、リンク先が何者かの情報（仮処理）
	this.nodeTypes = {'hasResult':'unknown','has_part': 'part_process', 'hasFindings':'finding', 'hasParticipant':'participant', 'hasAgent':'participant','hasInput':'participant', 'hasOutput':'participant', 'has Pathway':'part_process', 'has_Molecular_reaction':'part_process'};


	this.clear();


}


Data.prototype.clear = function(){
	// 本来このメソッドやこのクリアも不要のはず
	this.data = [];
	this.relations = [];
	this.current = {};
}

Data.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}


Data.prototype.getValidRelationType = function(cb){
	this.api.find("/data/tree/type", function(data){
		cb(data);
	});
}


Data.prototype.findSeries = function(cb){
	this.api.find("/data/tree/course", function(data){
		cb(data);
	});
}

Data.prototype.findWhole = function(cb){
	this.api.find("/data/tree", function(data){
		cb(data);
	});
}

//概念種別を取得する
Data.prototype.findType = function(s, cb){
	s = get_uri(s);
	if (s == null){
		return;
	}

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	if (cb != null){
		this.api.find("/data/concept/" + s + "/type", function(data){
			cb(data);
		});
	}
	return this.api.findSync("/data/concept/" + s + "/type");

}



// 指定作用機序が持つ全ノード一覧を取得する
Data.prototype.findNodes = function(s, label, cb, type){
	var self = this;

	if (type == null){
		type = '';
	} else {
		type = '/' + type;
	}

	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用
	this.api.find("/data/map/course/"+s+type, function(data){
		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});
}


// 概念のアノテーション情報を取得する
Data.prototype.findAnnotation = function(s, cb, external){
	s = get_uri(s);

//	this.api.find("/data/map/process/tox:[TXG]_0000109", function(data){ // processテスト用

	var opt = '';

	if (external){
		opt = '/true';
	}

	this.api.find("/data/concept/" + s + opt, function(data){

		cb(data);

	});
}

//指定プロセスから関連する全作用機序一覧を取得する
Data.prototype.findCourses = function(s, cb){
	var self = this;

	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/process/"+s+"/course", function(data){

			cb(data);

		});
	}

	return this.api.findSync("/data/process/"+s+"/course");
}

// 自概念に関連しているプロセスを取得する
Data.prototype.findRelations = function(s, cb){
	var self = this;

	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/concept/"+s+"/relation", function(data){

			cb(data);

		});
	}

	return this.api.findSync("/data/concept/"+s+"/relation");
}

/**
 * 自分から再帰的にたどった原因一覧を取得する
 */
Data.prototype.findCausesAndResults = function(s){
	var ret = {'origins': {}, 'dests':{}};

	var self = this;

	function findRecurseCauses(s, ret, work){
		if (work == null){
			work = [];
		}
		for (var i in self.data.relations){
			var rel = self.data.relations[i];
			if (rel.t == s && work.indexOf(rel.f) < 0 && rel.l.indexOf('result') >= 0){
				if (ret.origins[rel.l] == null){
					ret.origins[rel.l] = [];
				}
				work.push(rel.f);
				ret.origins[rel.l].push({'id':rel.f, 'l':getLabel(rel.f)});
				findRecurseCauses(rel.f, ret, work);
			}
		}
	}

	function findRecurseResults(s, ret, work){
		if (work == null){
			work = [];
		}
		for (var i in self.data.relations){
			var rel = self.data.relations[i];
			if (rel.f == s && work.indexOf(rel.t) < 0 && rel.l.indexOf('result') >= 0){
				if (ret.dests[rel.l] == null){
					ret.dests[rel.l] = [];
				}
				work.push(rel.t);
				ret.dests[rel.l].push({'id':rel.t, 'l':getLabel(rel.t)});
				findRecurseResults(rel.t, ret, work);
			}
		}
	}

	findRecurseCauses(s, ret);
	findRecurseResults(s, ret);


	function getLabel(id){
		for (var j in self.data.concepts){
			var datum = self.data.concepts[j];
			if (datum.id == id){
				return datum.l;
			}
		}
		return id;
	}

	return ret;
}


/**
 * 自分の持つ原因と結果一覧を取得する
 * @param s
 * @returns {___anonymous3095_3121}
 *//*
Data.prototype.findCausesAndResults = function(s){
	// サーバを経由せず、自分が持つデータのみで処理する

	var ret = {'origins': {}, 'dests':{}};

	var self = this;

	for (var i in this.data.relations){
		var rel = this.data.relations[i];
		if (rel.f == s){
			if (ret.dests[rel.l] == null){
				ret.dests[rel.l] = [];
			}
			ret.dests[rel.l].push({'id':rel.t, 'l':getLabel(rel.t)});
		}
		if (rel.t == s){
			if (ret.origins[rel.l] == null){
				ret.origins[rel.l] = [];
			}
			ret.origins[rel.l].push({'id':rel.f, 'l':getLabel(rel.f)});
		}
	}

	function getLabel(id){
		for (var j in self.data.concepts){
			var datum = self.data.concepts[j];
			if (datum.id == id){
				return datum.l;
			}
		}
		return id;
	}

	return ret;
}*/


Data.prototype.makeLabel = function(label){
/*
	var tmp = label.split('＠');
	if (tmp.length == 2){
		label = tmp[0];
	}
	tmp = label.split('@');
	if (tmp.length == 2){
		label = tmp[0];
	}
*/
// 一つ目の「＠」で改行
	var index = label.indexOf('＠');
	if (index < 0){
		index = label.indexOf('@');
	}
	if (index >= 0){
		label = label.substring(0, index) + "\n" + label.substring(index);
	}

	return label;
}
