

/**
 * プロセスデータ処理用API
 */

function ProcessData(endpoint, lang){
	// Create a new directed graph

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

//	// 探索対象とするtypeの一覧 これは外から渡してやる
//	this.targetTypes = [];


	// part表示を逆転させるか
	this.isInverse = false;

//	this.targetTypes = ['hasResult', 'has_part', 'hasParticipant'];
//	this.targetTypes = ['hasParticipant'];
//	this.targetTypes = ['hasResult', 'has_part'];

	// リンク種別ごとの、リンク先が何者かの情報（仮処理）
	this.nodeTypes = {'hasResult':'unknown','has_part': 'part_process', 'hasFindings':'finding', 'hasParticipant':'participant', 'hasAgent':'participant','hasInput':'participant', 'hasOutput':'participant', 'has Pathway':'part_process', 'has_Molecular_reaction':'part_process'};


	this.clear();


}


ProcessData.prototype.clear = function(){
	this.data = [];
	this.relations = [];
	this.current = {};
}

ProcessData.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}


ProcessData.prototype.getValidRelationType = function(cb){
	this.api.find("/data/tree/type", function(data){
		cb(data);
	});
}


ProcessData.prototype.findAllProcesses = function(cb){
//	var self = this;
	this.api.find("/data/tree/process/part", function(data){
//		self.data = data;
		cb(data);
	});
}



// 指定プロセスから関連する全ノードおよび関連一覧を取得する
ProcessData.prototype.findNodes = function(s, label, cb, type){
	var self = this;

	if (type == null){
		type = '';
	} else {
		type = '/' + type;
	}

	s = get_uri(s);

	this.api.find("/data/map/process/"+s+type, function(data){

//		self.data = data;
		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});

}
//概念種別を取得する
ProcessData.prototype.findType = function(s, cb){
	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/concept/"+s + "/type", function(data){

			cb(data);

		});
	}
	return this.api.findSync("/data/concept/"+s + "/type");
}

//指定プロセスから関連する全作用機序一覧を取得する
ProcessData.prototype.findCourses = function(s, cb){
	var self = this;

	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/process/"+s+"/course", function(data){

			cb(data);

		});
	}

	return this.api.findSync("/data/process/"+s+"/course");
}

//指定概念の関連元プロセス一覧を取得する
ProcessData.prototype.findRelations = function(s, cb){
	var self = this;

	s = get_uri(s);

	if (cb != null){
		this.api.find("/data/concept/"+s+"/relation", function(data){

			cb(data);

		});
	}

	return this.api.findSync("/data/concept/"+s+"/relation");
}



//指定プロセスの汎用機序が持つ全ノードおよび関連一覧を取得する

ProcessData.prototype.findChains = function(s, label, cb, type){
	var self = this;

	if (type == null){
		type = '';
	} else {
		type = '/' + type;
	}

	s = get_uri(s);

	this.api.find("/data/map/chain/"+s+type, function(data){
		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});

}

//全ノードおよび関連一覧を取得する
ProcessData.prototype.findAllChains = function(cb, type){
	var self = this;

	if (type == null){
		type = '/rpwmftioa';
	} else {
		type = '/' + type;
	}

	this.api.find("/data/map/all"+type, function(data){
		if (data == null || data.concepts == null || data.concepts.length == 0){

		} else {
			self.data = data;
		}

		cb({'data':data.concepts, 'relations':data.relations});

	});

}


//指定プロセスの兄弟および関連一覧を取得する
ProcessData.prototype.findSiblings = function(s, cb, type){
	var self = this;

	if (type == null){
		type = '';
	} else {
		type = '/' + type;
	}

	s = get_uri(s);

	this.api.find("/data/concept/siblings/"+s+type, function(data){

//		self.data = data;

		cb(data);

	});

}


//概念のアノテーション情報を取得する
// (TODO Dataにも同じのがあるのでまとめたい)
ProcessData.prototype.findAnnotation = function(s, cb, external){
	s = get_uri(s);

	var opt = '';

	if (external){
		opt = '/true';
	}


	this.api.find("/data/concept/" + s + opt, function(data){

		cb(data);

	});
}

ProcessData.prototype.findCausesAndResults = function(s){
	// サーバを経由せず、自分が持つデータのみで処理する

	var ret = {'origins': {}, 'dests':{}};

	var self = this;

	for (var i in this.data.relations){
		var rel = this.data.relations[i];
		if (rel.f == s){
			if (ret.dests[rel.l] == null){
				ret.dests[rel.l] = [];
			}
			ret.dests[rel.l].push({'id':rel.t, 'l':getLabel(rel.t)});
		}
		if (rel.t == s){
			if (ret.origins[rel.l] == null){
				ret.origins[rel.l] = [];
			}
			ret.origins[rel.l].push({'id':rel.f, 'l':getLabel(rel.f)});
		}
	}

	function getLabel(id){
		for (var j in self.data.concepts){
			var datum = self.data.concepts[j];
			if (datum.id == id){
				return datum.l;
			}
		}
		return id;
	}

	return ret;
}

ProcessData.prototype.makeLabel = function(label){
/*
	var tmp = label.split('＠');
	if (tmp.length == 2){
		label = tmp[0];
	}
	tmp = label.split('@');
	if (tmp.length == 2){
		label = tmp[0];
	}
*/
// 一つ目の「＠」で改行
	var index = label.indexOf('＠');
	if (index < 0){
		index = label.indexOf('@');
	}
	if (index >= 0){
		label = label.substring(0, index) + "\n" + label.substring(index);
	}

	return label;
}
