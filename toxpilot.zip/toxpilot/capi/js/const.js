/*
var DATA_TOX_PROCESS = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001715'; // 毒性作用機序依存プロセス
var DATA_TOX_MECHA = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000009'; // 毒性発現作用機序
var DATA_HAS_PART = 'http://purl.obolibrary.org/obo/BFO_0000051'; // has_part
var DATA_HAS_RESULT = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000069'; // has_result
var DATA_HAS_ROLE = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001518'; // hasRole
var DATA_HAS_PARTICIPANT = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001519'; // hasParticipant
var DATA_HAS_RELATED_ASSAY = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000756'; // hasRelatedAssay
var DATA_PRIMITIVE_PROCESS = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000271'; // prmitiveプロセス
var DATA_PRIMITIVE_PATHWAY = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000614'; // 生体パスウェイ
var DATA_ASSAY = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000487'; // assay
var DATA_FUNC_PROCESS = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000145'; // 機能関連プロセス
var DATA_PHEM_PROCESS = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000357'; // 現象関連プロセス

var DATA_IN_VITRO_HUMAN = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000795'; // in vitro(human)
var DATA_IN_VIVO_RAT = 'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000773'; // in vivo(rat)
*/

var BASE_URI = 'http://purl.obolibrary.org/obo/';


var DATA_TOX_MECHA = BASE_URI + 'TXPO_0000009'; // 毒性発現作用機序


// 固有色設定
var COLOR_MAP = [
		BASE_URI + 'TXPO_0000028', // 好酸性顆粒変性
		BASE_URI + 'TXPO_0002528', // ERストレス
		BASE_URI + 'TXPO_0000888', // 脂肪肝
		BASE_URI + 'TXPO_0001432', // 曇り硝子変性
		BASE_URI + 'TXPO_0001986', // ミトコンドリア障害
		BASE_URI + 'TXPO_0000324', // アポトーシス
		BASE_URI + 'TXPO_0001277', // 胆汁うっ滞
		BASE_URI + 'TXPO_0002215'  // リン脂質症
];


var base_url = 'http://localhost/';


function get_uri(s){
	if (s == null){
		return null;
	}
	if (typeof s == 'object'){
		if (s.id != null){
			s = s.id;
		} else {
			return null;
		}
	}
	s = s.replace(BASE_URI , 'txpo:');
	s = s.replace('http://purl.obolibrary.org/obo/', 'go:');
	s = s.replace('http://www.semanticweb.org/yukiyamagata/ontologies/2017/1/tgp#', 'tgp:');


	if (s.indexOf('/') >= 0){
		s = encodeURIComponent(encodeURIComponent(s));
	}

	return s;
}
