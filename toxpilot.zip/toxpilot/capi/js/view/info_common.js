/**
 * 情報表示共通
 */

function InfoCommon(div, lang){

	this.div = div;

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.keys = ['http://www.w3.org/2000/01/rdf-schema#label', 'http://purl.obolibrary.org/obo/IAO_0000115'];

	this.link_prefixes = {'PMID:':'https://www.ncbi.nlm.nih.gov/pubmed/', 'Reactome:': 'https://reactome.org/PathwayBrowser/#/','ISBN:':'https://isbnsearch.org/isbn/'};
}


InfoCommon.getLabel = function(data, lang){
	var ret = null;
	var keys = ['http://www.w3.org/2000/01/rdf-schema#label', 'http://purl.obolibrary.org/obo/IAO_0000115'];
	for (var i in keys){
		var key = keys[i];
		var datums = data.annotations[key];
		if (datums == null){
			continue;
		}
		if (key == 'http://www.w3.org/2000/01/rdf-schema#label'){
			var labels = [];
			for (var i in datums){
				var datum = datums[i];
				labels.push(datum.o);
			}
			if (labels.length > 0){
				ret = this.get_label(labels, lang);
				break;
			}
		}
	}
	return ret;

}

InfoCommon.get_label = function(objs, l){
	var tmp = null;
	for (var i in objs){
		var obj = objs[i];
		if (l == null){
			return obj.value.replace(/\n/g, '<br>');
		}
		if (obj['xml:lang'] != null){
			tmp = obj.value;
			if (obj['xml:lang'] == l){
				return tmp.replace(/\n/g, '<br>');
			}
		} else {
			tmp = obj.value;
		}
	}
	return tmp.replace(/\n/g, '<br>');

}


InfoCommon.prototype.showHead = function(data){
	var ts = this.div;

	this.id = data.id;

//	var self = this;
	var keys = this.keys;

	// head
	var contents = '<table class="info top">';
	// head はlabelとdefinition
	for (var i in keys){
		var key = keys[i];
		var datums = data.annotations[key];
		if (datums == null){
			continue;
		}
		if (key == 'http://www.w3.org/2000/01/rdf-schema#label'){
			var labels = [];
			for (var i in datums){
				var datum = datums[i];
				labels.push(datum.o);
			}
		}

		contents += this.make_tr(datums, data.dic);
	}
	contents += "</table>\n";
	this.set_table_contents(contents, ts.id + '_info_head');
}

InfoCommon.prototype.showAnnotation = function(data){
	var ts = this.div;
	var keys = this.keys;
	var excepts = ['http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://purl.obolibrary.org/obo/IAO_0000232'];

	// annotation
	var contents = '<div><h4><span class="open_table">－</span> <span>Annotation Property</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info annotation">';
	for (var key in data.annotations){
		if (excepts.indexOf(key) >= 0 || keys.indexOf(key) >= 0){
			// 除外データ
			continue;
		}
		var datums = data.annotations[key];
		contents += this.make_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_annotation');
	$('#' + ts.id + '_info_annotation .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_annotation .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_annotation .table').slideDown(200);
			$(event.target).text('－');
		}
	});
}

InfoCommon.prototype.showObject = function(data){
	var ts = this.div;
	// object
	var contents = '<div><h4><span class="open_table">－</span> <span>Object Property</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info object">';
	for (var key in data.objects){
		var datums = data.objects[key];
		contents += this.make_object_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_object');
	$('#' + ts.id + '_info_object .open_table').click(function(event){
		toggle($(event.target));

	});

	function toggle(target){
		if (target.text() == '－'){
			// close
			$('#' + ts.id + '_info_object .table').slideUp(200);
			target.text('＋');
		} else {
			$('#' + ts.id + '_info_object .table').slideDown(200);
			target.text('－');
		}
	}
}

InfoCommon.prototype.showInheritObject = function(data){
	var ts = this.div;
	// object
	var contents = '<div><h4><span class="open_table">－</span> <span>Object Property (Anonymous Ancestors)</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info inherit">';
	for (var key in data.inherits){
		var datums = data.inherits[key];
		contents += this.make_object_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_inherit');
	$('#' + ts.id + '_info_inherit .open_table').click(function(event){

		toggle($(event.target));
	});

	function toggle(target){
		if (target.text() == '－'){
			// close
			$('#' + ts.id + '_info_inherit .table').slideUp(200);
			target.text('＋');
		} else {
			$('#' + ts.id + '_info_inherit .table').slideDown(200);
			target.text('－');
		}
	}

}

InfoCommon.prototype.showEquivalent = function(data){
	var ts = this.div;
	// object
	var contents = '<div><h4><span class="open_table">－</span> <span>Equivalent Property</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info equivalent">';
	for (var key in data.equivalents){
		var datums = data.equivalents[key];
		contents += this.make_object_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_equivalent');
	$('#' + ts.id + '_info_equivalent .open_table').click(function(event){
		toggle($(event.target));
	});

	function toggle(target){
		if (target.text() == '－'){
			// close
			$('#' + ts.id + '_info_equivalent .table').slideUp(200);
			target.text('＋');
		} else {
			$('#' + ts.id + '_info_equivalent .table').slideDown(200);
			target.text('－');
		}
	}
}

InfoCommon.prototype.showMapping = function(data){
	var ts = this.div;

	var first = false;
	var open = false;

	var sw = $('#' + ts.id + '_info_mapping .open_table').text();

	if (sw == '－'){
		// 既に一度描画済み、かつ、開かれている
		open = true;
	} else if (sw == '＋'){
		// 既に一度描画済み、かつ、閉じられている
		open = false;
	} else {
		// 初回描画
		open = false;
		first = true;
	}


	// mapping
	var contents = '<div><h4><span class="open_table">－</span> <span>Mapping</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info mapping">';
	if (!first){
		for (var key in data.mapping){
			var datum = data.mapping[key];
			if (key == 'error'){
				contents += '<tr><th><div>' + datum +'</div></th></tr>';
			} else {
				contents += '<tr><td><div><span class="clickable outer">' + key +'</span><span class="hide">' + key + '</span></div></td></tr>';
			}
		}
	} else {
		contents += '<tr><th><div>Loading..</div></th></tr>';
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_mapping');

	if (!first){
		// 初回以降は普通にtoggleイベント
		$('#' + ts.id + '_info_mapping .open_table').click(function(event){
			toggle($(event.target), true);
		});
	}

	var self = this;

	if (first){
		toggle($('#' + ts.id + '_info_mapping .open_table'));
		$('#' + ts.id + '_info_mapping .open_table').click(function(event){
			if (self.cbFunc != null){
				// 初回以降はこのイベントは破壊される
				toggle($(event.target), true);
				self.cbFunc(self.id, "external");
			}
		});
	}

	function toggle(target, animation){
		var speed = 200;
		if (!animation){
			speed = 0;
		}
		if (target.text() == '－'){
			// close
			$('#' + ts.id + '_info_mapping .table').slideUp(speed);
			target.text('＋');
		} else {
			$('#' + ts.id + '_info_mapping .table').slideDown(speed);
			target.text('－');
		}
	}

}

InfoCommon.prototype.showCourse = function(data){
	var ts = this.div;

	var id = data.id;

	// annotation
	var contents = '<div><h4><span class="open_table">－</span> <span>Related Courses</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info course">';
	for (var i in data.courses){
		var datums = data.courses[i];
		contents += make_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.set_table_contents(contents, ts.id + '_info_course');
	$('#' + ts.id + '_info_course .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_course .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_course .table').slideDown(200);
			$(event.target).text('－');
		}
	});

	function make_tr(datum, dic){
		var label = datum.l;

		var contents = "<tr><td>";
		if (id != null){
			contents += '<div><span class="clickable res">' + datum.l +'</span><span class="hide">' + datum.id + ',course,' + id + '</span></div>';
		} else {
			contents += '<div><span class="clickable res">' + datum.l +'</span><span class="hide">' + datum.id + ',course</span></div>';
		}
		contents += "</td></tr>\n";

		return contents;
	}
}


InfoCommon.prototype.make_tr = function(datums, dic){
	var self = this;
	var label = dic[datums[0].p.value];
	if (label != null){
		label = this.get_label(label, this.lang);
	}
	if (label == null){
		label = this.get_pref(datums[0].p.value);
	}
	var contents = '';
	for (var i in datums){
		contents += "<tr><th>" + label + "</th>";
		contents += "<td>";
		var datum = datums[i];
		contents += make_tr_div(datum.o);
		var opts = datum.opt;
		if (opts != null){
			for (var i in opts){
				var opt = opts[i];
				var olabel = dic[opt.p.value];
				if (olabel != null){
					olabel = this.get_label(olabel, this.lang);
				}
				if (olabel == null){
					olabel = this.get_pref(opt.p.value);
				}
				contents += '<div class="option"><div class="head">'+olabel+"</div>";

				var opt = opts[i];
				contents += make_tr_div(opt.o);
				contents += "</div>";
			}
		}


		contents += "</td></tr>\n";
	}


	function make_tr_div(obj){
		var contents = '';
		if (obj.type == 'literal'){
			if (obj['xml:lang'] == null){
				contents += '<div>"' + self.get_link(obj.value) +'"</div>';
			} else {
				contents += '<div>"' + self.get_link(obj.value) +'"@' + obj['xml:lang'] + "</div>";
			}
		} else {
			var olabel = dic[obj.value];
			if (olabel != null){
				olabel =self.get_label(olabel, self.lang);
				contents += '<div><span class="clickable res">' + olabel +'</span><span class="hide">' + obj.value + '</span></div>';
			} else {
				contents += "<div>" + self.get_link(obj.value) +"</div>";
			}
		}
		return contents;
	}

	return contents;
}

InfoCommon.prototype.make_object_tr_blank = function(data, dic, depth, line, first){
	var ret = line;
	// 複数存在する場合でも、違いはpropertyのlangのみなので一つにまとめてよい(andの場合）
	var datum = data[0];

	if (!datum['oa'+(depth)]){
		return ret;
	}

	var label = dic[datum['oa'+(depth)].value];
	if (label != null){
		label = this.get_label(label, self.lang);
		label = '<div class="link"><span class="clickable res">' + label +'</span><span class="hide">' + datum['oa'+(depth)].value + '</span></div>';
	}

	var type = datum['ot'+(depth)].value;

	if (type.indexOf('intersectionOf') > 0){
		// AND
		if (!first){
			ret += "(";
		}
		ret += label + " and (";

		label = dic[datum['pl'+(depth+1)].value];
		if (label != null){
			label = this.get_label(label, self.lang);
		}
		if (label == null){
			label = this.get_pref(datum['pl'+(depth+1)].value);
		}
		ret += label+"　";

		label = dic[datum['op'+(depth+1)].value];
		if (label != null){
			label = this.get_label(label, self.lang);
		}
		if (label == null){
			label = this.get_pref(datum['op'+(depth+1)].value);
		}
		ret += label;

		if (datum['o'+(depth+1)].type == 'bnode'){
			ret = this.make_object_tr_blank(data, dic, depth+1, ret, false);
			ret += ")";
			if (!first){
				ret += ")";
			}
		} else {
			label = dic[datum['o'+(depth+1)].value];
			if (label != null){
				label = this.get_label(label, self.lang);
				label = '<div class="link"><span class="clickable res">' + label +'</span><span class="hide">' + datum['o'+(depth+1)].value + '</span></div>';
			}
			if (label == null){
				label = this.get_pref(datum['o'+(depth+1)].value);
			}
			ret += "　" + label + ")";

			if (!first){
				ret += ")";
			}
		}
	} else if (type.indexOf('unionOf') > 0){
		// OR
		var o = datum['o'].value;
		if (depth > 1){
			o = datum['o'+(depth)].value;
		}
		var depth_ = depth;
		for (var d = depth+1; ; d++){
			if (datum['o'+(d)]){
				if (datum['o'+(d)].value == o && datum['ot'+(d)].value.indexOf('unionOf') > 0){
					depth_ = d;
				} else {
					break;
				}
			} else {
				break;
			}
		}
		var list = [];
		var con = [];
		for (var i in data){
			datum = data[i];



			if (datum['oa'+(depth_)]){
				var or = datum['oa'+(depth_)].value;
				label = dic[datum['oa'+(depth_)].value];
				if (list.indexOf(or) < 0){
					label = this.get_label(label, self.lang);
					label = '<div class="link"><span class="clickable res">' + label +'</span><span class="hide">' + or + '</span></div>';
					con.push(label);
					list.push(or);
				}
			}
		}

		ret += "(" + con.join(" or ") + ")";
		return ret;

	}



	return ret;
}

InfoCommon.prototype.make_object_tr = function(datums, dic){


	var label = "";
	var first = true;
	if (datums[0].pl){
		label = dic[datums[0].pl.value];
		if (label != null){
			label = this.get_label(label, self.lang);
		}
		if (label == null){
			label = this.get_pref(datums[0].pl.value);
		}
		first = false;
	}
	var not = false;

	for (var i in datums){
		if (datums[i].ot1 && datums[i].ot1.value.indexOf('complementOf') > 0){
			// not
			not = true;
			break;
		}
	}
	if (not){
		label = "not　("+label;
	}

	var contents = "<tr><td>" + label;

	if (datums[0].op){
		label = dic[datums[0].op.value];
		if (label != null){
			label = this.get_label(label, self.lang);
		}
		if (label == null){
			label = this.get_pref(datums[0].op.value);
		}
		first = false;
	} else {
		label = "";
	}

	contents += "　" + label;

	var ntype = datums[0].o.type;
	if (ntype == 'bnode'){
		// TODO blank node
		return contents + "　" + this.make_object_tr_blank(datums, dic, 1, "", first) + "</td></tr>\n";
	}

	for (var i in datums){
		var datum = datums[i];
		if (datum.o.type == 'literal'){
			if (datum.o['xml:lang'] == null){
				contents += '　<div>"' + this.get_link(datum.o.value) +'"</div>';
			} else {
				contents += '　<div>"' + this.get_link(datum.o.value) +'"@' + datum.o['xml:lang'] + "</div>";
			}
		} else {
			var olabel = dic[datum.o.value];
			if (olabel != null){
				olabel = this.get_label(olabel, this.lang);
				contents += '　<div class="link"><span class="clickable res">' + olabel +'</span><span class="hide">' + datum.o.value + '</span></div>';
			} else {
				contents += "　<div>" + this.get_link(datum.o.value) +"</div>";
			}
		}
		break;
	}
	if (not){
		contents += ")";
	}
	contents += "</td></tr>\n";

	return contents;
}



InfoCommon.prototype.set_table_contents = function(contents, id){
	$('#' + id).html(contents);

	var self = this;

	$('#' + id + ' span.clickable.res').click(function(elm){
		var id = $(elm.target).next().text();

		var args = id.split(',');
		var type = null;
		if (args.length > 1){
			type = args[1];
		}

		if (args.length < 3){
			id = args[0];
		} else {
			id = [args[0], args[2]]; // process, processに関連する要素
		}
		// 該当IDの種別に応じて処理を行う。
		if (self.cbFunc != null){
			self.cbFunc(id, type);
		}
/*
		// 該当IDの種別に応じて処理を行う。
		if (self.cbFunc != null){
			self.cbFunc(id);
		}
*/
	});

	$('#' + id + '  span.clickable.outer').click(function(elm){
		var res = $(elm.target).next().text();
		for (var key in self.link_prefixes){
			res = res.replace(key, self.link_prefixes[key]);
		}
		/*
		res = res.replace('PMID:','https://www.ncbi.nlm.nih.gov/pubmed/');
		res = res.replace('Reactome:','https://reactome.org/PathwayBrowser/#/');
		res = res.replace('ISBN:','https://isbnsearch.org/isbn/');
		*/
		window.open(res, '_blank');

	});
}

InfoCommon.prototype.get_label = function(objs, l){
	return InfoCommon.get_label(objs, l);
}


InfoCommon.prototype.get_link = function(o){
	var ret = o;

	var indx = o.lastIndexOf(':');
	if (indx < 0){
		return escapeHtml(ret);
	}
	o = o.substring(0, indx+1);
//	if (o.indexOf('http://') == 0 || o.indexOf('https://') == 0 || o.indexOf('PMID:') == 0 ||  o.indexOf('Reactome:') ||  o.indexOf('ISBN:') == 0){
	if (o.indexOf('http:') == 0 || o.indexOf('https:') == 0 || this.link_prefixes[o] != null){
		ret = '<span class="clickable outer">' + ret +'</span><span class="hide">' + ret + '</span>';
	} else {
		ret = escapeHtml(ret).replace(/\n/g, '<br>');
	}
	return ret;

	function escapeHtml(str){
		  str = str.replace(/&/g, '&amp;');
		  str = str.replace(/>/g, '&gt;');
		  str = str.replace(/</g, '&lt;');
		  str = str.replace(/"/g, '&quot;');
		  str = str.replace(/'/g, '&#x27;');
		  str = str.replace(/`/g, '&#x60;');
		  return str;
		}

}


InfoCommon.prototype.get_pref = function(prop){
	var i = prop.lastIndexOf('#');
	if (i > 0){
		prop = prop.substring(i+1);
	} else {
		i = prop.lastIndexOf('/');
		if (i > 0){
			prop = prop.substring(i+1);
		}
	}
	return prop;
}


// processベースの遺伝子テーブルを作成する
InfoCommon.prototype.makeProcessGeneTable = function(data){

	var dic = {};
	var params = {};
	var items = {};
	for (var i in data){
		var datum = data[i];

		var process = datum.id;
		dic[process] = datum.l;
		var genes = datum.gene;



		for (var g in genes){
			var gene = genes[g];

			dic[gene.id] = gene.l;
			params[gene.id] = {'role':null, 'assay':null};
			var assay = null;
			if (gene.assay != null){
				for (var a in gene.assay){
					assay += gene.assay[a].l.toLowerCase();
					params[gene.id].assay = gene.assay[a].id;
					dic[gene.assay[a].id] = gene.assay[a].l;
				}
			}
			var role = [];
			if (gene.role != null){
				for (var a in gene.role){
					role = gene.role[a].id;
					params[gene.id].role = role;
					dic[role] = gene.role[a].l;
				}
			}

			var item = items[process];
			if (item == null){
				item = {'vivo': [], 'vitro':[], 'canonical':[]};
				items[process] = item;
			}

			if (assay == null || assay == ''){
				item.canonical.push(gene.id);
			} else {
				if (assay.indexOf('vivo') >= 0){
					item.vivo.push(gene.id);
				}
				if (assay.indexOf('vitro') >= 0){
					item.vitro.push(gene.id);
				}
			}
		}
	}

	var html = '<table class="tablesorter"><thead><tr><th>Process</th><th colspan=3>Canonical</th><th colspan=3>Human Gene</th><th colspan=3>Rat Gene</th></tr></thead>';
	html += '<tbody>';


	for (var process in items){
		var item = items[process];
		var vitros = item.vitro;
		var vivos = item.vivo;
		var canonicals = item.canonical;
		var rows = Math.max(1, vitros.length, vivos.length, canonicals.length);
		for (var i=0; i<rows; i++){
			html += '<tr>';
//			if (i == 0){
//				html += '<td rowspan=' + rows + '><span class="clickable res">' +label_get_before_at(dic[process]) + '</span><span class="hide">' + process + '</span></td>';
			html += '<td><span class="clickable res">' +label_get_before_at(dic[process]) + '</span><span class="hide">' + process + ',process</span></td>';
//			}
			if (i < canonicals.length){
				var v = canonicals[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
			} else {
				html += '<td></td><td></td><td></td>';
			}
			if (i < vitros.length){
				var v = vitros[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}

			} else {
				html += '<td></td><td></td><td></td>';
			}
			if (i < vivos.length){
				var v = vivos[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}

			} else {
				html += '<td></td><td></td><td></td>';
			}
			html += '</tr>';

		}


	}
	html += '</tbody>';
	html += '</table>';

	return html;
}

InfoCommon.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
}

InfoCommon.prototype.setLang = function(lang){
	this.lang = lang;

}
