/**
 * マップ表示API
 * 利用のためには別途描画ライブラリをインポートする必要がある
 */

function Map(div, options, initials){

	this.div = div[0];
	this.options = {
//			'props':{'s':'is-a', 'r':'hasResult', 'p':'has_part', 'w':'has Pathway', 'm':'has_Molecular_reaction', 'f':'hasFindings', 't':'hasParticipant', 'a':'hasAgent', 'i':'hasInput', 'o':'hasOutput'},
			'props':{'s':'is-a', 'r':'has result', 'p':'has part', 'w':'has pathway', 'm':'has molecular reaction', 'f':'has finding', 't':'has participant', 'a':'has agent', 'i':'has input', 'o':'has output'},
			'mol':false,
			'inverse': true,
			'direction': 'LR',
			'color_map': null
			};
	if (options != null){
		/*
		for (var key in options){
			this.options[key] = options[key];
		}
		*/
		this.options = Object.assign(this.options, options);

	}
	this.initials = {
			'props':'rpwmfa',
			'mol':false,
			'inverse': false,
		};

	if (initials != null){
		this.initials = Object.assign(this.initials, initials);
	}
	this.init();

}

Map.prototype.init = function(){
	var ts = this.div;
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_control_panel",
				'class' : "map_control_panel"
			}));
	/*
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_control_panel",
				'class' : "map_main_panel"
			}));
*/
	$("#"+ts.id + " .map_control_panel").append(
		$('<DIV></DIV>')
		.attr({
			'class' : "map_props"
		})
	);
	if (this.options.inverse){
		$("#"+ts.id + " .map_control_panel").append(
				$('<DIV></DIV>')
				// inverseはpending
//				.append('<input type="checkbox" name="inverse"> inverse part')
				// full screen
				.append("<input type=\"checkbox\" name=\"fullscreen\"> Full screen")
			);
		if (this.initials.inverse){
			$("#"+ts.id + " . map_control_panel input[type=checkbox]").attr('checked','checked');
		}
	} else {
		// full screen
		$("#"+ts.id + " .map_control_panel").append("<input type=\"checkbox\" name=\"fullscreen\"> Full screen")
	}


	for(var o in this.options.props){
		var visible = true;
		if (this.options.mol){
			if ('tio'.indexOf(o) >= 0){
				visible = false;
			}
		}

		var cbox = '<INPUT type="checkbox" name="view_type" value="' + o +'">' + this.options.props[o] + ' ';

		if (!visible){
			cbox = '<span class="hide"><INPUT type="checkbox" name="view_type" value="' + o +'">' + this.options.props[o] + ' </span>';
		}

		$("#"+ts.id + " .map_control_panel .map_props").append(cbox);
	}


	var self = this;


	if (this.options.mol){
		var molchk = '<INPUT type="checkbox" name="mol_chk">Molecule (';
		molchk += '<INPUT type="checkbox" name="be_type" value="canonical">canonical ';
		molchk += '<INPUT type="checkbox" name="be_type" value="human">human (';
		molchk += '<INPUT type="checkbox" name="be_type" value="human_vitro_">in vitro ';
		molchk += '(<INPUT type="checkbox" name="be_type" value="human_vitro_predicted">predicted ';
		molchk += '<INPUT type="checkbox" name="be_type" value="human_vitro">others))';
		molchk += '<INPUT type="checkbox" name="be_type" value="mouse">mouse (';
		molchk += '<INPUT type="checkbox" name="be_type" value="mouse_vivo">in vivo ';
		molchk += '<INPUT type="checkbox" name="be_type" value="mouse_vitro">in vitro)';
		molchk += '<INPUT type="checkbox" name="be_type" value="rat">rat (';
		molchk += '<INPUT type="checkbox" name="be_type" value="rat_vivo">in vivo ';
		molchk += '<INPUT type="checkbox" name="be_type" value="rat_vitro">in vitro)';
		/*
		molchk += ' | ';
		molchk += '<INPUT type="checkbox" name="mol_type" value="vivo">in vivo ';
		molchk += '<INPUT type="checkbox" name="mol_type" value="vitro">in vitro';
		*/
		molchk += ')';
		$("#"+ts.id + " .map_control_panel .map_props").append(molchk);

		if (this.initials.mol){
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type]").each(function(index, c){
				$(c).attr('checked','checked');
			});
			/*
			$("#"+ts.id + " .map_control_panel .map_props input[name=mol_type]").each(function(index, c){
				$(c).attr('checked','checked');
			});*/
			$("#"+ts.id + " .map_control_panel .map_props input[name=mol_chk]").each(function(index, c){
				$(c).attr('checked','checked');
			});
		}

	}

	$("#"+ts.id + " .map_control_panel .map_props input[name=view_type]").each(function(index, c){
		if (self.initials.props.indexOf($(c).val()) >= 0){
			$(c).attr('checked','checked');
		}
	});



	// option変更イベント
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=view_type]", 'click', function(event){
//		update_viewtype();
		if (self.updateCB != null){
			self.updateCB('option');
		}
	});

	// mol変更イベント
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=mol_chk]", 'change', function(event){
		// 自己完結する
		$("#"+ts.id + " .map_control_panel .map_props input[name=be_type]").prop('checked', this.checked);
//		$("#"+ts.id + " .map_control_panel .map_props input[name=mol_type]").prop('checked', this.checked);
		if (self.updateCB != null){
			self.updateCB('molecule');
		}
	});
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=be_type]", 'click', function(event){

		var target = $(event.target);

		if (target.val() == 'human_vitro_'){
			var val = $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_]").prop('checked');
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_predicted]").prop('checked', val);
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro]").prop('checked', val);
		}
		if (target.val().indexOf('human_vitro') >= 0){
			var val = false;
			if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_predicted]").prop('checked') ||
				 $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro]").prop('checked')){
				val = true;
			}
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_]").prop('checked', val);
		}

		if (target.val().indexOf('human_') >= 0){
			var val = false;
			if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_predicted]").prop('checked') ||
				 $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_]").prop('checked') ||
				 $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro]").prop('checked')){
				val = true;
			}
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human]").prop('checked', val);
		}
		if (target.val() == 'human'){
			var val = $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human]").prop('checked');
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_predicted]").prop('checked', val);
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro_]").prop('checked', val);
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=human_vitro]").prop('checked', val);
		}

		if (target.val().indexOf('rat_') >= 0){
			var val = false;
			if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat_vivo]").prop('checked') ||
				$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat_vitro]").prop('checked')){
				val = true;
			}
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat]").prop('checked', val);
		}
		if (target.val() == 'rat'){
			var val = $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat]").prop('checked');
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat_vivo]").prop('checked', val);
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=rat_vitro]").prop('checked', val);
		}
		if (target.val().indexOf('mouse_') >= 0){
			var val = false;
			if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse_vivo]").prop('checked') ||
				$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse_vitro]").prop('checked')){
				val = true;
			}
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse]").prop('checked', val);
		}
		if (target.val() == 'mouse'){
			var val = $("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse]").prop('checked');
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse_vivo]").prop('checked', val);
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=mouse_vitro]").prop('checked', val);
		}

		if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type]:checked").length > 0){
			$("#"+ts.id + " .map_control_panel .map_props input[name=mol_chk]").prop('checked',true);
		}


		if (self.updateCB != null){
			self.updateCB('molecule');
		}
	});
	/*
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=mol_type]", 'click', function(event){
		if (self.updateCB != null){
			self.updateCB('molecule');
		}
	});*/


	$(document).delegate("#"+ts.id + " .map_control_panel input[name=fullscreen]", 'click', function(event){
//		$("#"+ts.id).toggleClass('fullscreen');
		if (self.updateCB != null){
			var div = $("#"+ts.id);
			var val = $("#"+ts.id + " .map_control_panel input[name=fullscreen]").prop('checked');

			self.updateCB('fullscreen', [val, div]); // TODO
		}
	});

	$("#"+ts.id + " .map_control_panel").append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_find_panel",
				'class' : "map_find_panel"
			})
			.append("<input type=\"text\" name=\"findtext\" class=\"uiparts_theme textbox findtext\">" +	/* mod maeda 見栄え改善 */
					"<input type=\"button\" value=\"FIND\" name=\"find\" class=\"uiparts_theme common_button find\">" +
					"<input type=\"button\" value=\"△\" name=\"prev\" class=\"uiparts_theme next_prev_button prev\">" +
					"<input type=\"button\" value=\"▽\" name=\"next\" class=\"uiparts_theme next_prev_button next\">")
					);


	// 検索処理
	var findProc = function(){
		var findText = $("#"+ts.id + " .map_control_panel input[name=findtext]").val();
		// 同じ検索語でなければ検索をする
		if( this.nowFindText != findText ){
			self.view.clearHighlight();
			self.view.find( findText );
			this.nowFindText = findText;
		}
		// 同じ検索語であれば次に進める
		else {
			self.view.find_highlight(true);
		}
	}



	// 検索処理イベント
	$("#"+ts.id + " .map_control_panel input[name=find]").click(function(event){
		findProc();
	});
	// テキストボックスでエンターキーを押した時も同様に検索処理イベントを動かす
	$("#"+ts.id + " .map_control_panel input[name=findtext]").keypress(function(event){
		if( event.which === 13 ){
			findProc();
		}
	});

	$("#"+ts.id + " .map_control_panel input[name=prev]").click(function(event){
		self.view.find_highlight(false);
	});
	$("#"+ts.id + " .map_control_panel input[name=next]").click(function(event){
		self.view.find_highlight(true);
	});


//	$("#"+ts.id + " .map_main_panel").append('<svg id="' + ts.id + '_canvas" width=1500 height=1000></svg>');
	$(ts).append('<svg id="' + ts.id + '_canvas" class="svg_base" width=1500 height=1000></svg>');
	// safariでイベントを受け取れるようフルサイズrectを背景とする
	$("#"+ts.id + "_canvas").append(
			$('<RECT></RECT>')
			.attr({
				'width' : '100%',
				'height' : '100%',
				'fill' : '#fff',
				'pointer-events' : 'all'
			}));

	$("#"+ts.id).append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_radar",
				'class' : "radar base"
			}));

//	$("#"+ts.id+"_radar").append('<svg id="' + ts.id + '_radar_canvas"></svg>');


	this.view = new Draw(ts.id + "_canvas", this.options.direction, this.options.color_map);
	this.view.setUpdateHandler(function(param){
		if (param == 'zoom'){
			self.radar.refresh();
		} else {
			self.radar.draw();
		}
	});
	this.radar = new Radar(ts.id + "_radar", this.view);

}

Map.prototype.setUpdateHandler = function(func){
	this.updateCB = func;
}


Map.prototype.getRelationType = function(){
	var ts = this.div;
	var ret = '';
	$("#"+ts.id + " .map_control_panel .map_props input[name=view_type]:checked").each(function(){
		ret += $(this).val();
	});
	return ret;
}

// あまり適切ではないがどうすべきか
Map.prototype.adjust = function(){
	if (!this.options.mol){
		return false;
	}
	var ts = this.div;
	var types = ['human', 'rat', 'mouse'];
	var ret = [];
	$("#"+ts.id + " .map_control_panel .map_props input[name=be_type]:checked").each(function(){
		var hit = false;
		for (var i in ret){
			var temp = ret[i];
			if ($(this).val().indexOf(temp) >= 0){
				ret[i] = $(this).val();
				hit = true;
				break;
			}
		}
		if (!hit){
			if (ret.indexOf($(this).val()) < 0){
				if (types.indexOf($(this).val()) < 0){
					ret.push($(this).val());
				}
			}
		}
	});

	// rat チェックありで　rat_vivo rat_vitro　いずれにもチェックがない場合、rat_vivo,rat_vitroを追加
	// mouse チェックありで　mouse_vivo mouse_vitro　いずれにもチェックがない場合、mouse_vivo,mouse_vitroを追加
	for (var i in types){
		var type = types[i];

		if ($("#"+ts.id + " .map_control_panel .map_props input[name=be_type][value=" + type +"]").prop('checked')){
			var only = true;
			$("#"+ts.id + " .map_control_panel .map_props input[name=be_type]").each(function(){
				if ($(this).val() != type && $(this).val().indexOf(type) == 0 && $(this).prop('checked')){
//					ret.push($(this).val());
					only = false;
				}
			});
			if (only){
				$("#"+ts.id + " .map_control_panel .map_props input[name=be_type]").each(function(){
					if ($(this).val().indexOf(type) == 0){
						ret.push($(this).val());
					}
				});
			}

		}

	}

	/*
	$("#"+ts.id + " .map_control_panel .map_props input[name=mol_type]:checked").each(function(){
		if (ret.indexOf($(this).val()) < 0){
			ret.push($(this).val());
		}
	});*/

	var val = false;
	// 一つでもmoleculeにチェックがあればhas agentにチェックを入れる
	if (ret.length > 0){
		if (!$("#"+ts.id + " .map_control_panel .map_props input[name=view_type][value=a]")[0].checked){
			$("#"+ts.id + " .map_control_panel .map_props input[name=view_type][value=a]")[0].checked = true;
			val = true;
		}
	}

	// molの表示非表示チェックに合わせてノードの表示非表示を変更する
	this.view.viewNode(['human','mouse','rat', 'predicted', 'vitro', 'vivo', 'canonical'], ret);

	return val;
}

Map.prototype.setMapData = function(data, clear){
	var ts = this.div;
	if (clear){
		$('#'+ ts.id + ' .map__find_panel input[type=text]').val('');
	}

	this.mapData = data;
	this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);
}

Map.prototype.findWord = function(word){
	var ts = this.div;
	selectedIndex = 0;
	if (word == ''){
		this.clearHighlight();
		this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	highlightedIds = recurseFind(word, highlightedIds, this.mapData.rootNode, nodes);

	function recurseFind(word, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if ((node.name).indexOf(word) >= 0){
			var expects = ['@', '＠'];
			var hit = true;
			for (var i in expects){
				if ((node.name).indexOf(expects[i]) >= 0 && (node.name).indexOf(expects[i]) < (node.name).indexOf(word)){
					hit = false;
					break;
				}
			}
			if (hit){
				if (ids.indexOf(node.id) < 0){
					ids.push(node.id);
				}
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(word, ids, node.children[i], nodes);
		}
		return ids;

	};

	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
}

Map.prototype.findID = function(id, findOnly){
	if (findOnly == null){
		findOnly = false;
	}
	if (!findOnly){
		this.view.clearHighlight();
	}
	return this.view.find(id, findOnly);
	/*
	var ts = this.div;
	selectedIndex = 0;
	this.clearHighlight();
	if (id == ''){
		this.viewMap(ts.id + "_main", this.mapData, this.cbFunc);

		return;
	}
	highlightedIds = [];
	nodes = [];

	highlightedIds = recurseFind(id, highlightedIds, this.mapData.rootNode, nodes);

	function recurseFind(id, ids, node, nodes){
		// すでにチェック済みの場合はそのまま返す
		if (nodes.indexOf(node) >= 0){
			return ids;
		}
		nodes.push(node);

		if (node.resource == id){
			if (ids.indexOf(node.id) < 0){
				ids.push(node.id);
			}
		}

		for (var i=0; i<node.children.length; i++){
			recurseFind(id, ids, node.children[i], nodes);
		}
		return ids;

	};

	this.highlight(highlightedIds, true);
	if (highlightedIds.length != 0){
		this.focusHighlight(selectedIndex);
	}
	*/
}

Map.prototype.focusHighlight = function(index){
	var ts = this.div;
	if (index == 0){
		$('#' + ts.id + ' .map_find_panel input[name=prev]').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .map_find_panel input[name=prev]').removeAttr('disabled');
	}

	if (index == (highlightedIds.length-1)){
		$('#' + ts.id + ' .map_find_panel input[name=next]').attr('disabled', 'disabled');
	} else {
		$('#' + ts.id + ' .map_find_panel input[name=next]').removeAttr('disabled');
	}

	this.focusNode(highlightedIds[selectedIndex]);

	setClassToNode(highlightedIds[selectedIndex], 'select');

}

Map.prototype.highlight = function(id, isHighlight){
	var ts = this.div;
	this.clearHighlight();
	var ids = [];
	if (id instanceof Array){
		ids = id;
	} else {
		ids.push(id);
	}

	if (this.mapData != null){
		for (var i=0; i<ids.length; i++){
			this.mapData.highlight(ids[i], isHighlight);
		}
	}

	this.viewMap(ts.id + "_main", this.mapData, cbFunc);

}

Map.prototype.clearHighlight = function(){
	if (this.mapData != null){
		this.mapData.highlightClear();
	}
}

Map.prototype.focusNode = function(id){
	var ts = this.div;
	$('#' + ts.id + '_main').animate({
//		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - 400)
		scrollTop:$('#' + ts.id + '_main').scrollTop() + ($('#' + id).position().top - ($('#' + ts.id + '_main').position().top + 150))
	});
	if (ts.highlightCb != null){
		ts.highlightCb(id);
	}
}

Map.prototype.onFocusHighlighted = function(cb){
	var ts = this.div;
	ts.highlightCb = cb;
},


Map.prototype.viewMap = function(id, data, cb){
	this.view.setData(data);

	this.radar.draw();
}

Map.prototype.onNodeClicked = function(func, right_func){
	this.view.setClickHandler(func, right_func);
}


Map.prototype.setContextMenu = function(context){
	/*
	this.view.node_rightclick_event = function(d, obj){
		popup.bind(obj);
		popup.show();
	};
	*/
	this.view.setContextMenu(context);
}
