/**
 * 検索入力表示API
 */

function SearchInput(div, options, initials, lang){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

SearchInput.prototype.init = function(){
	var ts = this.div;
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "search_panel"
			}));
/*
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_control_panel",
				'class' : "map_main_panel"
			}));
*/
	/*
	<div class="search_panel">
		<div>
			<span>×</span>
			<select size="1"><option>Process</option><option>Course</option><option>Molecule</option><option>Observation</option></select>
			<input type="text">
			<select size="1"><option>Partial Match</option><option>Full Match</option></select>
			<select size="1"><option>Contains Parents</option><option>Contains Siblings</option><option>Only Myself</option></select>
		</div>
		<div>
			<span>×</span>
			<select size="1"><option>Process</option><option>Course</option><option>Molecule</option><option>Observation</option></select>
			<input type="text">
			<select size="1"><option>Partial Match</option><option>Full Match</option></select>
			<select size="1"><option>Contains Parents</option><option>Contains Siblings</option><option>Only Myself</option></select>
		</div>
	</div>
	<input type="button" value="ADD">
	<input type="button" value="FIND">
*/

	$(ts).append('<input type="button" name="find" value="FIND" class="uiparts_theme common_button">');

	var self = this;

	this.data = new Search(base_url, this.lang);
	/*
	this.data.findRemarkList(function(data){
		self.setSuggestRemarkData(data);
	});*/


	this.addCondition('Course', 'c', true, false);
	this.addCondition('Process', 'p', true, true);
	this.addCondition('Molecule/Compound', 'm', false, false);
	this.addCondition('Role', 'r', false, false, true);
	this.addCondition('Finding', 'f', false, false, true);
	this.addCondition('Structure', 's', false, false, true);
	this.addCondition('Quarity', 'q', false, false, true);

	$(document).on('click', "#"+ts.id + " .search_panel .search_condition.c input[type=text]", function(event){
		// TODO select typeによって挙動を変える
		var type = $(event.target.previousElementSibling.previousElementSibling).val();
		/* これはtype選択時にautocomplete登録
		if (type == 'Molecule'){
			// 分子サジェスト
		} else if (type == 'finding'){
			// 所見サジェスト
		} else
		*/
		if (type == 'c'){
			// 作用機序ツリーサジェスト
			view_suggesttree(event);
		}
	});

	$(document).on('click', "#"+ts.id + " .search_panel .search_condition input[type=text]", function(event){
		var type = $(event.target.previousElementSibling.previousElementSibling).val();
//		$(event.target.nextElementSibling).val(''); // 入力欄をクリア
		$("#"+ts.id + " .search_panel .search_condition input[type=text]").autocomplete({
	        source: [],
	        autoFocus: true,
	        delay: 200,
	        minLength: 2
		});
		var t = null;
		if (type == 'f'){
			t = 'f';
		}
		if (type == 'm'){
			t = 'm';
		}
		if (type == 'r'){
			t = 'r';
		}
		if (type == 's'){
			t = 's';
		}
		if (type == 'q'){
			t = 'q';
		}
		if (type != 'c'){
			hide_suggesttree();
		}
		if (t != null){
			// サジェスト
			$("#"+ts.id + " .search_panel .search_condition input[type=text]").autocomplete({
//		        source: self.remark_list,
				source : self.data.getSuggestFunc(t),
		        autoFocus: true,
		        delay: 200,
		        minLength: 0
		    });
		}

	});

	$(document).on('click', "#"+ts.id + " .search_panel .search_condition input[type=button]", function(event){
		var text = $(event.target.previousElementSibling.previousElementSibling.previousElementSibling);
		$(text).val('');

		text.click();
		text.focus();
		var event = $.Event('keydown');
		event.keyCode = 8;
		text.trigger(event);
	});


	$(document).on('change', "#"+ts.id + " .search_panel .search_condition input[name=valid]", function(event){
		var checked = $(event.target).prop('checked');
		var a = checked;
		// TODO チェックが外れた項目は編集できなくする

	});


	$('#' + ts.id + ' input[name=find]').click(function(event){
		self.do_find();
	});



	var target = null;
	// サジェスト用作用機序ツリー生成
	function make_suggesttree(ts){
		$(ts).append(
				$('<DIV></DIV>')
				.attr({
					'id' : ts.id + "_suggest_tree",
					'class' : "hide"
				}));
		self.suggesttree = new Tree($('#' + ts.id+ '_suggest_tree'));
		self.suggesttree.onNodeClicked(function(tid){
			var t = self.suggesttree.getNodeData(tid);
			self.suggesttree.findID(t.resource);
			self.id = t.resource;
			if (target != null){
				$(target).val(t.name);
				target = null;
				$('#' + ts.id + '_suggest_tree').addClass('hide');

			}

		});
	}
	function view_suggesttree(event){
		target = event.target;
		// TODO tree以外触れなくする
		$('#' + ts.id + '_suggest_tree').removeClass('hide');
	}

	function hide_suggesttree(){
		$('#' + ts.id + '_suggest_tree').addClass('hide');
	}

	make_suggesttree(ts);

	/*

	$("#"+ts.id + " .map_control_panel .map_props input[name=view_type]").each(function(index, c){
		if (self.initials.props.indexOf($(c).val()) >= 0){
			$(c).attr('checked','checked');
		}
	});


	// TODO option変更イベント
	$(document).delegate("#"+ts.id + " .map_control_panel .map_props input[name=view_type]", 'click', function(event){
//		update_viewtype();
		if (self.updateCB != null){
			self.updateCB();
		}
	});


	$("#"+ts.id + " .map_control_panel").append(
			$('<DIV></DIV>')
			.attr({
//				'id' : ts.id + "_find_panel",
				'class' : "map_find_panel"
			})
			.append("<input type=\"text\" name=\"findtext\"><input type=\"button\" value=\"FIND\" name=\"find\">" +
					"<input type=\"button\" value=\"△\" name=\"prev\"><input type=\"button\" value=\"▽\" name=\"next\">")
					);

	// 検索処理イベント
	$("#"+ts.id + " .map_control_panel input[name=find]").click(function(event){
		self.view.clearHighlight();
		self.view.find($("#"+ts.id + " .map_control_panel input[name=findtext]").val());
	});
	$("#"+ts.id + " .map_control_panel input[name=prev]").click(function(event){
		self.view.find_highlight(false);
	});
	$("#"+ts.id + " .map_control_panel input[name=next]").click(function(event){
		self.view.find_highlight(true);
	});


//	$("#"+ts.id + " .map_main_panel").append('<svg id="' + ts.id + '_canvas" width=1500 height=1000></svg>');
	$(ts).append('<svg id="' + ts.id + '_canvas" width=1500 height=1000></svg>');
	// safariでイベントを受け取れるようフルサイズrectを背景とする
	$("#"+ts.id + "_canvas").append(
			$('<RECT></RECT>')
			.attr({
				'width' : '100%',
				'height' : '100%',
				'fill' : '#fff',
				'pointer-events' : 'all'
			}));
	this.view = new Draw(ts.id + "_canvas", this.options.direction);
*/
}

SearchInput.prototype.setEventHandler = function(handler){
	this.handler = handler;
}

SearchInput.prototype.do_find = function(){
	this.cbShowIndicator();
	var ts = this.div;
	// TODO 検索処理実行
	// 検索条件から条件文字列を生成する
	// 結果もこのObject内で処理する？
	var queries = [];
	var checks = $('#'+ts.id+" .search_panel .search_condition input[name=valid]");
	var types = $('#'+ts.id+" .search_panel .search_condition input[name=type]");
	var words = $('#'+ts.id+" .search_panel .search_condition input[name=find_detail]");
	var matches = $('#'+ts.id+" .search_panel .search_condition select[name=match]");
	var targets = $('#'+ts.id+" .search_panel .search_condition select[name=target]");

	var t = [];
	for (var i=0; i<$(types).length; i++){
		if ($(checks[i]).prop('checked')){
			queries.push("tp="+$(types[i]).val()+",w="+$(words[i]).val()+",m="+$(matches[i]).val()+",t="+$(targets[i]).val());
			t.push($(types[i]).val());
		}
	}
	if (queries.length == 0){
		// チェックなし
		this.cbHideIndicator();
		return;
	}

	var self = this;

	if (self.handler != null){
		$('#' + ts.id + '_suggest_tree').addClass('hide');
		self.handler('find',queries);
	}


	this.find(queries, function(result){
		if (self.handler != null){
			self.handler('all_result', result, t);
		}
		self.cbHideIndicator();
	}, t);

}


SearchInput.prototype.find = function(queries, handler, t){
	var self = this;

	var keys = ['tp=c', 'tp=p'];
	var queries_addition = null;

//	if (!(queries.length == 1 && (queries[0].indexOf('tp=p') >= 0) || queries[0].indexOf('tp=c') >= 0)){
	if (queries.length == 1 && (queries[0].indexOf('tp=p') < 0) && queries[0].indexOf('tp=c') < 0){
		if (queries.length == 1){
			queries_addition = [queries[0]];
		}

		for (var i in keys){
			var key = keys[i];
			var exists = false;
			for (var i=0; i<queries.length; i++){
				var query = queries[i];
				if (query.indexOf(key) >= 0){
					exists = true;
					break;
				}
			}
			if (!exists){
				queries.push(key);
			}
		}
	}

	if (queries_addition == null){
		find_(queries, function(result){
			handler(result,t);
		}, t);
	} else {
		find_(queries, function(result){
			find_(queries_addition, function(res, result){
				result = merge_result(result, res, t);
				handler(result,t);
			}, result, t);
		}, t);
	}


	function merge_result(result, additions, t){
		for (var i in additions){
			var add = additions[i];
			var id = add[t+'s'];
			if (id != null){
				id = id.value;
			}
			var exists = false;
			for (var j in result){
				var tmp = result[j];
				if (tmp[t+'s'] != null && id == tmp[t+'s'].value){
					exists = true;
					break;
				}
			}
			if (!exists){
				result.push(add);
			}
		}
		return result;
	}

	function find_(queries, handler_, args){
		self.data.find(queries, function(result){
			if (handler_ != null){
				handler_(result, args);
			}
		}, args, function(result){
			if (handler_ != null){
				handler_(result, args);
			}
		});
	}

}

SearchInput.prototype.find_all = function(word){
	// course, process, role, molecule, finding, structure について順にword検索
	var types = [{'type':'c', 'name':'course'},{'type':'p', 'name':'process'},{'type':'r', 'name':'role'},
	             {'type':'m', 'name':'molecule'},{'type':'f', 'name':'finding'},{'type':'s', 'name':'structure'},{'type':'q', 'name':'quarity'}];

	var self = this;
	var ts = this.div;

	if (self.handler != null){
		$('#' + ts.id + '_suggest_tree').addClass('hide');
//		self.handler('find',queries);
	}

	word = encodeURIComponent(word);

	this.cbShowIndicator();
	var counter = 0;
	for (var i in types){
		var type = types[i];
		var queries = ['tp='+ type.type+",w="+word];
		counter++;
		this.find(queries, function(result, type){
			self.handler('part_result', result, type);
			counter--;
			if( 0 == counter ){
				self.cbHideIndicator();
			}
		}, type.type, type.type);
	}
	/* 応答がない時の対策として60秒後には読み込み中画面を消すようにする */
	setTimeout( function() {
		self.cbHideIndicator();
	}, 60000 );
}


/**
 * サジェスト用ツリーデータの中身設定
 * @param result
 */
SearchInput.prototype.setSuggestTreeData = function(result){
	this.suggesttree.setTreeData(result, true);
}

/**
 * サジェスト用所見データの中身設定
 */
SearchInput.prototype.setSuggestRemarkData = function(list){
	this.remark_list = [];

	for (var i in list){
		var datum = list[i];
		this.remark_list.push(datum.rl.value);
	}
	// TODO update type
}


SearchInput.prototype.addCondition = function(name, type, check, withParents, showList){
	var ts = this.div;

	var content =
		'<div class="search_condition ' + type + '">\n'+
		'<input type="checkbox" name="valid" ' + (check ? ' checked="checked"' : '') + '>\n'+
		'<input type="hidden" name="type" value="' + type + '"><span>' + name + '</span>\n'+
		'<input type="text" name="find_detail" class="uiparts_theme textbox">\n'+
		'<select size="1" name="match" class="uiparts_theme common_button"><option value="part">Partial Match</option><option value="full">Full Match</option></select>\n';
	if (withParents){
		content += '<select size="1" name="target" class="uiparts_theme common_button"><option value="myself">---</option><option value="parent">Contains Parents</option><option value="sibling">Contains Siblings</option></select>\n';
	} else {
		content += '<select size="1" name="target" class="hide uiparts_theme common_button"><option value="myself">---</option></select>\n';
	}
	if (showList){
		content += '<input type="button" value="LIST" class="uiparts_theme common_button">\n';
	}

	content += '</div>';

	$('#'+ts.id+" .search_panel").append(content);

}

SearchInput.prototype.removeCondition = function(index){
	var ts = this.div;
	if ($("#"+ts.id + " .search_panel .search_condition").length >= index){
		$($("#"+ts.id + " .search_panel .search_condition")[index]).remove();
	}
}

SearchInput.prototype.setLang = function(lang){
	this.lang = lang;
	this.data.setLang(lang);
}

