/**
 * 概念情報表示API
 * TODO annnotation限定ではないため名前を変更すべき
 */

function InfoAnnotation(div, lang, initials){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

InfoAnnotation.prototype.init = function(){
	var ts = this.div;

	// TODO info_annotationは複数表示されることもありうる
	//　IDの固有性についてはこちらではなく親にて保証する

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_panel"
			}));


	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_head'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_annotation'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_equivalent'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_object'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_inherit'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_mapping'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_course'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_process'
			}));


	this.common = new InfoCommon(this.div, this.lang);

}




InfoAnnotation.prototype.show = function(data){
	var ts = this.div;

	this.common.showHead(data);
	this.common.showAnnotation(data);
	this.common.showEquivalent(data);
	this.common.showObject(data);
	this.common.showInheritObject(data);
	this.common.showMapping(data);
	if (data.genes == null || data.genes.length == 0){
		this.common.showCourse(data);
		this.showProcess(data);
	} else {
		var crses = this.pickupCourses(data);
		crses.dic = data.dic;

		this.common.showCourse(crses);
		this.showProcess(crses);

	}



	$(this.div).show();

//	return ret;
}

InfoAnnotation.prototype.show_external = function(data){
	this.common.showMapping(data);
}


InfoAnnotation.prototype.pickupCourses = function(data){
	var ret = {'courses':[], 'processes':[]};
	var tmp_course = [];
	var tmp_process = [];
	if (data.genes == null){
		return ret;
	}
	for (var key in data.genes){
		var gene = data.genes[key];

		// course
		var courses = gene.course;
		for (var i in courses){
			if (tmp_course.indexOf(courses[i].id) < 0){
				ret.courses.push(courses[i]);
				tmp_course.push(courses[i].id)
			}
		}

		// process
		if (tmp_process.indexOf(gene.id) < 0){
			ret.processes.push({'id':gene.id, 'l':gene.l});
			tmp_process.push(gene.id)
		}
	}
	return ret;
}

InfoAnnotation.prototype.showProcess = function(data){
	var ts = this.div;

	// annotation
	var contents = '<div><h4><span class="open_table">－</span> <span>Related Processes</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info course">';
	for (var i in data.processes){
		var datums = data.processes[i];
		contents += make_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.common.set_table_contents(contents, ts.id + '_info_process');
	$('#' + ts.id + '_info_process .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_process .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_process .table').slideDown(200);
			$(event.target).text('－');
		}
	});

	function make_tr(datum, dic){
		var label = datum.l;

		var contents = "<tr><td>";
		contents += '<div><span class="clickable res">' + datum.l +'</span><span class="hide">' + datum.id + ',process</span></div>';
		contents += "</td></tr>\n";

		return contents;
	}
}



InfoAnnotation.prototype.onNodeClicked = function(func){
	this.cbFunc = func;

	this.common.onNodeClicked(func);

}

InfoAnnotation.prototype.setLang = function(lang){
	this.lang = lang;
	this.common.setLang(lang);

}

