/**
 * プロセス情報表示API
 */

function InfoProcess(div, lang, initials){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

InfoProcess.prototype.init = function(){
	var ts = this.div;

	// TODO info_annotationは複数表示されることもありうる
	//　IDの固有性についてはこちらではなく親にて保証する

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_panel"
			}));


	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_head'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_annotation'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_equivalent'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_object'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_inherit'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_course'
			}));

	this.common = new InfoCommon(this.div, this.lang);

}



InfoProcess.prototype.show = function(data){
	var ts = this.div;

	this.common.showHead(data);
	this.common.showAnnotation(data);
	this.common.showEquivalent(data);
	this.common.showObject(data);
	this.common.showInheritObject(data);

	this.common.showCourse(data);



	$(ts).show();

}
/*
InfoProcess.prototype.showCourse = function(data){
	var ts = this.div;

	// annotation
	var contents = '<div><h4><span class="open_table">－</span> <span>Related Courses</span></h4></div>' + "\n";
	contents += '<div class="table"><table class="info course">';
	for (var i in data.courses){
		var datums = data.courses[i];
		contents += this.make_tr(datums, data.dic);
	}
	contents += "</table></div>\n";
	this.common.set_table_contents(contents, ts.id + '_info_course');
	$('#' + ts.id + '_info_course .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_course .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_course .table').slideDown(200);
			$(event.target).text('－');
		}
	});
}
*/

InfoProcess.prototype.make_tr = function(datum, dic){
	var label = datum.l;

	var contents = "<tr><td>";
	contents += '<div><span class="clickable res">' + datum.l +'</span><span class="hide">' + datum.id + '</span></div>';
	contents += "</td></tr>\n";

	return contents;
}

InfoProcess.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
	this.common.onNodeClicked(func);
}

InfoProcess.prototype.setLang = function(lang){
	this.lang = lang;
	this.common.setLang(lang);

}

