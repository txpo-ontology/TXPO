/**
 * ロール情報表示API
 * TODO annotationと分離する必要はある？
 * 渡されたデータによって区別すればよいのでは
 */

function InfoRole(div, lang, initials){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

InfoRole.prototype.init = function(){
	var ts = this.div;

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_panel"
			}));


	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_head'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_annotation'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_equivalent'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_object'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_inherit'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_mapping'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_course'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_pgene'
			}));
	this.common = new InfoCommon(this.div, this.lang);

}



InfoRole.prototype.show = function(data){
	var ts = this.div;

	this.common.showHead(data);
	this.common.showAnnotation(data);
	this.common.showEquivalent(data);
	this.common.showObject(data);
	this.common.showInheritObject(data);
	this.common.showMapping(data);

	// プロセス-遺伝子
	var contents = '<div><h4><span class="open_table">－</span> <span>Related Processes</span></h4></div>' + "\n";
	contents += '<div class="table">';
	if (data.genes != null){
		contents += this.makeGeneTable(data.id, data.genes);
	}
	contents += '</div>';
	this.common.set_table_contents(contents, ts.id + '_info_pgene');
	var $table = $('#' + ts.id+ '_info_pgene table');
	$table.tablesorter();

	$('#' + ts.id + '_info_pgene .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_pgene .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_pgene .table').slideDown(200);
			$(event.target).text('－');
		}
	});

	$(ts).show();


}

InfoRole.prototype.show_external = function(data){
	this.common.showMapping(data);
}

// moleculeベースのテーブルを作成する
InfoRole.prototype.makeGeneTable = function(id, data){

	var dic = {};
	var items = {};
	for (var i in data){
		var datum = data[i];

		var process = datum.id;
		dic[process] = datum.l;
		var genes = datum.gene;

		for (var g in genes){
			var gene = genes[g];
			/*
			if (gene.id != id){
				continue;
			}*/

			dic[gene.id] = gene.l;
			var assay = null;
			if (gene.assay != null){
				for (var a in gene.assay){
					assay += gene.assay[a].l.toLowerCase();
				}
			}
			/*
			var role = [];
			if (gene.role != null){
				for (var a in gene.role){
					dic[gene.role[a].id] = gene.role[a].l;
					role.push(gene.role[a].id);
				}
			}*/


			var item = items[process];
			if (item == null){
				item = {'type': [], 'gene':[gene.id]};
				items[process] = item;
			} else {
				item.gene.push(gene.id);
			}

			if (assay == null || assay == ''){
				item.type.push("Canonical");
			} else {
				if (assay.indexOf('vivo') >= 0){
					item.type.push("Rat Gene");
				}
				if (assay.indexOf('vitro') >= 0){
					item.type.push("Human Gene");
				}
			}
		}
	}

	var html = '<table class="tablesorter"><thead><tr><th>Process</th><th>Gene</th><th>Type</th></tr></thead>';
	html += '<tbody>';
	for (var process in items){
		var item = items[process];
		var types = item.type;
		var genes = item.gene;

		types = Object.values(types).map(function(v){
			return '<span>' + v + '</span>';
		}).join(',');
		genes = Object.values(genes).map(function(v){
			return '<span class="clickable res">' + dic[v] + '</span><span class="hide">' + v + '</span>';
		}).join(',');

		html += '<tr>';
		html += '<td><span class="clickable res">' +dic[process] + '</span><span class="hide">' + process + ',process,' + id + '</span></td>';
		html += '<td>' +genes + '</td>';
		html += '<td>' +types + '</td>';
		html += '</tr>';
	}
	html += '</tbody>';
	html += '</table>';

	return html;
}


InfoRole.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
	this.common.onNodeClicked(func);
}

InfoRole.prototype.setLang = function(lang){
	this.lang = lang;
	this.common.setLang(lang);

}
