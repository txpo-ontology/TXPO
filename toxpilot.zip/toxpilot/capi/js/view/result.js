/**
 * 検索結果表示API
 */

function SearchResult(div, base_url, initials, lang){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

/*
	this.words = {
			'c':{'ja':'作用機序', 'en':'Toxic Course'},
			'p':{'ja':'プロセス', 'en':'Process'},
			'm':{'ja':'分子', 'en':'Molecule'},
			'r':{'ja':'ロール', 'en':'Role'},
			'f':{'ja':'所見', 'en':'Finding'},
			's':{'ja':'構造', 'en':'Structure'}
			};
			*/
	this.words = {
			'c':'course',
			'p':'process',
			'm':'molecule',
			'r':'role',
			'f':'finding',
			's':'structure',
			'q':'quarity'
			};

	// 結果をクリックされたときにどの画面に飛ぶか
	this.types = {
			'c':'course',
			'p':'process',
			'm':'ontology',
			'r':'ontology',
			'f':'ontology',
			's':'ontology',
			'q':'ontology'
			};


	this.strings();

	this.init(base_url);

}

SearchResult.prototype.init = function(endpoint){
	var ts = this.div;


	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_div"
			}));


	$("#" + ts.id + " .result_div").append(
			'<DIV id="' + ts.id + '_process" class="result_tree"></DIV>'
			);
	$("#" + ts.id + " .result_div").append(
			'<DIV id="' + ts.id + '_table"></DIV>'
			);
	var self = this;

}

SearchResult.prototype.hide = function(){
	$(this.div).hide();

}


SearchResult.prototype.show = function(result, types){
	var ts = this.div;
	// データ種別によって分岐

	var self = this;


	if (types.length == 1){
		// 一種類
		var type = types[0];

		if (type.indexOf('p') == 0){
			single_process(result);
		} else {
			single_table(result, type);
		}

		this.setLang(this.lang);

		$(this.div).show();

		return;
	}

	function single_process(result){

		// TODO この辺の処理は全く整理できていない
		var ancestors = {};
		var dic = {};
		for (var i in result){
			// ancestorの集計
			var datum = result[i];
/*
			var k = "_";
			if (datum.pl['xml:lang'] != null && datum.pl['xml:lang'] != ''){
				k = datum.pl['xml:lang'];
			}
			if (dic[datum.p.value] == null){
				dic[datum.p.value] = {};
			}
			*/
			self.addDic(dic, datum.p.value, datum.pl);
//			dic[datum.p.value][k] = datum.pl.value;
			if (ancestors[datum.p.value] == null){
				ancestors[datum.p.value] = [];
			}
			var list = ancestors[datum.p.value];
			if (list.indexOf(datum.a.value) < 0){
				list.push(datum.a.value);
			}
		}
		var keys = [];
		for (var key in ancestors){
			if (keys.indexOf(key) < 0){
				keys.push(key);
			}
		}

		for (var key in ancestors){
			var list = ancestors[key];
			var newList = [];
			for (var i in keys){
				var k = keys[i];
				if (list.indexOf(k) >= 0){
//					list.splice(list.indexOf(key), 1);
					newList.push(k);
				}
			}
			ancestors[key] = newList;
		}

		var tmp = {};
		for(var d=0;;d++){
			var hit = false;

			for (var key in ancestors){
				var list = ancestors[key];
				if (list.length > 0){
					hit = true;
					var item = list[0];
					list.shift();
					if (tmp[key] == null){
						tmp[key] = {depth:-1};
					}
					if (tmp[item] == null){
						tmp[item] = {depth:-1};
					}
					tmp[item][key] = tmp[key];
				}
			}
			if (!hit){
				break;
			}
		}
		for (var key in ancestors){
			if (tmp[key] == null){
				tmp[key] = {depth:0};
			}
		}

		set_depth(tmp);

		function set_depth(ans, depth){
			if (depth == null){
				depth = 0;
			}
			for (var key in ans){
				var an = ans[key];
				if (!isNaN(an)){
					continue;
				}
				if (an.depth < depth){
					an.depth = depth;
				}
				set_depth(an, depth+1);
			}
		}

		var contents = '<table class="tablesorter"><thead><tr>';
		contents += '<th><span class="text_result_' + self.words['p'] + '"></span></th></tr></thead>\n<tbody>\n';
		for (var key in tmp){
			 var item = tmp[key];

			 if (item.depth != 0){
				 continue;
			 }

			 contents += make_list(contents, item, key);

		}
		 contents += "</tbody></table>\n";

		function make_list(contents, ans, key, depth){
			var ret = '';
			if (depth == null){
				depth = 0;
			}
			ret += '<tr><td><span class="clickable res">';
			for (var i=0; i<depth; i++){
				ret += "　";
			}

			/*
			var word = dic[key][self.lang];
			if (word == null){
				word = dic[key]['_'];
			}*/

			ret += self.getDic(dic, key) + '</span><span class="hide">' + key + ",process</td></tr>\n";
			for (var k in ans){
				var an = ans[k];
				if (!isNaN(an)){
					continue;
				}
				ret += make_list(ret, an, k, depth+1);
			}
			return ret;
		}

		$('#' + ts.id+ '_table').show();
		$('#' + ts.id+ '_table').html(contents);
		var table = $('#' + ts.id+ '_table table');
		table.tablesorter();

		$('#' + ts.id+ '_table span.clickable.res').click(function(elm){
			var id = $(elm.target).next().text();
			var args = id.split(',');
			var type = args[1];

			if (args.length < 3){
				id = args[0];
			} else {
				id = [args[0], args[2]];
			}
			// 該当IDの種別に応じて処理を行う。
			if (self.cbFunc != null){
				self.cbFunc(id, type);
			}

		});

	}


	function single_table(result, type){
		var skeys = ['c', 'm','r','f','s', 'q'];
		var skey = null;
		var lkey = null;
//		var name = null;
		for (var i in skeys){
			if (type == skeys[i]){
				skey = skeys[i] + 's';
				lkey = skeys[i] + 'l';
				break;
			}
		}
		if (skey != null){
//			name = self.words[type];

			var rmap = {};
			var dic = {};
			for (var i in result){
				var datum = result[i];
				var item = null;
				self.addDic(dic, datum[skey].value, datum[lkey]);
				if (rmap[datum[skey].value] == null){
					item = {'c':[], 'p':[]};

/*
					var k = "_";
					if (datum[lkey]['xml:lang'] != null && datum[lkey]['xml:lang'] != ''){
						k = datum[lkey]['xml:lang'];
					}
					if (dic[datum[skey].value] == null){
						dic[datum[skey].value] = {};
					}
					dic[datum[skey].value][k] = datum[lkey].value;
					*/



//					dic[datum[skey].value] = datum[lkey].value;
					rmap[datum[skey].value] = item;
				} else {
					item = rmap[datum[skey].value];
				}
				if (datum.cs != null){
					var c = datum.cs.value;
					self.addDic(dic, c, datum.cl);
					if (item.c.indexOf(c) < 0){
						/*
						var k = "_";
						if (datum.cl['xml:lang'] != null && datum.cl['xml:lang'] != ''){
							k = datum.cl['xml:lang'];
						}
						if (dic[c] == null){
							dic[c] = {};
						}
//						dic[c] = datum.cl.value;
						dic[c][k] = datum.cl.value;
						*/

						item.c.push(c);
					}
				}
				if (datum.p != null){
					var p = datum.p.value;
/*
					var k = "_";
					if (datum.pl['xml:lang'] != null && datum.pl['xml:lang'] != ''){
						k = datum.pl['xml:lang'];
					}
					if (dic[p] == null){
						dic[p] = {};
					}


					dic[p][k] = datum.pl.value;
					*/
					self.addDic(dic, p, datum.pl);


					self.addDic(dic, p, datum.pl);
					if (item.p.indexOf(p) < 0){
//						dic[p][k] = datum.pl.value;
						item.p.push(p);
					}
				}
			}

			var html = '<table class="tablesorter"><thead><tr>';
			html += '<th><span class="text_result_' + self.words[type] + '"></span></th>';
			if (type != 'c'){
				// 作用機序単体以外の場合は作用機序とプロセスのセットを追加
				html += '<th><span class="text_result_' + self.words.c + '"></span></th>';
				html += '<th><span class="text_result_' + self.words.p + '"></span></th>';
			}
			html += "</tr></thead>\n<tbody>\n";


			for (var key in rmap){
				var datum = rmap[key];
				html += "<tr>";
/*
				var word = dic[key][self.lang];
				if (word == null){
					word = dic[key]['_'];
				}
*/
				html += '<td><span class="clickable res">' + self.getDic(dic, key) + '</span><span class="hide">' + key + "," + self.types[type] + "</span></td>";// 作用機序
				if (type!= 'c'){
					// 作用機序単体以外の場合は作用機序とプロセスのセットを追加
					html += '<td>';
					var temp = [];
					for (var i in datum.c){
						var c = datum.c[i];
/*
						var cword = dic[c][self.lang];
						if (cword == null){
							cword = dic[c]['_'];
						}
						*/
						temp.push('<span class="clickable res">' + self.getDic(dic, c) + '</span><span class="hide">' + c + ",course," + key + "</span>");
					}
					html += temp.join(', ');
					html += "</td>";// プロセス
					html += '<td>';
					temp = [];
					for (var i in datum.p){
						var p = datum.p[i];
						/*
						var pword = dic[p][self.lang];
						if (pword == null){
							pword = dic[p]['_'];
						}*/
						temp.push('<span class="clickable res">' + self.getDic(dic, p) + '</span><span class="hide">' + p + ",process," + key + "</span>");
					}
					html += temp.join(', ');
					html += "</td>";// プロセス
				}

				html += "</tr>\n";
			}

			html += "</tbody></table>\n";


			$('#' + ts.id+ '_table').show();
			$('#' + ts.id+ '_table').html(html);
			var $table = $('#' + ts.id+ '_table table');
			$table.tablesorter();

			$('#' + ts.id+ '_table span.clickable.res').click(function(elm){
				var id = $(elm.target).next().text();
				var args = id.split(',');
				var type = args[1];

				if (args.length < 3){
					id = args[0];
				} else {
					id = [args[0], args[2]];
				}
				// 該当IDの種別に応じて処理を行う。
				if (self.cbFunc != null){
					self.cbFunc(id, type);
				}

			});
		}
	}


	// 複数
	// TODO プロセス・作用機序などのリストを動的生成

	// 結果テーブル情報のヘッダ生成
	var html = '<table class="tablesorter"><thead><tr>';
	for (var i in types){
		var type = types[i];
		for (var key in this.words){
			var word = this.words[key];
			if (type.indexOf(key) == 0){
				html += '<th><span class="text_result_' + word + '"></span></th>';
			}

		}
	}
	html += "</tr></thead>\n<tbody>\n";

	var temp_html = [];

	var dic = {};

	var temp_results = [];

	for (var i in result){
		var tmp_result = {};
		var datum = result[i];
		if (types.indexOf('c') >= 0 && datum.cs != null && datum.cl != null){
			self.addDic(dic, datum.cs.value, datum.cl);
			tmp_result.cs = datum.cs;
		}
		if (types.indexOf('p') >= 0 && datum.p != null && datum.pl != null){
			self.addDic(dic, datum.p.value, datum.pl);
			tmp_result.p = datum.p;
		}
		if (datum.ms != null && datum.ml != null){
			self.addDic(dic, datum.ms.value, datum.ml);
			tmp_result.ms = datum.ms;
		}
		if (datum.fs != null && datum.fl != null){
			self.addDic(dic, datum.fs.value, datum.fl);
			tmp_result.fs = datum.fs;
		}
		if (datum.ss != null && datum.sl != null){
			self.addDic(dic, datum.ss.value, datum.sl);
			tmp_result.ss = datum.ss;
		}
		if (datum.qs != null && datum.ql != null){
			self.addDic(dic, datum.qs.value, datum.ql);
			tmp_result.qs = datum.qs;
		}
		if (temp_results.indexOf(tmp_result) < 0){
			temp_results.push(tmp_result);
		}
	}


	for (var i in temp_results){
		var datum = temp_results[i];
		var content = '';
		if (types.indexOf('c') >= 0 && datum.cs != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.cs.value) + '</span><span class="hide">' + datum.cs.value+ ",course</span></td>";// 作用機序
		}
		if (types.indexOf('p') >= 0 && datum.p != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.p.value) + '</span><span class="hide">' + datum.p.value+ ",process</span></td>";// プロセス
		}
		if (datum.ms != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.ms.value) + '</span><span class="hide">' + datum.ms.value+ ",molecule</span></td>";// 分子
		}
		if (datum.rs != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.rs.value) + '</span><span class="hide">' + datum.rs.value+ ",role</span></td>";// ロール
		}
		if (datum.fs != null){
			if (datum.cs != null){
				content += '<td><span class="clickable res">' + self.getDic(dic, datum.fs.value) + '</span><span class="hide">' + datum.cs.value+ ",course,"+ datum.fs.value +"</span></td>";// 所見
			} else {
				content += '<td><span class="clickable res">' + self.getDic(dic, datum.fs.value) + '</span><span class="hide">' + datum.fs.value+ ",ontology</span></td>";// 所見
			}
		}
		if (datum.ss != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.ss.value) + '</span><span class="hide">' + datum.ss.value+ ",ontology</span></td>";// 構造
		}
		if (datum.qs != null){
			content += '<td><span class="clickable res">' + self.getDic(dic, datum.qs.value) + '</span><span class="hide">' + datum.qs.value+ ",ontology</span></td>";// 性質
		}
		if (temp_html.indexOf(content) < 0){
			html += "<tr>";
			html += content;
			html += "</tr>\n";
			temp_html.push(content);
		}

	}

	html += "</tbody></table>\n";


	$('#' + ts.id+ '_table').show();
	$('#' + ts.id+ '_table').html(html);

	var $table = $('#' + ts.id+ '_table table');
	$table.tablesorter();
//	$table.floatThead();
	$('#' + ts.id+ '_table span.clickable.res').click(function(elm){
		var id = $(elm.target).next().text();
		var args = id.split(',');
		var type = args[1];

		if (args.length <= 2){
			id = args[0];
		} else {
			id = [args[0], args[2]];
		}

		// 該当IDの種別に応じて処理を行う。
		if (self.cbFunc != null){
			self.cbFunc(id, type);
		}

	});

	this.setLang(this.lang);

	$(this.div).show();


}

SearchResult.prototype.addDic = function(dic, key, value){
	var k = '_';

	if (value['xml:lang'] != null && value['xml:lang'] != ''){
		k = value['xml:lang'];
	}
	if (dic[key] == null){
		dic[key] = {};
	}
	dic[key][k] = value.value;

}

SearchResult.prototype.getDic = function(dic, key){
	var k = '_';

	var words = dic[key];
	if (words == null){
		return "";
	}
	if (words[this.lang] != null){
		return words[this.lang];
	}
	return words['_'];
}


SearchResult.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
}

SearchResult.prototype.setLang = function(lang){

	this.lang = lang;

	if (lang == null){
		lang = 'ja';
	}
	for(var key in this.consts[lang]){
		$('.text_result_'+key).text(this.consts[lang][key]);
	}
}

SearchResult.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'course': '作用機序',
			'process': 'プロセス',
			'role': 'ロール',
			'molecule': '分子/化合物',
			'finding': '所見',
			'structure': '構造',
			'quarity': '性質'};
	this.consts['en'] = {
			'detail_result': 'Detail Result',
			'course': 'Course',
			'process': 'Process',
			'role': 'Role',
			'molecule': 'Molecule/Compound',
			'finding': 'Finding',
			'structure': 'Structure',
			'quarity': 'Quarity'};

}