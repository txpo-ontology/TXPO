/**
 * PubMed情報表示API
 */

function InfoPubMed(div, lang, initials){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

InfoPubMed.prototype.init = function(){
	var ts = this.div;

	// TODO info_annotationは複数表示されることもありうる
	//　IDの固有性についてはこちらではなく親にて保証する

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_panel"
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_condition'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_head'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_summary'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_foot'
			}));

	var self = this;

	var condition = 'Type : '+
		'(<input type="checkbox" name="type" value="clinical">Clinical Trials '+
		'<input type="checkbox" name="type" value="case">Case Report) '+
		' Species:<input type="checkbox" name="species" value="human">Humans';

	// これは化合物の場合のみ表示？
	condition += '<div class="terms"><span class="term_compound"><input type="radio" name="' + ts.id + '_term" value="narrow">Narrow search(<span class="narrow"/>):'+
	'(</span><input type="radio" name="' + ts.id + '_term" value="narrow_tox" selected="selected">Drug induced liver injury (DILI)(<span class="narrow_tox"/>) '+
	'/ <input type="radio" name="' + ts.id + '_term" value="narrow_liver">Liver(<span class="narrow_liver"/>)<span class="term_compound">)  '+
	'<input type="radio" name="' + ts.id + '_term" value="broad">Broad search(<span class="broad"/>):'+
	'(<input type="radio" name="' + ts.id + '_term" value="broad_tox">Drug induced liver injury (DILI)(<span class="broad_tox"/>) '+
	'/ <input type="radio" name="' + ts.id + '_term" value="broad_liver">Liver(<span class="broad_liver"/>))</span></div>';


	$("#" + ts.id + '_info_condition').append(
			'<div>'+ condition + '</div>');

	$("#" + ts.id + '_info_condition input[type="checkbox"]').click(function(event){
		// 変更通知を上に投げる
		self.cbFunc('change');
	});
	$("#" + ts.id + '_info_condition input[type="radio"]').click(function(event){
		// 変更通知を上に投げる
		self.cbFunc('change');
	});

	this.common = new InfoCommon(this.div, this.lang);

}




InfoPubMed.prototype.show = function(data){
	var ts = this.div;

	// TODO dataを展開

	this.updateCheck(data['opt']);

	this.showHead(data);
	this.showSummary(data);


	$(this.div).show();

//	return ret;
}

InfoPubMed.prototype.updateCheck = function(data){
	var ts = this.div;

	// 一旦チェックを全クリア
	$("#" + ts.id + '_info_condition input[type="checkbox"]').prop('checked', false);

	for (var key in data){
		var checks = data[key];

		for (var i in checks){
			$("#" + ts.id + '_info_condition input:checkbox[name="' + key + '"][value="' + checks[i] + '"]').prop('checked', true);
		}
	}



}


InfoPubMed.prototype.showHead = function(data){
	var ts = this.div;

	var content = "<h3>Search Results</h3>";

	content += "<div>";

	if (data['ids'] == null){
		content += "Search Failed";
	} else {
		if (data['ids'].length > 0){
			content += "Items: ";
			content += "1 to "+ data['ids'].length + " of "+ data['count'];
		} else {
			content += "No Match Results";
		}
	}

	content += "</div>";
	if (data['url'] != null){
		content += '<div><a href="' + data['url'] +'" target="_blank">See more</div>';
	}

	$("#" + ts.id + '_info_head').html(content);

	// TODO course と compound で表示を変える
	if (data['type'] == 'compound'){
		$("#" + ts.id + '_info_condition .terms .term_compound').show();
	} else {
		$("#" + ts.id + '_info_condition .terms  .term_compound').hide();
	}

	var type = data['term']['type'];
	$("#" + ts.id + '_info_condition input[name="' + ts.id + '_term"]').val([type]);

	var counts = data['term']['counts']

	for (var key in counts){
		$("#" + ts.id + '_info_condition span.'+key).text(counts[key]);
	}

}


InfoPubMed.prototype.showSummary = function(data){
	var ts = this.div;

	var summaries = data['summary'];

	var content = "";

	if (summaries == null){
		// TODO 取得エラー
		content = "<span>Summary Search Failed</span>";

		return;
	}

	for (var i in summaries){
		content += "<div>";
		var summary = summaries[i];

		var id = summary['id']
		var item = summary['item'];
		var title = item['Title'];
		var authors = item['AuthorList'].join(', ');
		var source = item['Source'];
		var pubdate = item['PubDate'];
		var so = item['SO'];
		var ELocationID = item['ELocationID'];

		content += '<h4>' + ((i-0)+1) + '. <a href="https://www.ncbi.nlm.nih.gov/pubmed/' + id + '" target="_blank">' + title + '</a></h4>';
		content += '<div>';
		content += '<div>' + authors + "</div>\n";
		content += '<div>' + source + " " + pubdate + " " + so + " " + ELocationID + "</div>\n";
		content += '<div>PMID:' + id + "</div>\n";
		content += '</div>';

		content += "</div>";

	}

	$("#" + ts.id + '_info_summary').html(content);


}

InfoPubMed.prototype.getCurrentOpt = function(){
	var ts = this.div;

	var type = [];
	$("#" + ts.id + '_info_condition input[name="type"]:checked').each(function() {
	    type.push($(this).val());
	});
	var species = [];
	$("#" + ts.id + '_info_condition input[name="species"]:checked').each(function() {
		species.push($(this).val());
	});

	var term = $("#" + ts.id + '_info_condition input[name="' + ts.id + '_term"]:checked').val();

	return {'type':type, 'species':species, 'term':term};

}


InfoPubMed.prototype.onNodeClicked = function(func){
	this.cbFunc = func;

//	this.common.onNodeClicked(func);

}

InfoPubMed.prototype.setLang = function(lang){
	this.lang = lang;
	this.common.setLang(lang);

}

