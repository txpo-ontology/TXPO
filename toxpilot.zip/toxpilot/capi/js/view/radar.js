

/**
 * サブマップ描画ライブラリ
 * マップAPIから利用されるものであり、利用者が直接利用はしない
 * @param c
 * @param draw
 * @returns
 */

function Radar(c, src){

	this.c = c + "_canvas";

	$("#" + c).append('<svg id="' + this.c + '"></svg>');
	$("#"+this.c).parent().hide();


	this.src = src;

	var svg = d3.select("#" + this.c),
    inner = svg.append("g");

	var self = this;

	$(window).on("resize", function(){
		self.refresh();
	}).trigger("resize");

	this.max_width = 300;
	this.max_height = 300;

	this.padding = 20;
}

// mapの表示に合わせてradarの表示範囲を変える
Radar.prototype.refresh = function(){

	var base = $("#"+this.c).parent();

	var width = base.parent().width();
	var height = base.parent().height();

	// VIEWの表示領域を強調表示
	var trans = this.src.transform;
	var mag = this.src.scale;

	if (trans != null && this.trans != null){
		var base_width = $("#"+this.src.c).width() / mag;
		var base_height = $("#"+this.src.c).height() / mag;

		var base_x = (trans.x / mag);
		var base_y = (trans.y / mag);

		$('#' + this.c + "_scope").css({left: -base_x * this.trans.k + this.padding, top: -base_y * this.trans.k + this.padding, width:base_width * this.trans.k, height: base_height * this.trans.k});


		if (width > (this.logical_width * mag) && height > (this.logical_height * mag)){
			if ($("#"+this.c).parent().css('display') == 'block'){
				$("#"+this.c).parent().hide(200);
			}
		} else {
			if ($("#"+this.c).parent().css('display') == 'none'){
				$("#"+this.c).parent().show(200);
			}
		}


	}
	// 座標を変える
	base.css("left", width - (this.width + 30));
	base.css("top", height - (this.height + 30));

}

Radar.prototype.move_scope = function(){
	var left = $('#' + this.c + "_scope").css("left");
	var top = $('#' + this.c + "_scope").css("top");
	var width = $('#' + this.c + "_scope").css("width");
	var height = $('#' + this.c + "_scope").css("height");
	left = left.replace('px','') - 0;
	top = top.replace('px','') - 0;
	width = width.replace('px','') - 0;
	height = height.replace('px','') - 0;

	var base = $("#"+this.c).parent();
	var base_width = base.parent().width();
	var base_height = base.parent().height();


	left -= this.padding;
	top -= this.padding;

	var base_x = -(left / this.trans.k);
	var base_y = -(top / this.trans.k);

	var svg = d3.select("#" + this.src.c);
	var zoom = this.src.zoom;
	var mag = this.src.scale;

	svg.call(zoom.transform, d3.zoomIdentity.translate(base_x * mag, base_y * mag).scale(mag));


}


Radar.prototype.clear = function(){
	d3.selectAll("#" + this.c + " > g").remove();


}

Radar.prototype.draw = function(){
	var cp = d3.select("#" + this.c);

    var html = d3.select("#" + this.src.c).html().replace(/id=\"/g, 'id="radar_').replace(/class=\"node/g, 'class="radar node');
    cp.html(html);

    var svg = cp.node()

    var nodes = $("#" + this.c+ " .radar.node");
    var minx = 1000;
    var miny = 1000;
    var maxx = 0;
    var maxy = 0;
    for (var i in nodes){
    	if (isNaN(i)){
    		continue;
    	}
    	var node = nodes[i];
    	var trans = $(node).attr("transform");
    	if (trans != null && trans.indexOf("translate(") == 0){
    		/*
    		trans = trans.replace("translate(", "");
    		trans = trans.replace(")", "");
    		trans = trans.split(",");
    		*/

            var exc = /translate\(\s*([^\s,)]+)[ ,]?([^\s,)]+)?/.exec(trans);
            if (exc.length > 2){
            	trans = [exc[1], exc[2]];
            }
    	} else {
    		continue;
    	}


    	if (trans.length > 0){
    		var x = trans[0]-0;
    		var y = trans[1]-0;
    		if (maxx < x){
    			maxx = x;
    		}
    		if (maxy < y){
    			maxy = y;
    		}
    		if (minx > x){
    			minx = x;
    		}
    		if (miny > y){
    			miny = y;
    		}
    	}
    }

    maxx = Math.ceil(maxx);
    maxy = Math.ceil(maxy);

    var magx = (this.max_width / (maxx - minx));
    var magy = (this.max_height / (maxy - miny));
    var mag = magy;

    if (magx < magy){
    	mag = magx;
    }

    this.logical_width = (maxx - minx);
    this.logical_height = (maxy - miny);

    this.width = this.logical_width * mag + this.padding*2;
    this.height = this.logical_height * mag + this.padding*2;

    var inner = cp.select("g");

    var self = this;

	var zoom = d3.zoom().on("zoom", function() {
			inner.attr("transform", d3.event.transform);
			self.trans = d3.event.transform;
		}
	);

	cp.call(zoom.transform, d3.zoomIdentity.translate(this.padding + minx * -mag, this.padding + miny * -mag).scale(mag));


    $(svg).attr("width", this.width);
    $(svg).attr("height", this.height);

    if ($("#"+self.c+'_scope')[0] == null){
		$("#"+this.c).parent().append(
				$('<RECT></RECT>')
				.attr({
					'id' : self.c + '_scope',
					'class' : 'radar_scope',
					'fill' : '#00f'
				}));
		$("#"+self.c + "_scope").draggable({
			drag : function(event, ui){
				self.move_scope();
			}
		});
    }

	this.refresh();

}


Radar.prototype.setClickHandler = function(func, right_func){
	if (func != null){
		this.clickHandler = func;
	}
	if (right_func != null){
		this.rightClickHandler = right_func;
	}
}
