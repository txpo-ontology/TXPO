/**
 * 作用機序情報表示API
 * TODO annotationと分離する必要はある？
 * 渡されたデータによって区別すればよいのでは
 */

function InfoCourse(div, lang, initials){

	this.div = div[0];

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	this.init();

}

InfoCourse.prototype.init = function(){
	var ts = this.div;

	// TODO info_annotationは複数表示されることもありうる
	//　IDの固有性についてはこちらではなく親にて保証する

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "result_panel"
			}));


	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_head'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_annotation'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_equivalent'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_object'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_inherit'
			}));

	$('#' + ts.id + " .result_panel").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + '_info_pgene'
			}));

	this.common = new InfoCommon(this.div, this.lang);

}



InfoCourse.prototype.show = function(data){
	var ts = this.div;

	this.common.showHead(data);
	this.common.showAnnotation(data);
	this.common.showEquivalent(data);
	this.common.showObject(data);
	this.common.showInheritObject(data);

	// プロセス-遺伝子
	var contents = '<div><h4><span class="open_table">－</span> <span>Gene Types</span></h4></div>' + "\n";
	contents += '<div class="table">';
	if (data.genes != null){
		contents += this.makeProcessGeneTable(data.genes);
	}
	contents += '</div>';
	this.common.set_table_contents(contents, ts.id + '_info_pgene');
	var table = $('#' + ts.id+ '_info_pgene table');
	table.tablesorter();

	$('#' + ts.id + '_info_pgene .open_table').click(function(event){
		if ($(event.target).text() == '－'){
			// close
			$('#' + ts.id + '_info_pgene .table').slideUp(200);
			$(event.target).text('＋');
		} else {
			$('#' + ts.id + '_info_pgene .table').slideDown(200);
			$(event.target).text('－');
		}
	});

	$(ts).show();

//	return ret;

}

// processベースの遺伝子テーブルを作成する
InfoCourse.prototype.makeProcessGeneTable = function(data){

	var dic = {};
	var params = {};
	var items = {};
	for (var i in data){
		var datum = data[i];

		var process = datum.id;
		dic[process] = datum.l;
		var genes = datum.gene;



		for (var g in genes){
			var gene = genes[g];

			dic[gene.id] = gene.l;
			params[gene.id] = {'role':null, 'assay':null};
			var assay = '';
			if (gene.assay != null){
				for (var a in gene.assay){
					assay += gene.assay[a].l.toLowerCase();
					params[gene.id].assay = gene.assay[a].id;
					dic[gene.assay[a].id] = gene.assay[a].l;
				}
			}

			var being = '';
			if (gene.being != null){
				for (var a in gene.being){
					being += gene.being[a].t.toLowerCase();
				}
			}

			var role = [];
			if (gene.role != null){
				for (var a in gene.role){
					role = gene.role[a].id;
					params[gene.id].role = role;
					dic[role] = gene.role[a].l;
				}
			}

			var item = items[process];
			if (item == null){
				item = {'rat': [], 'mouse': [], 'vitro':[], 'canonical':[]};
				items[process] = item;
			}

			if (being != ''){
				if (being.indexOf('rat') >= 0){
					item.rat.push(gene.id);
				}
				if (being.indexOf('mouse') >= 0){
					item.mouse.push(gene.id);
				}
				if (being.indexOf('human') >= 0){
					item.vitro.push(gene.id);
				}
			} else
			if (assay == null || assay == ''){
				item.canonical.push(gene.id);
			} else {
				if (assay.indexOf('vivo') >= 0){
					item.rat.push(gene.id);
				}
				if (assay.indexOf('vitro') >= 0){
					item.vitro.push(gene.id);
				}
			}
		}
	}

	var html = '<table class="tablesorter"><thead><tr><th>Process</th><th colspan=3>Canonical</th><th colspan=3>Human Gene</th><th colspan=3>Rat Gene</th><th colspan=3>Mouse Gene</th></tr></thead>';
	html += '<tbody>';
/*
	for (var process in items){
		var item = items[process];
		var vitros = item.vitro;
		var vivos = item.vivo;
		var canonicals = item.canonical;
		var rows = Math.max(1, vitros.length, vivos.length, canonicals.length);
		for (var i=0; i<rows; i++){
			html += '<tr>';
			html += '<td><span class="clickable res">' +label_get_before_at(dic[process]) + '</span><span class="hide">' + process + ',process</span></td>';
			if (i < canonicals.length){
				var v = canonicals[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
			} else {
				html += '<td></td><td></td><td></td>';
			}
			if (i < vitros.length){
				var v = vitros[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}

			} else {
				html += '<td></td><td></td><td></td>';
			}
			if (i < vivos.length){
				var v = vivos[i];
				html += '<td><span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span></td>';
				var w = params[v].role;
				if (w != null){
					html += '<td><span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}
				w = params[v].assay;
				if (w != null){
					html += '<td><span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span></td>';
				} else {
					html += '<td></td>';
				}

			} else {
				html += '<td></td><td></td><td></td>';
			}
			html += '</tr>';

		}
*/
	for (var process in items){
		var item = items[process];
		var vitros = item.vitro;
		var rats = item.rat;
		var mouses = item.mouse;
		var canonicals = item.canonical;
		var vitro_assays = [];
		var rat_assays = [];
		var mouse_assays = [];
		var cano_assays = [];

		for (var i in vitros){
			var a = params[vitros[i]].assay;
			if (a != null && a != '' && vitro_assays.indexOf(a) < 0){
				vitro_assays.push(a);
			}
		}
		for (var i in rats){
			var a = params[rats[i]].assay;
			if (a != null && a != '' && rat_assays.indexOf(a) < 0){
				rat_assays.push(a);
			}
		}
		for (var i in mouses){
			var a = params[mouses[i]].assay;
			if (a != null && a != '' && mouse_assays.indexOf(a) < 0){
				mouse_assays.push(a);
			}
		}
		for (var i in canonicals){
			var a = params[canonicals[i]].assay;
			if (a != null && a != '' && cano_assays.indexOf(a) < 0){
				cano_assays.push(a);
			}
		}
		var rows = Math.max(1, vitro_assays.length, rat_assays.length, mouse_assays.length, cano_assays.length);

		for (var i=0; i<rows; i++){
			html += '<tr>';
			html += '<td><span class="clickable res">' +label_get_before_at(dic[process]) + '</span><span class="hide">' + process + ',process</span></td>';

			// canonical
			if (i < cano_assays.length || (cano_assays.length == 0 && i == 0)){
				var assay = null;
				if (cano_assays.length > i){
					assay = cano_assays[i];
				}

				html += '<td>';
				for (var j=0; j<canonicals.length; j++){
					var v = canonicals[j];
					if (params[v].assay == assay){
						html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
					}
				}
				html += '</td>';
				html += '<td>';
				for (var j=0; j< canonicals.length; j++){
					var v = canonicals[j];
					if (params[v].assay == assay){
						var w = params[v].role;
						if (w != null){
							html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + ',ontology</span>,';
						}
					}
				}
				html += '</td>';
				html += '<td>';
				w = assay;
				if (w != null){
					html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + ',ontology</span>,';
				}
				html += '</td>';
			} else {
				html += '<td></td><td></td><td></td>';
			}

			// vitro
			if (i < vitro_assays.length || (vitro_assays.length == 0 && i == 0)){
				var assay = null;
				if (vitro_assays.length > i){
					assay = vitro_assays[i];
				}

				html += '<td>';
				for (var j=0; j<vitros.length; j++){
					var v = vitros[j];
					if (params[v].assay == assay){
						html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
					}
				}
				html += '</td>';
				html += '<td>';
				for (var j=0; j< vitros.length; j++){
					var v = vitros[j];
					if (params[v].assay == assay){
						var w = params[v].role;
						if (w != null){
							html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + ',ontology</span>,';
						}
					}
				}
				html += '</td>';
				html += '<td>';
				w = assay;
				if (w != null){
					html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + ',ontology</span>,';
				}
				html += '</td>';
			} else {
				html += '<td></td><td></td><td></td>';
			}

			// rat
			if (i < rat_assays.length || (rat_assays.length == 0 && i == 0)){
				var assay = null;
				if (rat_assays.length > i){
					assay = rat_assays[i];
				}

				html += '<td>';
				for (var j=0; j<rats.length; j++){
					var v = rats[j];
					if (params[v].assay == assay){
						html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
					}
				}
				html += '</td>';
				html += '<td>';
				for (var j=0; j< rats.length; j++){
					var v = rats[j];
					if (params[v].assay == assay){
						var w = params[v].role;
						if (w != null){
							html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + ',ontology</span>,';
						}
					}
				}
				html += '</td>';
				html += '<td>';
				w = assay;
				if (w != null){
					html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + ',ontology</span>,';
				}
				html += '</td>';
			} else {
				html += '<td></td><td></td><td></td>';
			}

			// mouse
			if (i < mouse_assays.length || (mouse_assays.length == 0 && i == 0)){
				var assay = null;
				if (mouse_assays.length > i){
					assay = mouse_assays[i];
				}

				html += '<td>';
				for (var j=0; j<mouses.length; j++){
					var v = mouses[j];
					if (params[v].assay == assay){
						html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
					}
				}
				html += '</td>';
				html += '<td>';
				for (var j=0; j< rats.length; j++){
					var v = rats[j];
					if (params[v].assay == assay){
						var w = params[v].role;
						if (w != null){
							html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + ',ontology</span>,';
						}
					}
				}
				html += '</td>';
				html += '<td>';
				w = assay;
				if (w != null){
					html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + ',ontology</span>,';
				}
				html += '</td>';
			} else {
				html += '<td></td><td></td><td></td>';
			}
			html += '</tr>';

		}

	}

/*
	for (var process in items){
		var item = items[process];
		var vitros = item.vitro;
		var vivos = item.vivo;
		var canonicals = item.canonical;
		html += '<tr>';
		html += '<td><span class="clickable res">' +label_get_before_at(dic[process]) + '</span><span class="hide">' + process + ',process</span></td>';

		// canonicals
		html += '<td>';
		for (var i=0; i< canonicals.length; i++){
			var v = canonicals[i];
			html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< canonicals.length; i++){
			var v = canonicals[i];
			var w = params[v].role;
			if (w != null){
				html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< canonicals.length; i++){
			var v = canonicals[i];
			w = params[v].assay;
			if (w != null){
				html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';

		// vitros
		html += '<td>';
		for (var i=0; i< vitros.length; i++){
			var v = vitros[i];
			html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< vitros.length; i++){
			var v = vitros[i];
			var w = params[v].role;
			if (w != null){
				html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< vitros.length; i++){
			var v = vitros[i];
			w = params[v].assay;
			if (w != null){
				html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';

		// vivos
		html += '<td>';
		for (var i=0; i< vivos.length; i++){
			var v = vivos[i];
			html += '<span class="clickable res">' + label_get_before_at(dic[v]) + '</span><span class="hide">' + process + ",process," + v + '</span>,';
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< vivos.length; i++){
			var v = vivos[i];
			var w = params[v].role;
			if (w != null){
				html += '<span class="clickable res">' + label_get_before_at(dic[w]) + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';
		html += '<td>';
		for (var i=0; i< vivos.length; i++){
			var v = vivos[i];
			w = params[v].assay;
			if (w != null){
				html += '<span class="clickable res">' + dic[w] + '</span><span class="hide">' + w + '</span>,';
			}
		}
		html += '</td>';
		html += '</tr>';
	}
 */


	html += '</tbody>';
	html += '</table>';

	return html;
}


InfoCourse.prototype.onNodeClicked = function(func){
	this.cbFunc = func;
	this.common.onNodeClicked(func);

}

InfoCourse.prototype.setLang = function(lang){
	this.lang = lang;
	this.common.setLang(lang);

}
