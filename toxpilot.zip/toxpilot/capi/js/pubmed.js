

/**
 * PubMedデータ処理用API
 */

function PubMed(endpoint, lang){
	// Create a new directed graph

//	this.sparql = new SparqlAccessor(endpoint);
	this.api = new APIAccessor(endpoint, "1.0", lang);
	this.lang = lang;

}

PubMed.prototype.getCourseList = function(cb){
	this.api.find("/data/pubmed/course", function(data){
		cb(data);
	});
}


PubMed.prototype.find = function(id, opt, cb){
	this.api.find("/data/pubmed/" + get_uri(id) + "/" + opt, function(data){
		cb(data);
	});
}

PubMed.prototype.getMoleculeTree = function(cb){
	this.api.find("/data/pubmed/compound", function(data){
		cb(data);
	});
}

PubMed.prototype.setLang = function(lang){
	this.lang = lang;
	this.api.lang = lang;
}

