/**
 * PubMed画面について、複数タブで表示するためのI/Fを提供する
 * 他の画面とは異なり、左ペインと右ペインで独立したタブとする
 * （左ペインは２タブ固定、右ペインは動的生成）
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function PubMedController(base_url, div, lang, param){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);


	this.init_param = param;

	/*
	tab2 = new Tab([{head:'head2_1', content:'body2_1'}, {head:'head2_2', content:'body2_2'}, {head:'head2_3', content:'body2_3'}]);
	tab2.showTab('head2_1');
*/

}


PubMedController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	this.strings();

	this.base_url = base_url;


	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
/*
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all"
			}));
*/
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left_tab"
			}));

	$('#'+ts.id+" .left_tab").append(
			'<ul id="' + ts.id + '_tab_head" class="tab_head2">\n' +
			'<li id="' + ts.id + '_tab_head_0"><span class="text_pubmed_list_1"></span></li>\n' +
			'<li id="' + ts.id + '_tab_head_1"><span class="text_pubmed_list_2"></span></li>\n' +
			'</ul>\n');
	$('#'+ts.id+" .left_tab").append(
			'<div class="tab_body2">\n'+
			'<div class="body2" id="' + ts.id + '_tab_body_0"></div>\n'+
			'<div class="body2" id="' + ts.id + '_tab_body_1"></div>\n'+
			'</div>');
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));
	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_info",
				'class' : "right_full"
			}));

	$('#'+ts.id+"_tab_body_0").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all"
			}));

	$('#'+ts.id+"_tab_body_1").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_mtree",
				'class' : "left_all"
			}));


	this.common = new Common();

	this.info = new PMInfoController($('#' + ts.id + "_info"), this.lang);
	this.info.onNodeClicked(function(args){
		// TODO idを元に種別を取得し、それに応じた処理を行う

		// args = change

		var obj = self.info.getInfo(self.info.getCurrentTab()).obj;
		var opt_ = obj.getCurrentOpt();
		var id = obj.id;

		var opt = [];
		var t = opt_.type.join(",");
		if (t.length > 0){
			opt.push("type="+t);
		}
		var s = opt_.species.join(",");
		if (s.length > 0){
			opt.push("species="+s);
		}
		opt.push("term="+opt_.term);

		opt = encodeURIComponent(opt.join(";"));
		self.common.showIndicator();

		self.show_info(id, 'self', opt);

	}.bind(this));


	function set_eventmap(){
		self.eventMap = {
				'course':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'course', args);
					}
				},
				'generic':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'generic', args);
					}
				},
				'process':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'process', args);
					}
				}
		};
	}
	set_eventmap();

	this.data = new PubMed(base_url, this.lang);

	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(tid){
		self.common.showIndicator();
		var t = self.tree.getNodeData(tid);
		self.id = t.resource;

		self.tree.findID(t.resource);

		self.show_info(t.resource, 'self');

	});

	this.mtree = new Tree($('#' + ts.id+ '_mtree'));
	this.mtree.onNodeClicked(function(tid){
		self.common.showIndicator();
		var t = self.mtree.getNodeData(tid);
		self.id = t.resource;

		self.mtree.findID(t.resource);

		self.show_info(t.resource, 'self');

	});


	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});

	var tabs = []
	tabs.push({head:ts.id+"_tab_head_0", content:ts.id+"_tab_body_0"});
	tabs.push({head:ts.id+"_tab_head_1", content:ts.id+"_tab_body_1"});
	this.tab = new Tab("pubmed", tabs);
	this.tab.showTab(ts.id+"_tab_head_0");

}

PubMedController.prototype.show_info = function(id, target, opt){
	var self = this;

	// target = new / self

	// TODO opt
	if (opt == null){
		opt = '';
	}

	this.data.find(id, opt, function(data){

		var index = null;
		if (target != 'new'){
			index = self.info.getCurrentTab();
		}

		self.info.show(data, id, index);
		self.common.hideIndicator();
	});
}


PubMedController.prototype.update_tree = function(id, update){
	var self = this;
	var ts = this.div;
	this.id = id;

	if (update == null){
		update = true;
	}

	this.data.getCourseList(function(result){

		self.tree.setTreeData(result, true);

		setContextMenu();
	});

	this.data.getMoleculeTree(function(result){

		self.mtree.setTreeData(result, true);

		setMContextMenu();
	});


	function highlightId(id){
		// 該当IDを選択・強調、マップを表示
		var ids = self.tree.findID(id);
		if (ids != null && ids.length > 0){
			var id = ids[0];
			var t = self.tree.getNodeData(id);
//			self.tree.findID(t.resource);
//			update_series(t.resource, t.name, self.map.getRelationType());
//			self.update_series(id);
		}
	}

	// contextMenuのイベント登録
	function setContextMenu(){
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
//				            			self.eventHandler(self, 'newtab', node.resource);
					            		var node = get_node(target);
					            		self.tree.findID(node.resource);
					            		self.common.showIndicator();
					            		self.show_info(node.resource, 'new');
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		var node = get_node(target);
				            		self.tree.findID(node.resource);
				            		self.common.showIndicator();
				            		self.show_info(node.resource, 'self');
				            	}
				            },
				            {
				            	text    : 'Show Course',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'course', node.resource);
				            		}
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }
				            ]
		};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}

	// contextMenuのイベント登録2
	// TODO 二つのツリーで共通化したい
	function setMContextMenu(){
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
//				            			self.eventHandler(self, 'newtab', node.resource);
					            		var node = get_node(target);
					            		self.mtree.findID(node.resource);
					            		self.common.showIndicator();
					            		self.show_info(node.resource, 'new');
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		var node = get_node(target);
				            		self.mtree.findID(node.resource);
				            		self.common.showIndicator();
				            		self.show_info(node.resource, 'self');
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }
				            ]
		};
		self.mtree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.mtree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.mtree.getNodeData(id_);
			}
			return t;
		}
	}

}


PubMedController.prototype.setContextMenu = function (){

	var self = this;

	var sampleElement = $('#' + this.div.id+ '_head li');

	var contextMenuObj = new ContextMenu({
	    element  : sampleElement,
	    menuList : [
	        {
	            text    : 'Close This Tab',
	            action  : function(event) {
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	self.removeTab(id_);
	            },
	            disabled:(sampleElement.length <= 1)
	        }/*,
	        {
	            text    : 'Copy This Tab',
	            action  : function() {
//	                alert('button 2 click');
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	var t = self.tree.getNodeData(id_);
	            	if (self.eventHandler != null){
	            		self.eventHandler(self, 'newtab', t.resource);
	            	}
	            }
	        }*/
	    ]
	});
}

//現在の表示状態から、パラメータ情報を取得する
PubMedController.prototype.getParameter = function(){

}

PubMedController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}


PubMedController.prototype.setLang = function(lang){
	/*
	this.data.setLang(lang);
	this.info.setLang(lang);
	this.update_tree(this.id, true);
	*/

	this.data.setLang(lang);
	this.update_tree(this.id, true);


	if (lang == null){
		lang = 'ja';
	}
	for(var key in this.consts[lang]){
		$('.text_pubmed_'+key).text(this.consts[lang][key]);
	}


	if (this.lang != lang){
		this.lang = lang;

	}
}

PubMedController.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'list_1': '作用機序',
			'list_2': 'Most-DILI Concern 化合物'
			};
	this.consts['en'] = {
			'list_1': 'Toxic Courses',
			'list_2': 'Most-DILI Concern Compounds'
			};

}
