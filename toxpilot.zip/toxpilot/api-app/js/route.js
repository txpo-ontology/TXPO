

function Route(base_url, div, lang){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);
}


Route.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all2"
			}));
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));

	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all split-pane horizontal-percent"
			}));

	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_map",
				'class' : "right_top  split-pane-component"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider horizontal " + ts.id
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_bottom",
				'class' : "right_bottom split-pane-component " + ts.id
			}));

	this.common = new Common();

	this.map = new RouteMap($('#'+ts.id + '_map'));
	this.map.setUpdateHandler(this.mapHandler.bind(this));
	this.map.onNodeClicked(function(index, id, obj){
//		var a = args;
		self.showAnnotationInfo(id);
	}.bind(this),
	function(args1, args2, args3){
//		var a = args;
	}.bind(this), this);

	this.map_opt = new RouteOption($('#'+ts.id), this.map);



	this.data = new RouteData(base_url, this.lang);

	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(id){
		var t = self.tree.getNodeData(id);

		var type = self.data.findType(t.resource);
		if (type.type == 'process'){

			self.tree.findID(t.resource);
//		update_series(t.resource, t.name, self.map.getRelationType());
			self.update_series(id, null, true);
		} else {
			var relations = self.data.findRelations(t.resource);
			relations = relations.relations;
			if (relations.length > 0){
				id = self.tree.findID(relations[0].id, true, false)[0];
				self.update_series(id, null, true);
			}
			self.tree.findID(t.resource);
		}

	});

	this.info = new InfoController($('#'+ts.id + '_bottom'), this.lang);
	this.info.onNodeClicked(function(tid, etype){
		// TODO クリックに応じて別画面
		// TODO idを元に種別を取得し、それに応じた処理を行う

		self.data.findType(tid, function(data){
			if (data != null && data.type != null){
				var type = data.type;
				var etype = 'all';
				if (type == 'course'){
					etype = 'course';
				} else if (type == 'process'){
					etype = 'process';
				}
				// まずは情報表示
				if (self.eventHandler != null){
					self.eventHandler(self, etype, tid);
				}
			}
		});

	}.bind(this));


	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});



	function get_way(){

	}

//	this.update_tree();
//	update_tree(id);
//	update_viewtype();
/*
	$('#lang').change(function(elm){
		data.setLang($('#lang').val());
		update_tree();
		update_viewtype();
	});
*/
}

Route.prototype.mapHandler = function(type, args){

	if (type == 'option'){
		var tid = this.tree.getCurrent();
		if (tid == null){
			return;
		}
		var type = this.map.getRelationType();
		// typeが切り替わった
		// single の場合
		//  treeから現IDの下のpartではない最下位をとってきてIDを切り替える
		// genericの場合
		//  treeから現IDの一つ上の親をとってきてIDを切り替える
		if (type.type == 'single'){
//			id = getLeaf(tid, this);
			id = tid;
			this.update_series(id);
		} else {
			var t = this.tree.getNodeData(tid);
//			id = $('#'+tid).parent().parent().attr('id');
			id = tid;
//			id = t.parent.id;
		}

		this.update_series(id, null, true);
	} else
	if (type == 'fullscreen'){
		this.common.full_screen(args[1], args[0]);
	} else {
		this.update_series();
	}
//	this.eventHandler = func;

	var self = this;

	function getLeaf(id, self){
		var t = self.tree.getNodeData(id);

		var children = t.children;
		var child = null;
		for (var i in children){
			if (children[i].type != 'part'){
				child = children[i].id;
				break;
			}
		}
		if (child == null){
			return id;
		} else {
			return getLeaf(child, self);
		}
	}

}


Route.prototype.getLeaf = function(id){

}


Route.prototype.showAnnotationInfo = function(s){
//	var index = this.info.addTab(null,'annotation');
	var self = this;
	this.data.findAnnotation(s, function(data){
		self.info.show(data, 'annotation');
//		self.info.getInfo(index).show(data);
	});

}

Route.prototype.update_tree = function(id, addHistory) {

	var self = this;

	this.baseid = null;
	// idが配列だった場合は[1]をプロセスとし、[0]を関連とする
	if (id instanceof Array){
		this.baseid = id[0];
		id = id[1];
		// findings on
		this.option = ",finding";
	} else {
		this.baseid = null;
		this.option = "";
	}

	self.id = id;
	self.common.showIndicator();
	self.data.findAllProcesses(function(result){
		// treeデータ result
		self.tree.setTreeData(result, true);
		var id = self.id;
		self.id = null;


		setContextMenu();

		if (id != null){
			// 該当IDを選択・強調、マップを表示
			var ids = self.tree.findID(id);
			if (ids != null && ids.length > 0){
				var id = ids[0];
				var t = self.tree.getNodeData(id);
//				self.tree.findID(t.resource);
//				update_series(t.resource, t.name, self.map.getRelationType());
				self.update_series(id);
			}
		}

		// resize
		$(window).trigger('resize');
		self.common.hideIndicator();
	}
	);

	// contextMenuのイベント登録
	function setContextMenu(){
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'newtab', node.resource);
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.tree.findID(node.resource);
				            		self.update_series(node.id);
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }/*,
				            {
				            	text    : 'View Process',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.eventHandler(self, 'process', node.resource);
				            	}
				            },
				            {
				            	text    : 'View GenericChains',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.eventHandler(self, 'generic', node.resource);
				            	}
				            }*/
				            ]
		};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}
}

Route.prototype.update_series = function(tid, cb, refresh){
	var self = this;
	if (tid == null){
		tid = self.tree.getCurrent();
	}
	if (tid == null){
		return;
	}
	var t = self.tree.getNodeData(tid);
	var ccount = 0;
	var child = null;

	for (var i in t.children){
		if (t.children[i].type == null){
			ccount++;
			if (child == null){
				child = self.tree.getNodeData(t.children[i].id);
			}
		}
	}

	var id = t.resource;
//	self.tree.findID(id);
/*
	if (ccount > 0){
		self.map.setType('generic');
//		if (self.baseid == null){
			id = child.resource;
//		}
	} else {
		self.map.setType('single');
	}
*/

	var type = self.map.getRelationType();
	var way = '';
	if (type.direction.indexOf('c') >= 0){
		if (type.direction.indexOf('r') >= 0){
			way = 'both';
		} else {
			way = 'cause';
		}
	} else if (type.direction.indexOf('r') >= 0){
		way = 'result';
	}

	this.common.showIndicator();
	self.data.findRoute(id, function(data){
		self.tree.setCurrent(tid);
		if (data.data.length == 0){
			self.map.clear();
//			alert("No Data");
		} else {
			self.map.setMapData(data);
//			self.draw.setData(data);
//			update_series_gene_list(data.gene);

			var context = {
					menuList : [
						{
			            	text    : 'dmy'
			           }],
						   menuCallback : function(args){
							   var id = self.data.data.concepts[args.targetIndex].id;
							   var courses = self.data.findCourses(id);
							   var children = self.data.data.concepts[args.targetIndex].c;
							   var type = self.data.findType(id);
							   var crs = [];

							   if (children == null || children.length == 0){
								   var sub = [];
								   for (var i in courses.courses){
									   var course = courses.courses[i];
									   sub.push({
										   text: course.l,
										   args: [course.id, id],
										   action  : function(event, target, index, args) {
							            		self.eventHandler(self, 'course', args);
							            		self.common.full_screen($('#'+self.div.id + '_map'), false);
							            	}
									   }
									   );
								   }

								   if (sub.length > 0){
									   crs.push({
											   text    : 'Show Course',
											   subMenu : sub
									   });
								   }
								   if (type.type == "process"){
									   crs.push(
											   {
												   text    : 'Show ProcessInfo',
												   action  : function(event, target, index) {
									            		var id = self.data.data.concepts[target.__data__].id;
									            		self.eventHandler(self, 'process', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
												   }

											   });
									   crs.push(
											   {
												   text    : 'Show GeneralMaps',
												   action  : function(event, target, index) {
									            		var id = self.data.data.concepts[target.__data__].id;
									            		self.eventHandler(self, 'generic', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
												   }
											   });
									   crs.push({
											   text    : 'Find Route',
											   action  : function(event, target, index) {
									            	var id = self.data.data.concepts[target.__data__].id;
									            	self.eventHandler(self, 'route', id);
									            	self.common.full_screen($('#'+self.div.id + '_map'), false);
											   }
										   });
									   crs.push(
											   {
										   text    : 'Show Ontology',
										   action  : function(event, target, index) {
											   var id = self.data.data.concepts[target.__data__].id;
											   self.eventHandler(self, 'ontology', id);
											   self.common.full_screen($('#'+self.div.id + '_map'), false);
										   }
										});
									   if (self.map.getRelationType().type == 'single') {// single only
										   crs.push(
												   {
											   text    : 'Show Route To Here',
											   action  : function(event, target, index) {
									            	var id = self.data.data.concepts[target.__data__].id;
									            	self.view_route(id);
											   }
											});
									   }
								   } else {
										var relations = self.data.findRelations(id);
										 var sub = [];
										 for (var i in relations.relations){
											 var relation = relations.relations[i];
											 sub.push({
												text: relation.l,
												args: [id, relation.id],
												action  : function(event, target, index, args) {
													self.eventHandler(self, 'route', args);
													self.common.full_screen($('#'+self.div.id + '_map'), false);
												}
											 }
											 );
										 }

										 if (sub.length > 0){
											   crs.push({
													   text    : 'Find Route',
													   subMenu : sub
											   });
										}

										   crs.push(
												   {
											   text    : 'Show Ontology',
											   action  : function(event, target, index) {
												   var id = self.data.data.concepts[target.__data__].id;
												   self.eventHandler(self, 'ontology', id);
												   self.common.full_screen($('#'+self.div.id + '_map'), false);
											   }
											});

								   }
							   } else {
								   // genericノード
								   var sub = [];
								   for (var i in children){
									   var child = children[i];

									   sub.push({
										   text: child.l,
										   args: child.id,
										   action  : function(event, target, index, id) {
							            		self.eventHandler(self, 'process', id);
							            		self.common.full_screen($('#'+self.div.id + '_map'), false);
							            	}
									   }
									   );
								   }

								   if (sub.length > 0){
									   crs.push({
											   text    : 'Show ProcessInfo',
											   subMenu : sub
									   });
								   }

								   var sub2 = [];
								   for (var i in children){
									   var child = children[i];
									   var ccourses = self.data.findCourses(child.id);
									   for (var i in ccourses.courses){
										   var course = ccourses.courses[i];
										   var text = child.l;
										   if (ccourses.courses.length > 1){
											   text += '(' + course.l + ')';
										   }
										   sub2.push({
											   text: text,
											   args: [course.id, child.id],
											   action  : function(event, target, index, id) {
//												   var pid = self.data.data.concepts[target.__data__].id;
	//							            		var id = course.id;
								            		self.eventHandler(self, 'course', id);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
										   }
										   );
									   }
								   }

								   if (sub.length > 0){
									   crs.push({
											   text    : 'Show Eachmap',
											   subMenu : sub2
									   });
								   }


								   crs.push(
										   {
									        	text    : 'Find Route',
									        	action  : function(event, target, index) {
									        		var id = self.data.data.concepts[target.__data__].id;
//									        		self.eventHandler(self, 'route', [id, children[0].id]);
									        		self.eventHandler(self, 'route', [id, children[children.length-1].id]);
//									        		self.eventHandler(self, 'route', id);
									        		self.common.full_screen($('#'+self.div.id + '_map'), false);
									        	}
									        });
								   crs.push(
											{
								            	text    : 'Show Ontology',
								            	action  : function(event, target, index) {
								            		var id = self.data.data.concepts[target.__data__].id;
								            		self.eventHandler(self, 'ontology', id);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
								            });

							   }
							   return crs;
						   }
				};
			self.map.setContextMenu(context);
			self.map.findID(id);
		}
		self.common.hideIndicator();

		if (cb != null){
			cb(data);
		}
//	}, type.type+self.option, way, type.depth);
	}, type.type, way, type.depth);

	if (self.eventHandler != null){
		self.eventHandler(self, 'selected', t.name);
	}
}

Route.prototype.view_route = function(tid){

	var routes = [];
	// 原因から結果を探索
	this.data.findARoute(this.data.data.id,tid, this.data.data.relations, routes);
	// 結果から原因を探索
	this.data.findARoute(tid, this.data.data.id, this.data.data.relations, routes);

	this.map_opt.view_path(routes);
}


Route.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

Route.prototype.setLang = function(lang){
	this.lang = lang;
	this.data.setLang(lang);

	// TODO
	this.update_tree(this.id, true);
}