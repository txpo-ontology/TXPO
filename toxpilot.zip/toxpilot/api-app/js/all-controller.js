/**
 * 全階層画面について、複数タブで表示するためのI/Fを提供する
 * 他の画面とは異なり、左ペインは一つとし、右ペインをタブとする
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function AllController(base_url, div, lang, param){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);


	this.init_param = param;

	/*
	tab2 = new Tab([{head:'head2_1', content:'body2_1'}, {head:'head2_2', content:'body2_2'}, {head:'head2_3', content:'body2_3'}]);
	tab2.showTab('head2_1');
*/

}


AllController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	this.base_url = base_url;


	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));
	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_info",
				'class' : "right_full"
			}));

	this.common = new Common();

	this.info = new InfoController($('#' + ts.id + "_info"), this.lang);
	this.info.onNodeClicked(function(args, type){
		// TODO idを元に種別を取得し、それに応じた処理を行う

		if (type != null){
			if (type == 'external'){
				// 外部リソース取得
				self.show_external_info(args);
				return;
			}

			if (self.eventHandler != null){
				var etype = type;
				self.eventHandler(self, etype, args);
			}
		} else {
			self.data.findType(args, function(data){
				if (data != null && data.type != null){
					type = data.type;
					var etype = 'ontology';
					if (type == 'course'){
						etype = 'course';
					} else if (type == 'process'){
						etype = 'process';
					}
					// まずは情報表示
					if (self.eventHandler != null){
						self.eventHandler(self, etype, args);
					}
				}
			});
		}
	}.bind(this));


	function set_eventmap(){
		self.eventMap = {
				'course':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'course', args);
					}
				},
				'generic':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'generic', args);
					}
				},
				'process':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'process', args);
					}
				}
		};
	}
	set_eventmap();

	this.data = new Data(base_url, this.lang);
	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(tid){
		self.common.showIndicator();
		var t = self.tree.getNodeData(tid);
//		self.tree.findID(t.resource);
		self.id = t.resource;

	   var type = self.data.findType(self.id);

//		update_series(t.resource, t.name, self.map.getRelationType());
		self.show_info(t.resource, 'self');
//		self.common.hideIndicator();

	});

	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});

}

AllController.prototype.show_info = function(id, target){
//	this.info.show(id, 'course'); // TODO data種別を取得→種別指定にすべき
	var self = this;

	var type = this.data.findType(id);

	this.data.findAnnotation(id, function(data){

		if (type == null){
			type ='course';
		}

		self.tree.findID(data.id);

		var index = null;
		if (target != 'new'){
			var index = self.info.getCurrentTab();
		}

		self.info.show(data, type.type, index);
		self.common.hideIndicator();
	});
}

AllController.prototype.show_external_info = function(id){
	var self = this;

	this.data.findAnnotation(id, function(data){

		var index = self.info.getCurrentTab();

		self.info.show_external(data, index);
	}, true);
}



AllController.prototype.update_tree = function(id, update){
	var self = this;
	this.id = id;

	if (update == null){
		update = true;
	}

	/* tree読み出し前に呼ばれてしまうことがある TODO 検討
	if (!update){
		highlightId(id);
		return;
	}
	*/

	this.common.showIndicator();
	this.data.findWhole(function(result){
		// treeデータ result
		self.tree.setTreeData(result, true);
		var id = self.id;


		setContextMenu();

		if (id != null){
			highlightId(id);
		}

		if (self.init_param != null){
			for (var i in self.init_param.ids){
				var id_ = self.init_param.ids[i];
				self.show_info(id_, 'new');
				highlightId(id_);
			}
			this.init_param = null;
		}


		self.common.hideIndicator();
	} );

	function highlightId(id){
		// 該当IDを選択・強調、マップを表示
		var ids = self.tree.findID(id);
		if (ids != null && ids.length > 0){
			var id = ids[0];
			var t = self.tree.getNodeData(id);
//			self.tree.findID(t.resource);
//			update_series(t.resource, t.name, self.map.getRelationType());
//			self.update_series(id);
		}
	}

	// contextMenuのイベント登録
	function setContextMenu(){
		var context = {
				menuList : [
							{
				            	text    : 'dmy'
				           }],
							   menuCallback : function(args){
				            		var node = get_node(args.target);
								   var id = node.resource;
								   var type = self.data.findType(id);
								   var crs = [];
								   crs.push(
											{
								            	text    : 'Open in New Window',
								            	action  : function(event, target, index) {
								            		/*
								            		var node = get_node(target);

								            		if (self.eventHandler != null){
								            			self.eventHandler(self, 'newtab', [type, node.resource]);
								            		}*/
								            		var node = get_node(target);
								            		self.tree.findID(node.resource);
								            		self.show_info(node.resource, 'new');

								            	}
								            });
								   crs.push(
											{
								            	text    : 'Open in This Window',
								            	action  : function(event, target, index) {
								            		var node = get_node(target);
								            		self.tree.findID(node.resource);
								            		self.show_info(node.resource, 'self');
								            	}
								            });

								   if (type != null){
									   var courses = self.data.findCourses(id);
									   var type = self.data.findType(id);
									   var sub = [];
									   for (var i in courses.courses){
										   var course = courses.courses[i];
										   sub.push({
											   text: course.l,
											   args: course.id,
											   action  : function(event, target, index, id) {
												   var pid = self.data.data.concepts[target.__data__].id;
//								            		var id = course.id;
								            		self.eventHandler(self, 'course', [id, pid]);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
										   }
										   );
									   }

									   if (sub.length > 0){
										   crs.push({
												   text    : 'Show Course',
												   subMenu : sub
										   });
									   }
									   if (type.type == 'process'){
										   // プロセス
										   crs.push(
												{
									            	text    : 'Show ProcessInfo',
									            	action  : function(event, target, index) {
									            		var node = get_node(target);
									            		var id = node.resource;
									            		self.eventHandler(self, 'process', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}

									            });
										   crs.push(
									            {
									            	text    : 'Show GeneralMaps',
									            	action  : function(event, target, index) {
									            		var node = get_node(target);
									            		var id = node.resource;
									            		self.eventHandler(self, 'generic', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}
									            });
										   crs.push(
									            {
									            	text    : 'Find Route',
									            	action  : function(event, target, index) {
									            		var node = get_node(target);
									            		var id = node.resource;
									            		self.eventHandler(self, 'route', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}
									            });
									   } else if (type.type == 'course'){
										   // プロセス
										   crs.push(
												{
									            	text    : 'Show Course',
									            	action  : function(event, target, index) {
									            		var node = get_node(target);
									            		var id = node.resource;
									            		self.eventHandler(self, 'course', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}

									            });
									   }
								   }
							   return crs;
						   }


		};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}

}


AllController.prototype.setContextMenu = function (){

	var self = this;

	var sampleElement = $('#' + this.div.id+ '_head li');

	var contextMenuObj = new ContextMenu({
	    element  : sampleElement,
	    menuList : [
	        {
	            text    : 'Close This Tab',
	            action  : function(event) {
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	self.removeTab(id_);
	            },
	            disabled:(sampleElement.length <= 1)
	        }/*,
	        {
	            text    : 'Copy This Tab',
	            action  : function() {
//	                alert('button 2 click');
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	var t = self.tree.getNodeData(id_);
	            	if (self.eventHandler != null){
	            		self.eventHandler(self, 'newtab', t.resource);
	            	}
	            }
	        }*/
	    ]
	});
}

//現在の表示状態から、パラメータ情報を取得する
AllController.prototype.getParameter = function(){

}

AllController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}


AllController.prototype.setLang = function(lang){
	this.lang = lang;
	this.data.setLang(lang);
	this.info.setLang(lang);
	this.update_tree(this.id, true);
}
