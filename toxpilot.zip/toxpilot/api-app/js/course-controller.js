/**
 * 作用機序画面について、複数タブで表示するためのI/Fを提供する
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function CourseController(base_url, div, lang, param, isCreateTab ){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);

	if (isCreateTab) {
		this.addTab();
	}

	/*
	tab2 = new Tab([{head:'head2_1', content:'body2_1'}, {head:'head2_2', content:'body2_2'}, {head:'head2_3', content:'body2_3'}]);
	tab2.showTab('head2_1');
*/

}


CourseController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;
	this.base_url = base_url;


	$(ts).append(
			$('<DIV></DIV>'));

	$('#'+ts.id+" > div").append(
			$('<ul></ul>')
			.attr({
				'id' : ts.id + "_head",
				'class' : "tab_head2"
			}));
	$('#'+ts.id+" > div").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "tab_body"
			}));

	this.tab = new Tab("course", ts.id);

	var cmdMap = {};
	cmdMap['addTab'] = {undo:function(param){
			var tabid = param[0];
			var prev = param[1];
			var id = param[2];
			self.removeTab(tabid, false);
			self.selectTab(prev, false);
		}, redo:function(param){
			var tabid = param[0];
			var prev = param[1];
			var id = param[2];
			self.addTab(id, false);
			self.selectTab(tabid, false);
		}
	};
	cmdMap['removeTab'] = {
		undo:function(param){
			var id = param[0];
			var prev = param[1];
			self.addTab(id, false);
			self.selectTab(id, false);
		}, redo:function(param){
			var id = param[0];
			var prev = param[1];
			self.removeTab(id, false);
			self.selectTab(prev, false);
		}
	}
	cmdMap['selectTab'] = {
		undo:function(param){
			var id = param[0];
			var prev = param[1];
			self.selectTab(prev, false);
		}, redo:function(param){
			var id = param[0];
			var prev = param[1];
			self.selectTab(id, false);
		}
	}

	cmds.addHandler('course', cmdMap);


	function set_eventmap(){
		self.eventMap = {
				'selected':function(src, args){
					var tabs = self.tab.getTabs();
					for (var key in tabs){

						// TODO labelの「（」削除等の処理は別途まとめる
						if (tabs[key].content == src.div.id){
							var seps = ['（', '(', '['];
							var index = 9999;
							for (var i in seps){
								var sep = seps[i];
								var idx = args.indexOf(sep);
								if (idx >= 0){
									index = Math.min(index, idx);
								}
							}
							if (index < 9999){
								args = args.substring(0,index).trim();
							}

							self.tab.setName(key, args);
//							$('#'+key).text(args);
							break;
						}
					}
				},
				'generic':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'generic', args);
					}
				},
				'process':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'process', args);
					}
				},
				'route':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'route', args);
					}
				},
				'jump':function(src, args){
					// 該当ノードにジャンプする
					src.map.findID(args);
				},
				'ontology':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'ontology', args);
					}
				},
				'newtab':function(src, args){
					self.addTab(args);
				}
		};
	}



	set_eventmap();
}

/**
 * タブを追加する
 * 戻り値はタブのindex
 */
CourseController.prototype.addTab = function(id, addHistory){
	var ts = this.div;
	var self = this;
	var pid = null;

	// プロセスIDも含む
	if (Array.isArray(id)){
		pid = id[1];
		id = id[0];
	}

	if (addHistory == null){
		addHistory = true;
	}

//	var index = 0;

	var label = "new tab";

/*
	for (index = 0; ;index++){
		if ($("#" + ts.id + "_head_"+index)[0] == null){
			break;
		}
	}

	var newHead = ts.id + "_head_"+index;
	var newBody = ts.id + "body_"+index;
	*/
	var newHead = this.tab.getNewTabID();
	var newBody = newHead.body;
	var newHead = newHead.head;

	$('#'+ts.id+"_head").append(
			'<li id="' + newHead + '"></li>');

	$('#'+ts.id+" > div > div.tab_body").append(
			$('<DIV></DIV>')
			.attr({
				'id' : newBody,
				'class' : "body2"
			}));

	var init = {'props':'rpwmftioa', 'mol':false};
	if (pid != null){
		init = {'props':'rpwmftioa', 'mol':true};
	}
	var course = new Course(this.base_url, $('#' + newBody), this.lang, null, init);
	if (id != null){
		course.update_tree(id, false, pid);
	}

	// courseのイベントハンドラ（選択変更時・タブ追加など）
	course.setEventHandler(function(src, type, args){
		var func = self.eventMap[type];
		if (func != null){
			func(src, args);
		}
	});

	var self = this;
	var callback = function( data ) {
		var id_ = data.target.parentElement.id;
		if( "" == id_ ){
			id_ = data.target.parentElement.parentElement.id;
		}
		self.removeTab( id_ );
		data.stopPropagation();
	};

	this.tab.addTab( newHead, newBody, course, null, callback );
	this.tab.setName(newHead, label);


//	this.tab = new Tab([{head:ts.id + '_head_'+index, content:ts.id + '_body_'+index}]);
	if (addHistory){
		if (this.tab != null){
			var cmd = new Command("course.addTab", [newHead, this.tab.getCurrentTab(), id]);
			cmds.push(cmd);
		}
	}

	this.tab.showTab(newHead);

	this.setContextMenu();



	return newHead;

}



/**
 * タブを削除する
 */
CourseController.prototype.removeTab = function(index, addHistory){
	var ts = this.div;
	var self = this;

	if (addHistory == null){
		addHistory = true;
	}

	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	this.tab.removeTab(index);

	/* 要検討
	if (addHistory){
		var cmd = new Command("course.removeTab", [index, this.tab.getCurrentTab()]);
		cmds.push(cmd);
	}
	*/


	this.setContextMenu();
}

/**
 * タブを選択する
 */
CourseController.prototype.selectTab = function(index, addHistory){
	var ts = this.div;


	if (addHistory == null){
		addHistory = true;
	}

	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	if (addHistory){
		var cmd = new Command("course.selectTab", [index, this.tab.getCurrentTab()]);
		cmds.push(cmd);
	}


	this.tab.showTab(index);
}

/**
 * 現在のタブを取得する
 */
CourseController.prototype.getCurrentTab = function(){

	return this.tab.getCurrentTab();
}


CourseController.prototype.setContextMenu = function (){

	var self = this;

	var sampleElement = $('#' + this.div.id+ '_head li');

	var contextMenuObj = new ContextMenu({
	    element  : sampleElement,
	    menuList : [
	        {
	            text    : 'Close This Tab',
	            action  : function(event) {
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	if (id_ == ''){
	            		id_ = data.target.parentElement.id;
	            	}
	            	self.removeTab(id_);
	            },
	            disabled:(sampleElement.length <= 1)
	        }/*,
	        {
	            text    : 'Copy This Tab',
	            action  : function() {
//	                alert('button 2 click');
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	var t = self.tree.getNodeData(id_);
	            	if (self.eventHandler != null){
	            		self.eventHandler(self, 'newtab', t.resource);
	            	}
	            }
	        }*/
	    ]
	});
}


// 現在の表示状態から、パラメータ情報を取得する
CourseController.prototype.getParameter = function(){

}


CourseController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}


CourseController.prototype.setLang = function(lang){
	this.lang = lang;

	var objs = this.tab.getTabs();

	for (var key in objs){
		var object = objs[key];
		if (object.obj != null){
			object.obj.setLang(lang);
		}
	}
}
