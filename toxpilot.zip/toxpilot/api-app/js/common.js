/**
 *
 */
function Common(){
	this.top_bottom			= 0;
	this.horizontal_bottom	= 0;
	this.bottom_height		= 0;
	this.inner_height		= 0;

	this.indicator_count = 0;
}

// add maeda FullScreen対応 FullScreenにチェックが入った時に呼ばれる
Common.prototype.full_screen = function(div, full){
	// Onの時
	if (full){
		// フルスクリーン復帰後に右下のタブの高さが0になる問題の対応
//		if( "#body_3_body_0_map" != div.selector ) {
			this.top_bottom 		= div.css("bottom");
			this.horizontal_bottom	= this.top_bottom;
			this.bottom_height		= this.top_bottom;
//		}

		div.addClass('fullscreen');
		$('.split-pane').addClass('fullscreen');
		$('.tab_head').addClass('fullscreen');
		$('.tab_head2').addClass('fullscreen');
		// Safariフルスクリーン対応
		$('.split-pane-component').addClass('fullscreenmode');
		$('.split-pane-divider').addClass('fullscreenmode');
	// Offの時
	} else {
		div.removeClass('fullscreen');
		$('.split-pane').removeClass('fullscreen');
		$('.tab_head').removeClass('fullscreen');
		$('.tab_head2').removeClass('fullscreen');
		// Safariフルスクリーン対応
		$('.split-pane-component').removeClass('fullscreenmode');
		$('.split-pane-divider').removeClass('fullscreenmode');

		// フルスクリーン復帰後に右下のタブの高さが0になる問題の対応
//		if( "#body_3_body_0_map" != div.selector ) {
			var classStr = div.selector.replace( "_map", "" ).substr( 1 );	/* _mapと#の除去 */
			div.css("bottom", this.top_bottom );
			$( '.split-pane-divider.horizontal.' + classStr ).css("bottom", this.horizontal_bottom );
			$( '.right_bottom.split-pane-component.' + classStr ).height( this.bottom_height );
//		}
	}
	$(window).trigger('resize');

}


Common.prototype.showIndicator = function(){
	this.indicator_count++;

	$('.indicatorArea').css( "display", "block" );
}

Common.prototype.hideIndicator = function(){
	this.indicator_count --;

	if (this.indicator_count <= 0){
		$('.indicatorArea').css( "display", "none" );
	}
}