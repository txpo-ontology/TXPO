/**
 * トップ画面について、表示・制御するためのI/Fを提供する
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function TopController(base_url, div, lang, param){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);



}

TopController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	this.strings();

	// 画面作成
	function make_elements(ts){

		$(ts).append(
				$('<DIV></DIV>')
				.attr({
					'id' : ts.id + "_top_body",
					'class' : "top_main"
				}));

		$('#' + ts.id + "_top_body").append(
				$('<DIV></DIV>')
				.attr({
					'id' : ts.id + "_icon_list",
					'class' : "icon_list"
				}));

		for (var y=0; y<2; y++){
			$('#' + ts.id + "_icon_list").append(
					$('<DIV></DIV>')
					.attr({
						'id' : ts.id + "_icon_list_line_"+y,
						'class' : "top_icon_line_div"
					}));

			for (var x=0; x<3; x++){
				if (y == 1 && x == 2){
					$('#' + ts.id + "_icon_list_line_"+y).append(
							$('<DIV></DIV>')
							.attr({
								'id' : ts.id + "_icon_67",
								'class' : "top_icon_div wrap"
							}));


					$('#' + ts.id + "_icon_67").append(
							$('<DIV></DIV>')
							.attr({
								'id' : ts.id + "_icon_"+(y*3 + x + 1),
								'class' : "top_icon_div half"
							}));
					$('#' + ts.id + "_icon_67").append(
							$('<DIV></DIV>')
							.attr({
								'id' : ts.id + "_icon_"+(y*3 + x + 2),
								'class' : "top_icon_div half"
							}));

				} else {
					$('#' + ts.id + "_icon_list_line_"+y).append(
							$('<DIV></DIV>')
							.attr({
								'id' : ts.id + "_icon_"+(y*3 + x + 1),
								'class' : "top_icon_div"
							}));
				}

			}
		}
		for (var i=0; i<7; i++){
			$('#' + ts.id + "_icon_"+(i+1)).append(
					'<h3><span class="text_top_list_'+(i+1)+'"></span></h3>'
					);
			$('#' + ts.id + "_icon_"+(i+1)).append(
					'<div class="top_abst"><span class="text_top_abst_'+(i+1)+'"></span></div>'
					);
			$('#' + ts.id + "_icon_"+(i+1)).append(
					'<div class="top_icon"><img src="api-app/img/top_icon_'+(i+1)+'.png"></img></div>'
					);

			$('#' + ts.id + "_icon_"+(i+1)).click(function(event){
				var types = ['course', 'process', 'ontology', 'route', 'generic', 'search', 'pubmed'];
				for (var j=1; j<=types.length; j++){
					if ($('#' + self.div.id + "_icon_"+j).find(event.target).length > 0){
						self.eventHandler(self, types[j-1], null);
						break;
					}
				}

			});
		}

		$('#' + ts.id + "_icon_list").append(
		 '<div class="top_movie ja">'+
		 '<h3 class="top_movie_head">Tutorial</h3>'+
		 '<video src="demotoxpilot_text_ja.mp4" poster="tox_tn_ja.png" controls width="800px" preload="none"></video>'+
		 '<div class="top_movie_wrap"><img src="play_icon.png" class="top_movie_icon"/></div>'+
		 '</div>');
		$('#' + ts.id + "_icon_list").append(
		 '<div class="top_movie en">'+
		 '<h3 class="top_movie_head">Tutorial</h3>'+
		 '<video src="demotoxpilot_text_en.mp4" poster="tox_tn_en.png" controls width="800px" preload="none"></video>'+
		 '<div class="top_movie_wrap"><img src="play_icon.png" class="top_movie_icon"/></div>'+
		 '</div>');


		$('#' + ts.id + "_icon_list").append(
				$('<DIV>Copyright (C)2019 National Institutes of Biomedical Innovation, Health and Nutrition. All Rights Reserved.</DIV>')
				.attr({
					'id' : ts.id + "_footer",
					'class' : "footer_div"
				}));

		self.is_play = false;

		$(".top_movie_wrap").click(function(){
			if (!self.is_play){
				$("." +self.lang + " video")[0].play();
			} else {
				$("." +self.lang + " video")[0].pause();
			}
		});
		$("video").on("play" , function(){
			$("." +self.lang + " .top_movie_icon").hide();
			self.is_play = true;
		});
		$("video").on("pause", function(){
			$("." +self.lang + " .top_movie_icon").show();
			self.is_play = false;
		});

		self.setLang(self.lang);
	}

	make_elements(ts);

	this.common = new Common();

}



TopController.prototype.setLang = function(lang){

	if (lang == null){
		lang = 'ja';
	}
	for(var key in this.consts[lang]){
		$('.text_top_'+key).text(this.consts[lang][key]);
	}

	$("."+lang +" video")[0].pause();
	$('.top_movie').hide();
	$('.top_movie.'+lang).show();


	if (this.lang != lang){
		this.lang = lang;

	}

}

TopController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

TopController.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'list_1': '作用機序マップ',
			'list_2': 'プロセスマップ',
			'list_3': 'オントロジー',
			'list_4': 'ルート探索',
			'list_5': '汎用機序マップ',
			'list_6': '検索',
			'list_7': 'PubMed',
			'abst_1': '毒性発現の過程を生体プロセスの因果関係として可視化',
			'abst_2': '機能分解手法に基づきプロセスを部分分解',
			'abst_3': '毒性機序に関する用語を体系化',
			'abst_4': '複数の機序を横断した汎用的な因果関係を表示',
			'abst_5': '注目したプロセスの原因系または結果系のパスを表示',
			'abst_6': '',
			'abst_7': ''
			};
	this.consts['en'] = {
			'list_1': 'Toxic Course Map',
			'list_2': 'Process Map',
			'list_3': 'Ontology',
			'list_4': 'Route search',
			'list_5': 'General Course Map',
			'list_6': 'Search',
			'abst_1': 'Toxic course map visualized a toxic course as causal relationships between processes.',
			'abst_2': 'Process map visualizes the selected process based on the systemic functioning decomposition approach.',
			'abst_3': 'Ontology provides the definition and related information about each term based on the TXPO.',
			'abst_4': 'Route search provides the upstream or downstream paths of the focused process.',
			'abst_5': 'General course map visualizes general toxic courses common to multiple toxic courses.',
			'abst_6': '',
			'abst_7': ''
			};

}
