/**
 * PubMed情報表示画面について、複数タブで表示するためのI/Fを提供する
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function PMInfoController(div, lang, param){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init();

//	this.addTab();

	/*
	tab2 = new Tab([{head:'head2_1', content:'body2_1'}, {head:'head2_2', content:'body2_2'}, {head:'head2_3', content:'body2_3'}]);
	tab2.showTab('head2_1');
*/

}


PMInfoController.prototype.init = function(){
	var ts = this.div;
	var self = this;

	$(ts).append(
			$('<DIV></DIV>'));

	$('#'+ts.id+" > div").append(
			$('<ul></ul>')
			.attr({
				'id' : ts.id + "_head",
				'class' : "tab_head2"
			}));
	$('#'+ts.id+" > div").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "tab_body_info"
			}));

	this.tab = new Tab("info", ts.id);

	var cmdMap = {};
	cmdMap['addTab'] = {undo:function(param){
			var tabid = param[0];
			var prev = param[1];
			var id = param[2];
			var type = param[3];
			self.removeTab(tabid, false);
			self.selectTab(prev, false);
		}, redo:function(param){
			var tabid = param[0];
			var prev = param[1];
			var id = param[2];
			var type = param[3];
			self.addTab(id, type, false);
			self.selectTab(tabid, false);
		}
	};
	cmdMap['removeTab'] = {
		undo:function(param){
			var id = param[0];
			var prev = param[1];
			var type = param[2];
			self.addTab(id, type, false);
			self.selectTab(id, false);
		}, redo:function(param){
			var id = param[0];
			var prev = param[1];
			self.removeTab(id, false);
			self.selectTab(prev, false);
		}
	}
	cmdMap['selectTab'] = {
		undo:function(param){
			var id = param[0];
			var prev = param[1];
			self.selectTab(prev, false);
		}, redo:function(param){
			var id = param[0];
			var prev = param[1];
			self.selectTab(id, false);
		}
	}

	cmds.addHandler('info', cmdMap);

	function set_eventmap(){
		self.eventMap = {
				'selected':function(src, args){
					var tabs = self.tab.getTabs();
					for (var key in tabs){
						if (tabs[key].content == src.div.id){
							// TODO カッコ削除処理は別途
							var seps = ['（', '(', '['];
							var index = 9999;
							for (var i in seps){
								var sep = seps[i];
								var idx = args.indexOf(sep);
								if (idx >= 0){
									index = Math.min(index, idx);
								}
							}
							if (index < 9999){
								args = args.substring(0,index).trim();
							}

							self.tab.setName(key, args);

//							$('#'+key).text(args);
							break;
						}
					}
				},
				'newtab':function(src, args){
					self.addTab(args);
				}
		};
	}

	set_eventmap();
}

PMInfoController.prototype.show = function(data, id, index){

//	var label = InfoCommon.getLabel(data, this.lang);
	var label = data['label'];

	if (index == null){
		index = this.tab.findTab(label);
	}
	if (index == null){
		index = this.addTab(null);
	} else {
		// typeによってobjectを再作成
		var tabObjs = this.tab.getTab(index);
//		$('#'+tabObjs.content).empty(); // 既存コンテンツをクリア
//		var info = this.makeInfoObj(type, tabObjs.content, null);
//		tabObjs.obj = info;
		this.tab.showTab(index);
	}

	this.getInfo(index).obj.id = id; // TODO 仮
	this.getInfo(index).obj.show(data);
	// dataを元にtabの名前を設定
	this.tab.setName(this.getCurrentTab(), label);
}




/**
 * タブを追加する
 * 戻り値はタブのindex
 */
PMInfoController.prototype.addTab = function(id, addHistory){
	var ts = this.div;
	var self = this;

	if (addHistory == null){
		addHistory = true;
	}

//	var index = 0;

	var label = "new tab";
/*
	for (index = 0; ;index++){
		if ($("#" + ts.id + "_head_"+index)[0] == null){
			break;
		}
	}

	var newHead = ts.id + "_head_"+index;
	var newBody = ts.id + "body_"+index;
*/
	var newHead = this.tab.getNewTabID();
	var newBody = newHead.body;
	var newHead = newHead.head;


	$('#'+ts.id+"_head").append(
			'<li id="' + newHead + '"></li>');

	$('#'+ts.id+" > div .tab_body_info").append(
			$('<DIV></DIV>')
			.attr({
				'id' : newBody,
				'class' : "body2"
			}));

	var info = null;

	// TODO typeに応じてinfo種別を変更
	// type annotationは廃止すべきでは（course/process/molecule/role/finding/structure/その他　とする）
	/*
	if (type == 'process'){
		info = new InfoProcess($('#' + newBody), this.lang, id);
	} else if (type == 'course'){
		info = new InfoCourse($('#' + newBody), this.lang, id);
	} else if (type == 'molecule'){
		info = new InfoMolecule($('#' + newBody), this.lang, id);
	} else {
		// なにも該当しない場合は最低限のannotation
		info = new InfoAnnotation($('#' + newBody), this.lang, id);
	}*/
	info = this.makeInfoObj(newBody, id);


	var self = this;
	var callback = function( data ) {
		var id_ = data.target.parentElement.id;
		if( "" == id_ ){
			id_ = data.target.parentElement.parentElement.id;
		}
		self.removeTab( id_ );
		data.stopPropagation();
	};

	this.tab.addTab( newHead, newBody, info, null, callback );
	this.tab.setName(newHead, label);

	if (addHistory){
		if (this.tab != null){
			var cmd = new Command("pminfo.addTab", [newHead, this.tab.getCurrentTab(), id]);
			cmds.push(cmd);
		}
	}

	this.tab.showTab(newHead);

	this.setContextMenu();



	return newHead;

}

PMInfoController.prototype.makeInfoObj = function(newBody, id){
	var info = null;

	// TODO InfoPubMed を capi に追加
	info = new InfoPubMed($('#' + newBody), this.lang, id);

	// infoのイベントハンドラ（選択変更時・タブ追加など）
	if (this.nodeHandler != null){
		info.onNodeClicked(this.nodeHandler);
	}


	return info;
}


// indexに該当するinfoオブジェクトを取得する
PMInfoController.prototype.getInfo = function(tabid){
	var ts = this.div;



	return this.tab.getTabs()[tabid];

}


/**
 * タブを削除する
 */
PMInfoController.prototype.removeTab = function(index, addHistory){
	var ts = this.div;
	var self = this;

	if (addHistory == null){
		addHistory = true;
	}

	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	this.tab.removeTab(index);

	this.setContextMenu();
}

/**
 * タブを選択する
 */
PMInfoController.prototype.selectTab = function(index, addHistory){
	var ts = this.div;


	if (addHistory == null){
		addHistory = true;
	}

	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	if (addHistory){
		var cmd = new Command("info.selectTab", [index, this.tab.getCurrentTab()]);
		cmds.push(cmd);
	}


	this.tab.showTab(index);
}

/**
 * 現在のタブを取得する
 */
PMInfoController.prototype.getCurrentTab = function(){

	return this.tab.getCurrentTab();
}


PMInfoController.prototype.setContextMenu = function (){

	var self = this;

	var sampleElement = $('#' + this.div.id+ '_head li');

	var contextMenuObj = new ContextMenu({
	    element  : sampleElement,
	    menuList : [
	        {
	            text    : 'Close This Tab',
	            action  : function(event) {
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	if (id_ == ''){
	            		id_ = data.target.parentElement.id;
	            	}
	            	self.removeTab(id_);
	            },
	            disabled:(sampleElement.length <= 1)
	        },
	        {
	            text    : 'Copy This Tab',
	            action  : function() {
//	                alert('button 2 click');
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	var t = self.tree.getNodeData(id_);
	            	if (self.eventHandler != null){
	            		self.eventHandler(self, 'newtab', t.resource);
	            	}
	            }
	        }
	    ]
	});
}


// 現在の表示状態から、パラメータ情報を取得する
PMInfoController.prototype.getParameter = function(){

}

PMInfoController.prototype.onNodeClicked = function(func){
	this.nodeHandler = func;
}


PMInfoController.prototype.setLang = function(lang){
	this.lang = lang;
	var objs = this.tab.getTabs();

	for (var key in objs){
		var object = objs[key];
		if (object.obj != null){
			object.obj.setLang(lang);
		}
	}
}
