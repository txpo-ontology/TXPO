
/**
 * 汎用機序情報画面ひとつを司るオブジェクト
 */
function Generic(base_url, div, lang, prop, init){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.strings();

	this.init(base_url, prop, init);
}


Generic.prototype.init = function(base_url, prop, init){
	var ts = this.div;
	var self = this;
/*
	var color_map = [
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000028', // 好酸性顆粒変性
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0002528', // ERストレス
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000888', // 脂肪肝
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001432', // 曇り硝子変性
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001986', // ミトコンドリア障害
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0000324', // アポトーシス
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0001277', // 胆汁うっ滞
		'http://www.semanticweb.org/yukiyamagata/ontologies/toxicogenomics#[TXG]_0002215'  // リン脂質症
	         ];
*/
	var color_map = COLOR_MAP;


	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
	/*

	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all"
			}));
	*/
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left_tab"
			}));

	$('#'+ts.id+" .left_tab").append(
			'<ul id="' + ts.id + '_tab_head" class="tab_head2">\n' +
			'<li id="' + ts.id + '_tab_head_0"><span class="text_generic_process"></span></li>\n' +
			'<li id="' + ts.id + '_tab_head_1"><span class="text_generic_generic_node"></span></li>\n' +
			'</ul>\n');
	$('#'+ts.id+" .left_tab").append(
			'<div class="tab_body2">\n'+
			'<div class="body2" id="' + ts.id + '_tab_body_0"></div>\n'+
			'<div class="body2" id="' + ts.id + '_tab_body_1"></div>\n'+
			'</div>');

	$('#'+ts.id+"_tab_body_0").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all2"
			}));


	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));
	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_map",
				'class' : "right_full"
			}));

	this.common = new Common();

//	var ps = {'props':{'r':'hasResult', 'p':'has_part', 'w':'has Pathway', 'm':'has_Molecular_reaction', 'f':'hasFindings', 't':'hasParticipant', 'a':'hasAgent', 'i':'hasInput', 'o':'hasOutput'}};
	var ps = {'props':{'r':'has result', 'p':'has part', 'w':'has pathway', 'm':'has molecular reaction', 'f':'has finding', 't':'has participant', 'a':'has agent', 'i':'has input', 'o':'has output'}};

	if (prop == null){
		prop = ps;
	} else {
		prop = Object.assign(prop, ps);
	}
	this.setLang(this.lang);

	prop = Object.assign(prop, {'color_map':color_map});

	this.map = new Map($('#'+ts.id + '_map'), prop, init);
	this.map.setUpdateHandler(this.mapHandler.bind(this));// mapのチェック状態が変更になったなど
	this.map.onNodeClicked(function(args){
		var a = args;
	}.bind(this));

	this.data = new ProcessData(base_url, this.lang);

	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(tid){
		var t = self.tree.getNodeData(tid);
		self.tree.findID(t.resource);
		self.id = t.resource;

//		update_series(t.resource, t.name, self.map.getRelationType());
		self.update_series(tid);

	});

	this.info = new InfoSiblings($('#' + ts.id+ '_tab_body_1'), this.lang, {'color_map':color_map});


	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});

	var tabs = []
	tabs.push({head:ts.id+"_tab_head_0", content:ts.id+"_tab_body_0"});
	tabs.push({head:ts.id+"_tab_head_1", content:ts.id+"_tab_body_1"});
	this.tab = new Tab("process", tabs);
	this.tab.showTab(ts.id+"_tab_head_0");

	this.map.adjust();
}

Generic.prototype.mapHandler = function(type, args){
	if (type == 'option'){
		this.update_series();
	} else if (type == 'molecule'){
		this.update_molecule();
	} else	if (type == 'fullscreen'){
		this.common.full_screen(args[1], args[0]);
	} else {
		this.update_series();
	}

}

Generic.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

Generic.prototype.update_tree = function(id, update, pid){
	var self = this;
	this.id = id;

	if (update == null){
		update = true;
	}

	/* tree読み出し前に呼ばれてしまうことがある TODO 検討
	if (!update){
		highlightId(id);
		return;
	}
	*/


	self.id = id;
	this.common.showIndicator();
	self.data.findAllProcesses( function(result) {
		// treeデータ result
		self.tree.setTreeData(result, true);
		var id = self.id;
		self.id = null;


		setContextMenu();

		if (id != null){
			// 該当IDを選択・強調、マップを表示
			var ids = self.tree.findID(id);
			if (ids != null && ids.length > 0){
				var id = ids[0];
				var t = self.tree.getNodeData(id);
//				self.tree.findID(t.resource);
//				update_series(t.resource, t.name, self.map.getRelationType());
				self.update_series(id);
			} else {
				// TODO 全作用機序 仮
				self.update_allseries();
			}
		}

		// resize
		$(window).trigger('resize');
		self.common.hideIndicator();
	} );

	function highlightId(id){
		// 該当IDを選択・強調、マップを表示
		var ids = self.tree.findID(id);
		if (ids != null && ids.length > 0){
			var id = ids[0];
			var t = self.tree.getNodeData(id);
//			self.tree.findID(t.resource);
//			update_series(t.resource, t.name, self.map.getRelationType());
			self.update_series(id);
		}
	}

	// contextMenuのイベント登録
	function setContextMenu(){
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'newtab', node.resource);
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.tree.findID(node.resource);
				            		self.update_series(node.id);
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }
				            ]
		};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}

}

Generic.prototype.update_molecule = function(){
	this.common.showIndicator();
	if (this.map.adjust()){
		this.update_series();
	} else {
		this.updateMap();
	}
	this.common.hideIndicator();
}

Generic.prototype.update_series = function(tid, cb){
	var self = this;
	if (tid == null){
		tid = this.tree.getCurrent();
	}
	if (tid == null){
		return;
	}
	var t = this.tree.getNodeData(tid);
	this.id = t.resource;
	var id = this.id;
	this.tree.findID(id);
	var label = t.name;
	var type = this.map.getRelationType();

	this.common.showIndicator();
	this.data.findChains(id, label, function(result){
		if (result.data.length == 0){
//			self.draw.clear();
//			alert("No Data");
		} else {
			self.tree.setCurrent(tid);

			self.updateMap(id, result);

		}
		self.common.hideIndicator();

		if (cb != null){
			cb(data);
		}
	}, type);

	if (this.eventHandler != null){
		this.eventHandler(this, 'selected', t.name);
	}

}

// TODO 全作用機序 仮
Generic.prototype.update_allseries = function(cb){
	var self = this;
	var type = this.map.getRelationType();

	this.id = 'all';
	var id = this.id;

	this.common.showIndicator();
	this.data.findAllChains(function(result){
		if (result.data.length == 0){
//			self.draw.clear();
			alert("No Data");
		} else {
			self.updateMap(id, result);

		}
		self.common.hideIndicator();

		if (cb != null){
			cb(data);
		}
	}, type);

	if (this.eventHandler != null){
		this.eventHandler(this, 'selected', 'all');
	}

}

Generic.prototype.updateMap = function(id, result){

	if (id == null){
		id = this.id;
	}

	if (id == null || (typeof id != 'string' && id.id == null)){
		return;
	}


	var self = this;

	if (result == null){
		result = self.map.mapData;
	}

	var courses = [];
	for (var i in result.relations){
		var relation = result.relations[i];
		if (relation.s != null && courses.indexOf(relation.s) < 0){
			courses.push(relation.s);
		}
	}
	result.series_index = courses;

	self.map.setMapData(result);
	self.map.findID(id);

//	self.draw.setData(data);
//	update_series_gene_list(data.gene);

	self.data.findSiblings(id, function(siblings){
		// coursesも利用する
		siblings['courses_list'] = courses;
		self.info.show(siblings);

		self.tab.showTab(self.div.id+"_tab_head_1");
	});

	setContextMenu();

	function setContextMenu(){
		var context = {
				menuList : [
							{
				            	text    : 'dmy'
				           }],
							   menuCallback : function(args){
//								   var src = self.data.data.concepts[args.targetIndex];
//								   var id = src.id;
								   var src = null;
								   var id = null;
									for (var i in self.data.data.concepts){
										var datum = self.data.data.concepts[i];
										var id = datum.id;
										id = id.substring(id.lastIndexOf('/')+1);
										if (args.targetID.indexOf(id) > 0){
											src = datum;
											id = src.id;
											break;
										}
									}
								   var type = self.data.findType(id);

								   var children = src.c;
								   var courses = self.data.findCourses(id);
								   var crs = [];

								   if (children == null || children.length == 0){
									   // 汎用機序なし
									   var sub = [];
									   for (var i in courses.courses){
										   var course = courses.courses[i];
										   sub.push({
											   text: course.l,
											   args: course.id,
											   action  : function(event, target, index, id) {
												   var pid = self.data.data.concepts[target.__data__].id;
	//							            		var id = course.id;
								            		self.eventHandler(self, 'course', [id, pid]);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
										   }
										   );
									   }

									   if (sub.length > 0){
										   crs.push({
												   text    : 'Show Course',
												   subMenu : sub
										   });
									   }
									   if (type.type == "process"){
										   crs.push(
													{
										            	text    : 'Show ProcessInfo',
										            	/*
										            	action  : function() {
										            		alert('Show ProcessInfo');
										            	}
										            	*/
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'process', id);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}

										            });
										   crs.push(
										            {
										            	text    : 'Show GeneralMaps',
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'generic', id);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}
										            });
										   crs.push(
												   {
											        	text    : 'Find Route',
											        	action  : function(event, target, index) {
											        		var id = self.data.data.concepts[target.__data__].id;
											        		self.eventHandler(self, 'route', id);
											        		self.common.full_screen($('#'+self.div.id + '_map'), false);
											        	}
											        });

										   addCauseResults(id, crs);



										   crs.push(
													{
										            	text    : 'Show Ontology',
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'ontology', id);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}
										            });
									   } else {
											var relations = self.data.findRelations(id);
											 var sub = [];
											 for (var i in relations.relations){
												 var relation = relations.relations[i];
												 sub.push({
													text: relation.l,
													args: [id, relation.id],
													action  : function(event, target, index, args) {
														self.eventHandler(self, 'route', args);
														self.common.full_screen($('#'+self.div.id + '_map'), false);
													}
												 }
												 );
											 }

											 if (sub.length > 0){
												   crs.push({
														   text    : 'Find Route',
														   subMenu : sub
												   });
											}

											   addCauseResults(id, crs);

									   }
								   } else {
									   // 汎用機序
									   var sub = [];
									   for (var i in children){
										   var child = children[i];

										   sub.push({
											   text: child.l,
											   args: child.id,
											   action  : function(event, target, index, id) {
//												   var pid = self.data.data.concepts[target.__data__].id;
	//							            		var id = course.id;
								            		self.eventHandler(self, 'process', id);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
										   }
										   );
									   }

									   if (sub.length > 0){
										   crs.push({
												   text    : 'Show ProcessInfo',
												   subMenu : sub
										   });
									   }

									   var sub2 = [];
									   for (var i in children){
										   var child = children[i];
										   var ccourses = self.data.findCourses(child.id);
										   for (var i in ccourses.courses){
											   var course = ccourses.courses[i];
											   var text = child.l;
											   if (ccourses.courses.length > 1){
												   text += '(' + course.l + ')';
											   }
											   sub2.push({
												   text: text,
												   args: [course.id, child.id],
												   action  : function(event, target, index, id) {
//													   var pid = self.data.data.concepts[target.__data__].id;
		//							            		var id = course.id;
									            		self.eventHandler(self, 'course', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}
											   }
											   );
										   }
									   }

									   if (sub.length > 0){
										   crs.push({
												   text    : 'Show Eachmap',
												   subMenu : sub2
										   });
									   }


									   crs.push(
											   {
										        	text    : 'Find Route',
										        	action  : function(event, target, index) {
										        		var id = self.data.data.concepts[target.__data__].id;
//										        		self.eventHandler(self, 'route', [id, children[0].id]);
										        		self.eventHandler(self, 'route', id);
										        		self.common.full_screen($('#'+self.div.id + '_map'), false);
										        	}
										        });

									   addCauseResults(id, crs);

									   crs.push(
												{
									            	text    : 'Show Ontology',
									            	action  : function(event, target, index) {
									            		var id = self.data.data.concepts[target.__data__].id;
									            		self.eventHandler(self, 'ontology', id);
									            		self.common.full_screen($('#'+self.div.id + '_map'), false);
									            	}
									            });
								   }


								   return crs;
							   }

		};

		function addCauseResults(id, crs){
			var causeresult = self.data.findCausesAndResults(id);
			if (Object.keys(causeresult.origins).length > 0){
				var sub = [];
				var work = [];

				for (var t in causeresult.origins){
					var causes = causeresult.origins[t];
					for (var i in causes){
						var cause = causes[i];
						if (self.map.findID(cause.id, true).length > 0 && work.indexOf(cause.id) < 0){
							sub.push({
								text: cause.l,
								args: cause.id,
								action  : function(event, target, index, args) {
									self.eventHandler(self, 'jump', args);
									self.common.full_screen($('#'+self.div.id + '_map'), false);
								}
							}
							);
							work.push(cause.id);
						}
					}
				}

				if (sub.length > 0){
					crs.push(
							{
								text    : 'Show Causes',
								subMenu : sub
							});
				}

			}

			if (Object.keys(causeresult.dests).length > 0){
				var sub = [];
				var work = [];

				for (var t in causeresult.dests){
					var dests = causeresult.dests[t];
					for (var i in dests){
						var dest = dests[i];
						if (self.map.findID(dest.id, true).length > 0 && work.indexOf(dest.id) < 0){
							sub.push({
								text: dest.l,
								args: dest.id,
								action  : function(event, target, index, args) {
									self.eventHandler(self, 'jump', args);
									self.common.full_screen($('#'+self.div.id + '_map'), false);
								}
							}
							);
							work.push(dest.id);
						}
					}
				}

				if (sub.length > 0){
					crs.push(
							{
								text    : 'Show Results',
								subMenu : sub
							});
				}

			}
		}

		self.map.setContextMenu(context);

	}

}

Generic.prototype.showAnnotationInfo = function(s){
//	var index = this.info.addTab(null,'annotation');
	var self = this;
	this.data.findAnnotation(s, function(data){
		self.info.show(data, 'annotation');
//		self.info.getInfo(index).show(data);
	});

}

Generic.prototype.setLang = function(lang){

	if (lang == null){
		lang = 'ja';
	}

	this.lang = lang;

	for(var key in this.consts[lang]){
		$('.text_generic_'+key).text(this.consts[lang][key]);
	}

	if (this.data != null){
		this.data.setLang(lang);
	}
	if (this.info != null){
		this.info.setLang(lang);
	}

	// TODO
	if (this.tree != null){
		this.update_tree(this.id, true);
	}

}

Generic.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'process': 'プロセス',
			'generic_node': '汎用ノード'};
	this.consts['en'] = {
			'process': 'Process',
			'generic_node': 'General Process'};
}

