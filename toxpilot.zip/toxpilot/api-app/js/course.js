
/**
 * 作用機序情報画面ひとつを司るオブジェクト
 */
function Course(base_url, div, lang, prop, init){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url, prop, init);
}


Course.prototype.init = function(base_url, prop, init){
	var ts = this.div;
	var self = this;

	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all2"
			}));
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));

	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all split-pane horizontal-percent"
			}));

	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_map",
				'class' : "right_top split-pane-component"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider horizontal " + ts.id
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_bottom",
				'class' : "right_bottom split-pane-component " + ts.id
			}));

	if (prop != null){
		prop = Object.assign(prop, {'mol':true});
	} else {
		prop = {'mol':true};
	}


	this.common = new Common();

	this.map = new Map($('#'+ts.id + '_map'), prop, init);
	this.map.setUpdateHandler(this.mapHandler.bind(this));// mapのチェック状態が変更になったなど
	this.map.onNodeClicked(function(index, id, obj){
		// info
//		var a = args1;
		self.showAnnotationInfo(id);
	}.bind(this),
	function(index, id, obj){
	}.bind(this), this);

	this.data = new Data(base_url, this.lang);

	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(tid){
		var t = self.tree.getNodeData(tid);
		self.tree.findID(t.resource);
		self.id = t.resource;

//		update_series(t.resource, t.name, self.map.getRelationType());
		self.update_series(tid);

	});

	this.info = new InfoController($('#'+ts.id + '_bottom'), this.lang);
	this.info.onNodeClicked(function(tid, etype){

		if (etype == null){
			//
			self.map.findID(tid);
		} else {

			if (etype == 'external'){
				// 外部リソース取得
				self.show_external_info(tid);
				return;
			}

    		if (self.eventHandler != null){
    			self.eventHandler(self, etype, tid);
    		}

		}
	}.bind(this));

	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});

	this.map.adjust();
}

Course.prototype.mapHandler = function(type, args){
	if (type == 'option'){
		this.update_series();
	} else
	if (type == 'molecule'){
		this.update_molecule();
	} else
	if (type == 'fullscreen'){
		this.common.full_screen(args[1], args[0]);
	} else {
		this.update_series();
	}

}



Course.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

Course.prototype.update_tree = function(id, update, pid){
	var self = this;


	this.id = {id:id, pid:pid};
	if (id != null){
		if (typeof id == 'object'){
			this.id = id;
		}
	}

	if (update == null){
		update = true;
	}

	/* tree読み出し前に呼ばれてしまうことがある TODO 検討
	if (!update){
		highlightId(id);
		return;
	}
	*/

	// TODO これは毎回呼ばなくてよいはず
	this.common.showIndicator();
	this.data.findSeries(function(result){
		// treeデータ result
		self.tree.setTreeData(result, true);
		var id = null;
		var pid = null;
		if (self.id != null){
			id = self.id.id;
			pid = self.id.pid;
		}


		setContextMenu();

		if (id != null){
			highlightId(id, pid);
		}
		self.common.hideIndicator();
	}
	);


	function highlightId(id, pid){
		// 該当IDを選択・強調、マップを表示

		// TODO IDのtypeを取得
		self.data.findType(id, function(result){
			var id = result.id;
			if (result.type == 'course'){
				var ids = self.tree.findID(id);
				if (ids != null && ids.length > 0){
					var id = ids[0];
					var t = self.tree.getNodeData(id);
	//				self.tree.findID(t.resource);
	//				update_series(t.resource, t.name, self.map.getRelationType());
					self.update_series(id, function(){
						if (self.id != null && self.id.pid != null){
							self.map.findID(self.id.pid);
						}
//						self.id = null;
					});
				}
			} else {
				// TODO
				// idを持つcourseを取得し、map表示を行い、idノードを強調表示
				alert('idを持つcourseを取得し、map表示を行い、idノードを強調表示['+id+"]");
				// !! TODO これはこの前の時点で処理すべきでは

			}
		});
	}

	// contextMenuのイベント登録
	function setContextMenu(){
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'newtab', node.resource);
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.tree.findID(node.resource);
				            		self.update_series(node.id);
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }
				            ]
		};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}

}

Course.prototype.update_molecule = function(){
	this.common.showIndicator();
	if (this.map.adjust()){
		this.update_series();
	} else {
		this.updateMap();
		if (this.id != null && this.id.pid != null){
			this.map.findID(this.id.pid);
		}

	}
	this.common.hideIndicator();
}


Course.prototype.update_series = function(tid, cb){
	var self = this;
	var refresh = false;
	if (tid == null){
		tid = this.tree.getCurrent();
		refresh = true;
	}
	if (tid == null){
		return;
	}
	var t = this.tree.getNodeData(tid);
	if (this.id == null || typeof this.id == 'string'){
		this.id = t.resource;
	} else {
		this.id.id = t.resource;
	}
	var id = t.resource;
	this.tree.findID(id);
	var label = t.name;
	var type = this.map.getRelationType();

	this.common.showIndicator();
	this.data.findNodes(id, label, function(data){
		if (data.data.length == 0){
//			self.draw.clear();
//			alert("No Data");
		} else {
			self.tree.setCurrent(tid);

			self.updateMap(id, data);

		}

		self.common.hideIndicator();
		if (cb != null){
			cb(data);
		}
	}, type);

	// ここでは作用機序の情報を表示する
	if (!refresh){
		this.data.findAnnotation(id, function(data){
			self.info.show(data, 'course');
	//		self.info.getInfo(index).show(data);
		});
	}


	if (this.eventHandler != null){
		this.eventHandler(this, 'selected', t.name);
	}
}

Course.prototype.updateMap = function(id, data){

	var self = this;

	if (id == null){
		id = this.id;
	}

	if (id == null || (typeof id != 'string' && id.id == null)){
		return;
	}

	self.map.setMapData(data);

	setContextMenu();

	function setContextMenu(){
		var context = {
				/*
				menuList : [
				            {
				            	text    : 'Show ProcessInfo',
				            	action  : function(event, target, index) {
				            		var id = self.data.data.concepts[target.__data__].id;
//				            		alert('Show ProcessInfo');
//				            		self.showAnnotationInfo(id);
				            		var id = self.data.data.concepts[target.__data__].id;
				            		self.eventHandler(self, 'process', id);
				            	}
				            },
				            {
				            	text    : 'Show GenericChains',
				            	action  : function(event, target, index) {
//				            		alert('Show GenericChains');
				            		var id = self.data.data.concepts[target.__data__].id;
				            		self.eventHandler(self, 'generic', id);
				            	}
				            },
				            {
				            	text    : 'Find Route',
				            	action  : function(event, target, index) {
				            		var id = self.data.data.concepts[target.__data__].id;
				            		self.eventHandler(self, 'route', id);
				            	}
				            }
				            ]
				 */
				menuList : [
							{
				            	text    : 'dmy'
				           }],
							   menuCallback : function(args){
								   var src = null;
								   var id = null;
									for (var i in self.data.data.concepts){
										var datum = self.data.data.concepts[i];
										var id = datum.id;
										id = id.substring(id.lastIndexOf('/')+1);
										if (args.targetID.indexOf(id) > 0){
											src = datum;
											id = src.id;
											break;
										}
									}
//								   var src = self.data.data.concepts[args.targetIndex];
//								   var id = src.id;
								   var children = src.c;
								   var type = self.data.findType(id);
								   var crs = [];

								   if (type != null){
									   if (type.type == 'process'){
										   // プロセス
										   crs.push(
													{
										            	text    : 'Show ProcessInfo',
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'process', [id, id]);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}

										            });
										   crs.push(
										            {
										            	text    : 'Show GeneralMaps',
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'generic', id);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}
										            });
										   crs.push(
										            {
										            	text    : 'Find Route',
										            	action  : function(event, target, index) {
										            		var id = self.data.data.concepts[target.__data__].id;
										            		self.eventHandler(self, 'route', id);
										            		self.common.full_screen($('#'+self.div.id + '_map'), false);
										            	}
										            });

//										   addCauseResults(id, crs);

									   } else {
											var relations = self.data.findRelations(id);
											 var sub = [];
											 for (var i in relations.relations){
												 var relation = relations.relations[i];
												 sub.push({
													text: relation.l,
													args: [id, relation.id],
													action  : function(event, target, index, args) {
														self.eventHandler(self, 'route', args);
														self.common.full_screen($('#'+self.div.id + '_map'), false);
													}
												 }
												 );
											 }

											 if (sub.length > 0){
												   crs.push({
														   text    : 'Find Route',
														   subMenu : sub
												   });
											}
									   }
								   }

								   addCauseResults(id, crs);

								   crs.push(
											{
								            	text    : 'Show Ontology',
								            	action  : function(event, target, index) {
								            		var id = self.data.data.concepts[target.__data__].id;
								            		self.eventHandler(self, 'ontology', id);
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
								            });
							   return crs;
						   }

		};

		function addCauseResults(id, crs){
			var causeresult = self.data.findCausesAndResults(id);
			if (Object.keys(causeresult.origins).length > 0){
				var sub = [];
				var work = [];

				for (var t in causeresult.origins){
					var causes = causeresult.origins[t];
					for (var i in causes){
						var cause = causes[i];
						if (self.map.findID(cause.id, true).length > 0 && work.indexOf(cause.id) < 0){
							sub.push({
								text: cause.l,
								args: cause.id,
								action  : function(event, target, index, args) {
									self.eventHandler(self, 'jump', args);
									self.common.full_screen($('#'+self.div.id + '_map'), false);
								}
							}
							);
							work.push(cause.id);
						}
					}
				}

				if (sub.length > 0){
					crs.push(
							{
								text    : 'Show Causes',
								subMenu : sub
							});
				}

			}

			if (Object.keys(causeresult.dests).length > 0){
				var sub = [];
				var work = [];

				for (var t in causeresult.dests){
					var dests = causeresult.dests[t];
					for (var i in dests){
						var dest = dests[i];
						if (self.map.findID(dest.id, true).length > 0 && work.indexOf(dest.id) < 0){
							sub.push({
								text: dest.l,
								args: dest.id,
								action  : function(event, target, index, args) {
									self.eventHandler(self, 'jump', args);
									self.common.full_screen($('#'+self.div.id + '_map'), false);
								}
							}
							);
							work.push(dest.id);
						}
					}
				}

				if (sub.length > 0){
					crs.push(
							{
								text    : 'Show Results',
								subMenu : sub
							});
				}

			}
		}

		self.map.setContextMenu(context);

	}

}


// プロセス情報を表示
Course.prototype.showAnnotationInfo = function(s){
//	var index = this.info.addTab(null,'annotation');
	var self = this;
	this.data.findAnnotation(s, function(data){
		self.info.show(data, data.type);
//		self.info.getInfo(index).show(data);
	});

}

Course.prototype.show_external_info = function(s){
	var self = this;

	this.data.findAnnotation(s, function(data){

		self.info.show_external(data);
	}, true);
}

Course.prototype.setLang = function(lang){
	this.lang = lang;
	this.data.setLang(lang);
	this.info.setLang(lang); // TODO infoのデータも更新

	this.update_tree(this.id, true);

}
