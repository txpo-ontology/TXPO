/**
 * 検索画面について、表示・制御するためのI/Fを提供する
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function SearchController(base_url, div, lang, param){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);



}

SearchController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	this.strings();

	// 画面作成
	function make_elements(ts){
		$(ts).append(
				$('<DIV></DIV>')
				.attr({
					'id' : ts.id + "_search_body",
					'class' : "search_main"
				}));

		$('#' + ts.id + "_search_body").append(
				$('<DIV></DIV>')
				.attr({
					'class' : "course_list"
				}));

		$('#' + ts.id + "_search_body").append(
				$('<DIV></DIV>')
				.attr({
					'class' : "search_div"
				}));


		$('#' + ts.id + "_search_body").append(
				$('<DIV></DIV>')
				.attr({
					'class' : "route_div"
				}));

		$('#' + ts.id + " .course_list").append(
				$('<h2><span class="text_asearch_course_list"></span></h2>'));
		$('#' + ts.id + " .course_list").append(
				$('<div></div>'));

		$('#' + ts.id + "_search_body .search_div").append(
				$('<h2><span class="text_asearch_find"></span></h2>'));

		$('#' + ts.id + "_search_body .search_div").append(
				$('<DIV></DIV>')
				.attr({
					'id' : ts.id + "_whole_search_div"
//					'class' : "search_div"
				}));

		$('#' + ts.id + "_whole_search_div").append(
				'<DIV><input type="text" name="find_whole" class="uiparts_theme textbox">' +
				'<input type="button" name="find" value="FIND" class="uiparts_theme common_button"></DIV>'
				);


		$('#' + ts.id + "_search_body .search_div").append(
				$('<div></div>')
				.attr({
					'id' : ts.id + "_detail_search_div"
//					'class' : "search_div"
				}));
		$('#' + ts.id + "_detail_search_div").append(
				$('<h3><span class="text_asearch_detail_find"></span></h3>'));

		$('#' + ts.id + "_search_body .search_div").append(
				$('<div></div>')
				.attr({
					'id' : ts.id + "_result_div"
//					'class' : "search_div"
				}));

		// 全体検索の結果
		$('#' + ts.id + "_result_div").append(
				$('<div></div>')
				.attr({
					'id' : ts.id + "_result_div_all"
				}));
		// TODO これは複数個所に登場するのでまとめたい
		var types = [{type:'c', name:'course'}, {type:'p', name:'process'}, {type:'r', name:'role'}, {type:'m', name:'molecule'}, {type:'f', name:'finding'}, {type:'s', name:'structure'}, {type:'q', name:'quarity'}];
		self.all_results = {};
		$('#' + ts.id + "_result_div_all").append(
				$('<h3><span class="text_asearch_result"></span></h3>'));
		for (var i in types){
			var type = types[i];
			$('#' + ts.id + "_result_div_all").append(
					$('<div></div>')
					.attr({
						'id' : ts.id + "_result_div_all_" + type.type
					}));

			$('#' + ts.id + "_result_div_all_"+type.type).append(
					$('<h4><span class="text_asearch_' + type.name + '"></span></h4>'));


			var resultdivs = new SearchResult($('#' + ts.id + "_result_div_all_"+type.type), base_url, null, self.lang);
			resultdivs.onNodeClicked(function(args, type){
				if (self.eventHandler != null){
					var etype = type;
					self.eventHandler(self, etype, args);
				}
			});
			self.all_results[type.type] = resultdivs;
		}
		$('#' + ts.id + "_result_div_all").hide();

		// 詳細検索の結果
		$('#' + ts.id + "_result_div").append(
				$('<div></div>')
				.attr({
					'id' : ts.id + "_result_div_detail"
				}));
		$('#' + ts.id + "_result_div_detail").append(
				$('<h3><span class="search_detail_result"></span></h3>'));

		self.setLang(self.lang);
	}

	make_elements(ts);

	this.common = new Common();

	this.searchdiv = new SearchInput($('#' + ts.id + "_detail_search_div"));
	this.searchdiv.setEventHandler(function(type, args, options){
		//
		if (args == null){
			// 検索エラー
			alert('Search Failed. Please try with another condition.');
			return;
		}


		if (type == 'find'){
			// 検索実行
			// 全体結果を非表示
			$('#' + ts.id + "_result_div_all").hide();
			// 詳細結果を非表示
			self.resultdiv.hide();
		}
		if (type == 'all_result'){
			self.resultdiv.show(args, options);
		}
		if (type == 'part_result'){
			$('#' + ts.id + "_result_div_all").show();
			$('#' + ts.id + "_result_div_all_"+options).show();

			self.all_results[options].show(args, options);
		}

	});
	this.searchdiv.cbShowIndicator = function(){
		self.common.showIndicator();
	}
	this.searchdiv.cbHideIndicator = function(){
		self.common.hideIndicator();
	}

	this.resultdiv = new SearchResult($('#' + ts.id + "_result_div_detail"), base_url);
	this.resultdiv.onNodeClicked(function(args, type){
		// TODO
		if (self.eventHandler != null){
			var etype = type;
			self.eventHandler(self, etype, args);
		}
	});
	this.resultdiv.hide();

	// 作用機序一覧初期化
	this.data = new Data(base_url, this.lang);

	this.updateSeries();

	$(document).on('click', '#' + ts.id + " .course_list ul li span", function(event){
		var s = $(event.target.previousSibling).text();
		if (s == 'all'){
			self.eventHandler(self, 'generic', s);
		} else {
			self.eventHandler(self, 'course', s);
		}
	});

	$('#' + ts.id + '_whole_search_div input[name=find]').click(function(event){
		var word = $('#' + ts.id + '_whole_search_div input[name=find_whole]').val();
		self.searchdiv.find_all(word);
	});

	$('#' + ts.id + ' input[name=find_whole]').keypress(function(event){
		if (event.which == 13){
			var word = $('#' + ts.id + '_whole_search_div input[name=find_whole]').val();
			self.searchdiv.find_all(word);
		}
	});
}

SearchController.prototype.updateSeries = function(){
	var self = this;
	var ts = this.div;

//	this.common.showIndicator();
	function get_series(){
		self.data.findSeries(function(result){
			// 最上位の作用機序のみ一覧表示
			set_series_list(result);
			// suggest用treeを更新
			self.searchdiv.setSuggestTreeData(result, true);

//			self.common.hideIndicator();
		});
	}
	function set_series_list(result){
		var tmp_list = {};
		var list = [];
		for (var i=0; i<result.length; i++){
			var datum = result[i];
			if (datum.pr.value == DATA_TOX_MECHA){
				var tmp = tmp_list[datum.s.value]; //.push({s:datum.s, label:datum.l});
				if (tmp == null){
					tmp = {};
					tmp_list[datum.s.value] = tmp;
				}
				var ltype = "_";
				if (datum.l['xml:lang'] != null && datum.l['xml:lang'] != ""){
					ltype = datum.l['xml:lang'];
				}
				tmp[ltype] = datum.l.value;
			}
		}
		for (var s in tmp_list){
			var tmp = tmp_list[s];
			var label = null;
			for (var ltype in tmp){
				if (label == null || ltype == self.lang){
					label = tmp[ltype];
				}
			}
			list.push({s:s, label:label});
		}


		var content = '<ul>';
		var seps = ['（', '(', '['];
		for (var i in list){
			var item = list[i];

			var label = item.label;

			var index = 9999;
			for (var i in seps){
				var sep = seps[i];
				var idx = label.indexOf(sep);
				if (idx >= 0){
					index = Math.min(index, idx);
				}
			}
			if (index < 9999){
				label = label.substring(0,index).trim();
			}

			content += '<li><span class="hide">' + item.s + '</span><span class="clickable">' + label + '</span>\n';
		}
		if (typeof test !== 'undefined'){
			content += '<li><span class="hide">all</span><span class="clickable text_asearch_all_course"></span>\n';
		}


		content += '</ul>';
		$('#' + ts.id + " .course_list div").html(content);
/*
		$('#' + ts.id + " .course_list ul li span").click(function(event){
			var s = $(event.target.previousSibling).text();

		});
*/
		self.setLang(self.lang);
	}


	get_series();
}


SearchController.prototype.setLang = function(lang){

	if (lang == null){
		lang = 'ja';
	}
	for(var key in this.consts[lang]){
		$('.text_asearch_'+key).text(this.consts[lang][key]);
	}

	if (this.lang != lang){
		this.lang = lang;



		this.data.setLang(lang);
		this.updateSeries(lang);

		this.searchdiv.setLang(lang);
		this.resultdiv.setLang(lang);

		for (var key in this.all_results){
			this.all_results[key].setLang(lang);
		}

	}

}

SearchController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

SearchController.prototype.strings = function(){
	this.consts = {};

	this.consts['ja'] = {
			'course_list': '作用機序一覧',
			'find': '検索',
			'detail_find': '詳細検索',
			'result': '検索結果',
			'detail_result': '詳細検索結果',
			'course': '作用機序',
			'process': 'プロセス',
			'role': 'ロール',
			'molecule': '分子/化合物',
			'finding': '所見',
			'structure': '構造',
			'quarity': '性質',
			'all_course': '全作用機序'
			};
	this.consts['en'] = {
			'course_list': 'Toxic Course List',
			'find': 'Search',
			'detail_find': 'Detail Search',
			'result': 'Result',
			'detail_result': 'Detail Result',
			'course': 'Course',
			'process': 'Process',
			'role': 'Role',
			'molecule': 'Molecule/Compound',
			'finding': 'Finding',
			'structure': 'Structure',
			'quarity': 'Quarity',
			'all_course': 'All Toxic Courses'
			};

}
