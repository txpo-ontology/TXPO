/**
 * プロセス画面について、複数タブで表示するためのI/Fを提供する
 */


/**
 * div   対象DIV
 * lang  言語
 * param 初期状態復元用param
 */
function ProcessController(base_url, div, lang, param, isCreateTab){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url);

	if (isCreateTab) {
		this.addTab();
	}

	/*
	tab2 = new Tab([{head:'head2_1', content:'body2_1'}, {head:'head2_2', content:'body2_2'}, {head:'head2_3', content:'body2_3'}]);
	tab2.showTab('head2_1');
*/

}


ProcessController.prototype.init = function(base_url){
	var ts = this.div;
	var self = this;

	this.base_url = base_url;


	$(ts).append(
			$('<DIV></DIV>'));

	$('#'+ts.id+" > div").append(
			$('<ul></ul>')
			.attr({
				'id' : ts.id + "_head",
				'class' : "tab_head2"
			}));
	$('#'+ts.id+" > div").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "tab_body"
			}));

	this.tab = new Tab("process", ts.id);

	function set_eventmap(){
		self.eventMap = {
				'selected':function(src, args){
					var tabs = self.tab.getTabs();
					for (var key in tabs){
						if (tabs[key].content == src.div.id){
							// TODO
							var seps = ['（', '(', '['];
							var index = 9999;
							for (var i in seps){
								var sep = seps[i];
								var idx = args.indexOf(sep);
								if (idx >= 0){
									index = Math.min(index, idx);
								}
							}
							if (index < 9999){
								args = args.substring(0,index).trim();
							}

							self.tab.setName(key, args);
//							$('#'+key).text(args);
							break;
						}
					}
				},
				'course':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'course', args);
					}
				},
				'generic':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'generic', args);
					}
				},
				'process':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'process', args);
					}
				},
				'route':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'route', args);
					}
				},
				'ontology':function(src, args){
					// さらに上位にイベントを通知する
					if (self.eventHandler != null){
						self.eventHandler(src, 'ontology', args);
					}
				},
				'newtab':function(src, args){
					self.addTab(args);
				}
		};
	}
	set_eventmap();

}

/**
 * 現在のタブを取得する
 */
ProcessController.prototype.getCurrentTab = function(){

	return this.tab.getCurrentTab();
}


/**
 * タブを追加する
 * 戻り値はタブのindex
 */
ProcessController.prototype.addTab = function(id, addHistory){
	var ts = this.div;
	var self = this;

//	var index = 0;

	var label = "new tab";

	var pid = null;

	// プロセスIDも含む
	if (Array.isArray(id)){
		pid = id[1];
		id = id[0];
	}

	if (addHistory == null){
		addHistory = true;
	}
/*
	for (index = 0; ;index++){
		if ($("#" + ts.id + "_head_"+index)[0] == null){
			break;
		}
	}

	var newHead = ts.id + "_head_"+index;
	var newBody = ts.id + "body_"+index;
*/
	var newHead = this.tab.getNewTabID();
	var newBody = newHead.body;
	var newHead = newHead.head;



	$('#'+ts.id+"_head").append(
			'<li id="' + newHead + '"></li>');

	$('#'+ts.id+" > div > div.tab_body").append(
			$('<DIV></DIV>')
			.attr({
				'id' : newBody,
				'class' : "body2"
			}));

	var init = null;
	if (pid != null){
		init = {'props':'srpwmftioa', 'mol':true};
	} else {
		init = {'props':'srpwmftioa', 'mol':false};
	}

	var process = new Process(this.base_url, $('#' + newBody), this.lang, id, null, init);
	if (id != null){
		process.update_tree(id, false, pid);
	}

	// TODO processのイベントハンドラ（選択変更時・タブ追加など）
	process.setEventHandler(function(src, type, args){
		/*
		if (type == 'selected'){
			for (var key in self.tabmap){
				if (self.tabmap[key] == src.div.id){
					$('#'+key).text(args);
					break;
				}
			}
		}
		if (type == 'newtab'){
			self.addTab(args);
		}*/
		var func = self.eventMap[type];
		if (func != null){
			func(src, args);
		}
	});

	var self = this;
	var callback = function( data ) {
		var id_ = data.target.parentElement.id;
		if( "" == id_ ){
			id_ = data.target.parentElement.parentElement.id;
		}
		self.removeTab( id_ );
		data.stopPropagation();
	};

	this.tab.addTab( newHead, newBody, process, null, callback );
	this.tab.setName(newHead, label);

	if (addHistory){
		if (this.tab != null){
			var cmd = new Command("process.addTab", [newHead, this.tab.getCurrentTab(), id]);
			cmds.push(cmd);
		}
	}

	this.tab.showTab(newHead);

	this.setContextMenu();

	return newHead;

}



/**
 * タブを削除する
 */
ProcessController.prototype.removeTab = function(index){
	var ts = this.div;
	var self = this;

	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	this.tab.removeTab(index);

	this.setContextMenu();
}

/**
 * タブを選択する
 */
ProcessController.prototype.selectTab = function(index){
	if (!isNaN(index)){
		// 数値の場合はidに変換
		index = ts.id + "_head_"+index;
	}

	this.tab.showTab(index);
}


ProcessController.prototype.setContextMenu = function (){

	var self = this;

	var sampleElement = $('#' + this.div.id+ '_head li');

	var contextMenuObj = new ContextMenu({
	    element  : sampleElement,
	    menuList : [
	        {
	            text    : 'Close This Tab',
	            action  : function(event) {
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	if (id_ == ''){
	            		id_ = data.target.parentElement.id;
	            	}
	            	self.removeTab(id_);
	            },
	            disabled:(sampleElement.length <= 1)
	        }/*,
	        {
	            text    : 'Copy This Tab',
	            action  : function() {
//	                alert('button 2 click');
	            	var data = this._data;
	            	var id_ = data.target.id;
	            	var t = self.tree.getNodeData(id_);
	            	if (self.eventHandler != null){
	            		self.eventHandler(self, 'newtab', t.resource);
	            	}
	            }
	        }*/
	    ]
	});
}

//現在の表示状態から、パラメータ情報を取得する
ProcessController.prototype.getParameter = function(){

}

ProcessController.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}


ProcessController.prototype.setLang = function(lang){
	this.lang = lang;
	var objs = this.tab.getTabs();

	for (var key in objs){
		var object = objs[key];
		if (object.obj != null){
			object.obj.setLang(lang);
		}
	}
}
