

function Process(base_url, div, lang, id, prop, init){
	this.div = div[0];
	if (lang == null){
		lang = 'ja';
	}
	this.lang = lang;

	this.init(base_url, id, prop, init);
}


Process.prototype.init = function(base_url, id, prop, init){
	var ts = this.div;
	var self = this;

	$(ts).addClass('split-pane fixed-right');

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "left split-pane-component"
			}));
	$('#'+ts.id+" .left").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_tree",
				'class' : "left_all2"
			}));
	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider vertical"
			}));

	$(ts).append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right split-pane-component"
			}));

	$('#'+ts.id+" .right").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "right_all split-pane horizontal-percent"
			}));

	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_map",
				'class' : "right_top  split-pane-component"
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'class' : "split-pane-divider horizontal " + ts.id
			}));
	$('#'+ts.id+" .right_all").append(
			$('<DIV></DIV>')
			.attr({
				'id' : ts.id + "_bottom",
				'class' : "right_bottom split-pane-component " + ts.id
			}));

	if (prop != null){
		prop = Object.assign(prop, {'direction': 'TB', 'mol':true});
	} else {
		prop = {'direction': 'TB', 'mol':true};
	}

	this.common = new Common();

	this.map = new Map($('#'+ts.id + '_map'), prop, init);
	this.map.setUpdateHandler(this.mapHandler.bind(this));
	this.map.onNodeClicked(function(index, id, obj){
//		var a = args;
		self.showAnnotationInfo(id);
	}.bind(this),
	function(args1, args2, args3){
//		var a = args;
	}.bind(this), this);

	this.data = new ProcessData(base_url, this.lang);

	this.tree = new Tree($('#' + ts.id+ '_tree'));
	this.tree.onNodeClicked(function(id){
		var t = self.tree.getNodeData(id);
		self.tree.findID(t.resource);
//		update_series(t.resource, t.name, self.map.getRelationType());
		self.update_series(id);

	});

	this.info = new InfoController($('#'+ts.id + '_bottom'), this.lang);
	this.info.onNodeClicked(function(args, type){
		// TODO idを元に種別を取得し、それに応じた処理を行う
		if (type != null){
			if (type == 'external'){
				// 外部リソース取得
				self.show_external_info(args);
				return;
			}


			if (self.eventHandler != null){
				var etype = type;
				self.eventHandler(self, etype, args);
			}
		} else {
			self.data.findType(args, function(data){
				if (data != null && data.type != null){
					type = data.type;
					var etype = 'ontology';
					if (type == 'course'){
						etype = 'course';
					} else if (type == 'process'){
						etype = 'process';
					}
					// まずは情報表示
					if (self.eventHandler != null){
						self.eventHandler(self, etype, args);
					}
				}
			});
		}
		/*

		self.data.findType(tid, function(data){
			if (data != null && data.type != null){
				var type = data.type;
				var etype = 'ontology';
				if (type == 'course'){
					etype = 'course';
				} else if (type == 'process'){
					etype = 'process';
				}
				// まずは情報表示
				if (self.eventHandler != null){
					self.eventHandler(self, etype, tid);
				}
			}
		})*/;
	}.bind(this));

	$(ts).splitPane();
	$('#'+ts.id +' .split-pane').splitPane();
	$('#'+ts.id +' .split-pane-divider').on('mouseup', function () {
		$(window).trigger('resize');
	}).on('mouseout', function () {
		$(window).trigger('resize');
	});

	this.map.adjust();

}

Process.prototype.mapHandler = function(type, args){
	if (type == 'option'){
		this.update_series();
	} else
	if (type == 'molecule'){
		this.update_molecule();
	} else
	if (type == 'fullscreen'){
		this.common.full_screen(args[1], args[0]);
	} else {
		this.update_series();
	}

//	this.eventHandler = func;
}




Process.prototype.update_tree = function(id, update, pid){
	var self = this;
	this.id = {id:id, pid:pid};

	if (update == null){
		update = true;
	}

	self.common.showIndicator();
	self.data.findAllProcesses(function(result){
		// treeデータ result
		self.tree.setTreeData(result, true);
		var id = null;
		var pid = null;
		if (self.id != null){
			id = self.id.id;
			pid = self.id.pid;
		}
		self.id = null;


		setContextMenu();

		if (id != null){
			// 該当IDを選択・強調、マップを表示
			var ids = self.tree.findID(id);
			if (ids != null && ids.length > 0){
				var id = ids[0];
				var t = self.tree.getNodeData(id);
//				self.tree.findID(t.resource);
//				update_series(t.resource, t.name, self.map.getRelationType());
				self.update_series(id, null, pid);
			}
		}

		// resize
		$(window).trigger('resize');
		self.common.hideIndicator();
	}
	);


	// contextMenuのイベント登録
	function setContextMenu(){
		/*
		var context = {
				menuList : [
				            {
				            	text    : 'Open in New Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'newtab', node.resource);
				            		}
				            	}
				            },
				            {
				            	text    : 'Open in This Window',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);
				            		self.tree.findID(node.resource);
				            		update_series(node.id);
				            	}
				            },
				            {
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var node = get_node(target);

				            		if (self.eventHandler != null){
				            			self.eventHandler(self, 'ontology', node.resource);
				            		}
				            	}
				            }
				            ]
		};
		*/
		var context = {
				menuList : [
					{
		            	text    : 'dmy'
		           }],
					   menuCallback : function(args){
		            		var node = get_node(args.target);
							var id = node.resource;
							if (id.indexOf('$') > 0){
								id = id.substring(0, id.indexOf('$'));
							}
							var courses = self.data.findCourses(id);
							 var type = self.data.findType(id);
							 var sub = [];
							 for (var i in courses.courses){
								 var course = courses.courses[i];
								 sub.push({
									text: course.l,
									args: [course.id, id],
									action  : function(event, target, index, args) {
//										var pid = self.data.data.concepts[target.__data__].id;
//										var id = course.id;
										self.eventHandler(self, 'course', args);
										self.common.full_screen($('#'+self.div.id + '_map'), false);
									}
								 }
								 );
							 }

							 var crs = [];
							 if (sub.length > 0){
								   crs.push({
										   text    : 'Show Course',
										   subMenu : sub
								   });
							}

						   crs.push(
									{
						            	text    : 'Open in New Window',
						            	action  : function(event, target, index) {
						            		var node = get_node(target);

						            		if (self.eventHandler != null){
						            			self.eventHandler(self, 'newtab', node.resource);
						            		}
						            	}
						            });
						   crs.push(
									{
						            	text    : 'Open in This Window',
						            	action  : function(event, target, index) {
						            		var node = get_node(target);
						            		self.tree.findID(node.resource);
						            		self.update_series(node.id);
						            	}
						            });

						   if (type != null){
							   if (type.type == 'process'){
								   crs.push(
								            {
								            	text    : 'Show GeneralMaps',
								            	action  : function(event, target, index) {
								            		var node = get_node(target);
								            		var id = node.resource;
								            		if (self.eventHandler != null){
								            			self.eventHandler(self, 'generic', id);
								            		}
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
								            });
								   crs.push(
								            {
								            	text    : 'Find Route',
								            	action  : function(event, target, index) {
								            		var node = get_node(target);
								            		var id = node.resource;
								            		if (self.eventHandler != null){
								            			self.eventHandler(self, 'route', id);
								            		}
								            		self.common.full_screen($('#'+self.div.id + '_map'), false);
								            	}
								            });
								   crs.push(
								            {
								            	text    : 'Show Ontology',
								            	action  : function(event, target, index) {
								            		var node = get_node(target);

								            		if (self.eventHandler != null){
								            			self.eventHandler(self, 'ontology', node.resource);
								            		}
								            	}
								            });
							   } else {
									var relations = self.data.findRelations(id);
									 var sub = [];
									 for (var i in relations.relations){
										 var relation = relations.relations[i];
										 sub.push({
											text: relation.l,
											args: [id, relation.id],
											action  : function(event, target, index, args) {
												self.eventHandler(self, 'route', args);
												self.common.full_screen($('#'+self.div.id + '_map'), false);
											}
										 }
										 );
									 }

									 var crs = [];
									 if (sub.length > 0){
										   crs.push({
												   text    : 'Find Route',
												   subMenu : sub
										   });
									}
							   }
						   }
					   return crs;
				   }


};
		self.tree.setContextMenu(context);

		function get_node(data){
			var id_ = data.id;
			var t = self.tree.getNodeData(id_);
			if (t == null){
				id_ = data.parentElement.id;
				t = self.tree.getNodeData(id_);
			}
			return t;
		}
	}
}

Process.prototype.update_molecule = function(){
	this.common.showIndicator();
	if (this.map.adjust()){
		this.update_series();
	} else {
		this.updateMap();
	}
	this.common.hideIndicator();
}

Process.prototype.update_series = function(tid, cb, pid){
	var self = this;

	var update = false;
	if (tid == null){
		tid = self.tree.getCurrent();
		update = true;
	}
	if (tid == null){
		return;
	}
	var t = self.tree.getNodeData(tid);
	this.id = t.resource;

	var id = this.id;
	self.tree.findID(id);
	var label = t.name;
	var type = self.map.getRelationType();

	if (id.indexOf('$')>0){
		id = id.substring(0, id.indexOf('$'));
	}


	self.common.showIndicator();
	self.data.findNodes(id, label, function(data){
		if (data.data.length == 0){
//			self.draw.clear();
//			alert("No Data");
		} else {
			self.tree.setCurrent(tid);
			self.updateMap(id, data);
			/*
			self.map.setMapData(data);


			var context = {
					menuList : [
					{
		            	text    : 'dmy'
		           }],
					   menuCallback : function(args){
						   var id = self.data.data.concepts[args.targetIndex].id;
						   var courses = self.data.findCourses(id);
						   var type = self.data.findType(id);
						   var sub = [];
						   for (var i in courses.courses){
							   var course = courses.courses[i];
							   sub.push({
								   text: course.l,
								   args: course.id,
								   action  : function(event, target, index, id) {
									   var pid = self.data.data.concepts[target.__data__].id;
//					            		var id = course.id;
					            		self.eventHandler(self, 'course', [id, pid]);
					            		self.common.full_screen($('#'+self.div.id + '_map'), false);
					            	}
							   }
							   );
						   }

						   var crs = [];
						   if (sub.length > 0){
							   crs.push({
									   text    : 'Show Course',
									   subMenu : sub
							   });
						   }
						   if (type.type == 'process'){
							   crs.push(
								{
					            	text    : 'Show ProcessInfo',
					            	action  : function(event, target, index) {
					            		var id = self.data.data.concepts[target.__data__].id;
					            		self.eventHandler(self, 'process', id);
					            		self.common.full_screen($('#'+self.div.id + '_map'), false);
					            	}

					            });
							   crs.push(
							            {
							            	text    : 'Show GeneralMaps',
							            	action  : function(event, target, index) {
							            		var id = self.data.data.concepts[target.__data__].id;
							            		self.eventHandler(self, 'generic', id);
							            		self.common.full_screen($('#'+self.div.id + '_map'), false);
							            	}
							            });

							   crs.push({
									   text    : 'Show Route',
						            	action  : function(event, target, index) {
						            		var id = self.data.data.concepts[target.__data__].id;
						            		self.eventHandler(self, 'route', id);
						            		self.common.full_screen($('#'+self.div.id + '_map'), false);
					            	}
							   });
						   }
						   crs.push(
									{
						            	text    : 'Show Ontology',
						            	action  : function(event, target, index) {
						            		var id = self.data.data.concepts[target.__data__].id;
						            		self.eventHandler(self, 'ontology', id);
						            		self.common.full_screen($('#'+self.div.id + '_map'), false);
						            	}
						            });

						   return crs;
					   }
			};

			self.map.setContextMenu(context);
			self.map.findID(id);
			*/
		}
		self.common.hideIndicator();

		if (cb != null){
			cb(data);
		}
	}, type);

	if (!update){
		self.showAnnotationInfo(id);
	}

	if (self.eventHandler != null){
		self.eventHandler(self, 'selected', t.name);
	}

	function get_node(data){
		var id_ = data.id;
		var t = self.tree.getNodeData(id_);
		if (t == null){
			id_ = data.parentElement.id;
			t = self.tree.getNodeData(id_);
		}
		return t;
	}

}

Process.prototype.updateMap = function(id, data){

	var self = this;

	if (id == null){
		id = this.id;
	}
	if (id == null || (typeof id != 'string' && id.id == null)){
		return;
	}

	self.map.setMapData(data);


	var context = {
			menuList : [
			{
            	text    : 'dmy'
           }],
			   menuCallback : function(args){
//				   var id = self.data.data.concepts[args.targetIndex].id;
				   var src = null;
				   var id = null;
					for (var i in self.data.data.concepts){
						var datum = self.data.data.concepts[i];
						var id = datum.id;
						id = id.substring(id.lastIndexOf('/')+1);
						if (args.targetID.indexOf(id) > 0){
							src = datum;
							id = src.id;
							break;
						}
					}


				   var courses = self.data.findCourses(id);
				   var type = self.data.findType(id);
				   var sub = [];
				   for (var i in courses.courses){
					   var course = courses.courses[i];
					   sub.push({
						   text: course.l,
						   args: course.id,
						   action  : function(event, target, index, id) {
							   var pid = self.data.data.concepts[target.__data__].id;
//			            		var id = course.id;
			            		self.eventHandler(self, 'course', [id, pid]);
			            		self.common.full_screen($('#'+self.div.id + '_map'), false);
			            	}
					   }
					   );
				   }

				   var crs = [];
				   if (sub.length > 0){
					   crs.push({
							   text    : 'Show Course',
							   subMenu : sub
					   });
				   }
				   if (type.type == 'process'){
					   crs.push(
						{
			            	text    : 'Show ProcessInfo',
			            	action  : function(event, target, index) {
			            		var id = self.data.data.concepts[target.__data__].id;
			            		self.eventHandler(self, 'process', id);
			            		self.common.full_screen($('#'+self.div.id + '_map'), false);
			            	}

			            });
					   crs.push(
					            {
					            	text    : 'Show GeneralMaps',
					            	action  : function(event, target, index) {
					            		var id = self.data.data.concepts[target.__data__].id;
					            		self.eventHandler(self, 'generic', id);
					            		self.common.full_screen($('#'+self.div.id + '_map'), false);
					            	}
					            });

					   crs.push({
							   text    : 'Show Route',
				            	action  : function(event, target, index) {
				            		var id = self.data.data.concepts[target.__data__].id;
				            		self.eventHandler(self, 'route', id);
				            		self.common.full_screen($('#'+self.div.id + '_map'), false);
			            	}
					   });
				   } else {
						var relations = self.data.findRelations(id);
						 var sub = [];
						 for (var i in relations.relations){
							 var relation = relations.relations[i];
							 sub.push({
								text: relation.l,
								args: [id, relation.id],
								action  : function(event, target, index, args) {
									self.eventHandler(self, 'route', args);
									self.common.full_screen($('#'+self.div.id + '_map'), false);
								}
							 }
							 );
						 }

						 if (sub.length > 0){
							   crs.push({
									   text    : 'Find Route',
									   subMenu : sub
							   });
						}
				   }
				   crs.push(
							{
				            	text    : 'Show Ontology',
				            	action  : function(event, target, index) {
				            		var id = self.data.data.concepts[target.__data__].id;
				            		self.eventHandler(self, 'ontology', id);
				            		self.common.full_screen($('#'+self.div.id + '_map'), false);
				            	}
				            });

				   return crs;
			   }
	};

	self.map.setContextMenu(context);
	self.map.findID(id);

}

Process.prototype.showAnnotationInfo = function(s){
//	var index = this.info.addTab(null,'annotation');
	var self = this;
	this.data.findAnnotation(s, function(data){
		self.info.show(data, data.type);
//		self.info.getInfo(index).show(data);
	});

}

Process.prototype.show_external_info = function(s){
	var self = this;

	this.data.findAnnotation(s, function(data){

		self.info.show_external(data);
	}, true);
}


Process.prototype.setEventHandler = function(func){
	this.eventHandler = func;
}

Process.prototype.setLang = function(lang){
	this.lang = lang;
	this.data.setLang(lang);
	this.info.setLang(lang); // TODO infoのデータも更新

	this.update_tree(this.id, true);

}

